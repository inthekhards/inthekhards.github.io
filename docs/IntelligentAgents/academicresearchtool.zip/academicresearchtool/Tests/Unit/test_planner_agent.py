"""Unit tests: one function or class at a time, in isolation (no Ollama, no internet).

Section: Planner agent.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import httpx

from Agents.plan import PlannerAgent
from App.models import (
    AcceptanceCriteria,
)


def test_planner_builds_agents_from_chosen_models():
    """The models chosen in Settings are used by each agent.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    planner = PlannerAgent(models={"planner": "gemma4:e4b", "retrieval": "llama3.1:8b", "storage": "llama3.1:8b"})
    assert (planner.llm.model, planner.retrieval.llm.model, planner.processing.llm.model, planner.storage.llm.model) == (
        "gemma4:e4b", "llama3.1:8b", "qwen3.5:9b", "llama3.1:8b",
    )


def test_planner_is_told_the_language():
    """The planner's instructions name the research language.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    prompts = []

    class Capture:
        def generate_structured(self, prompt, schema, system=None, **kwargs):
            prompts.append(prompt)
            raise httpx.ConnectError("stop here")

    planner = PlannerAgent(llm=Capture(), processing_llm=Capture(), storage_llm=Capture())
    try:
        planner.decompose_goal("Qu'est-ce que la matière noire ?", "fr")
    except httpx.ConnectError:
        pass
    assert "the research is in French" in prompts[0]


def test_criteria_are_clamped_to_sensible_ranges():
    """Over-ambitious criteria from the model are limited to sensible ranges.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    c = AcceptanceCriteria(
        min_relevant_articles=500, min_peer_reviewed_share=3, min_average_quality=0.99,
        max_age_years=0, every_subtask_covered=False,
    )
    assert (c.min_relevant_articles, c.min_peer_reviewed_share, c.min_average_quality, c.max_age_years) == (25, 1.0, 0.85, 2)
