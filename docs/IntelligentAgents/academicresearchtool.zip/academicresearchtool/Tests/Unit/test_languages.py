"""Unit tests: one function or class at a time, in isolation (no Ollama, no internet).

Section: Research languages and writing systems.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

from App.languages import detect_language, foreign_script, get_language, language_problem


def test_writing_systems():
    """Cyrillic, Greek words and Chinese are detected; Greek symbols (β-amyloid) and accented names are not.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    assert foreign_script("Наталія Миколаївна Павлущенко") == "CYRILLIC"
    assert foreign_script("Κλινική μελέτη") == "GREEK"
    assert foreign_script("王伟") == "CJK"
    assert foreign_script("β-amyloid plaques and α-synuclein") is None  # scientific symbols are fine
    assert foreign_script("José María Romero Rodríguez") is None  # accented Latin names are fine


def test_english_article_with_cyrillic_author_is_rejected():
    """An English-tagged article with a Cyrillic author name is rejected.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    problem = language_problem(
        "en", "Integrating Socio-Emotional Learning into Primary Education", None,
        ["Наталія Миколаївна Павлущенко", "Oksana Kuznetsova"], "Journal", "en",
    )
    assert problem == "author name in Cyrillic script"


def test_detects_the_question_language():
    """The language of a question is detected (and not guessed from keywords only).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    assert detect_language("How does sleep affect memory consolidation?") == "en"
    assert detect_language("Qu'est-ce que la matière noire et comment la détecte-t-on ?") == "fr"
    assert detect_language("¿Cómo afecta el sueño a la memoria?") == "es"
    assert detect_language("Wie beeinflusst der Schlaf das Gedächtnis?") == "de"
    assert detect_language("quantum error correction") is None  # too few clues: no guess


def test_unknown_language_code_falls_back_to_english():
    """An unknown language code falls back to English.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    assert get_language("xx").code == "en" and get_language(None).code == "en"
