"""Unit tests: one function or class at a time, in isolation (no Ollama, no internet).

Section: Time budget, journal storage and settings.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

from datetime import datetime
import json
import os
import time

from App import config
from App.budget import TimeBudget, format_seconds, has_time, scope_limits, seconds_left
from App.journal import JournalStore
from App.models import FinalResults, PlannerApproval, RetrievalCycle

# ---- Time budget ------------------------------------------------------------


def test_scope_limits_match_the_settings():
    """Each scope gets the time, article and query limits set in App/config.py.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    general, detailed, extended = scope_limits("general"), scope_limits("detailed"), scope_limits("extended")
    assert (general.seconds_per_agent, general.articles_per_search, general.queries_per_search) == (300, 10, 3)
    assert (detailed.seconds_per_agent, detailed.articles_per_search, detailed.queries_per_search) == (300, 20, 5)
    assert (extended.seconds_per_agent, extended.articles_per_search, extended.queries_per_search) == (600, 40, 6)


def test_each_agent_has_its_own_budget():
    """Charging one agent's time doesn't reduce another agent's time.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    budget = TimeBudget(seconds_per_agent=100)
    budget.charge("Planner Agent", 30)
    budget.charge("Planner Agent", 30)
    assert budget.remaining("Planner Agent") == 40
    assert budget.remaining("Storage Agent") == 100
    budget.charge("Planner Agent", 500)
    assert budget.remaining("Planner Agent") == 0  # never negative


def test_time_spent_on_a_pop_up_is_not_charged():
    """Time inside ``budget.pause()`` is recorded so it can be left out of every agent's time.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    budget = TimeBudget()
    with budget.pause():
        time.sleep(0.2)
    assert budget.paused >= 0.18


def test_deadline_helpers():
    """``seconds_left`` and ``has_time`` treat None as 'no time limit'.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    assert seconds_left(None) is None and has_time(None, 10_000)
    soon = time.monotonic() + 5
    assert 4 < seconds_left(soon) <= 5 and has_time(soon, 4) and not has_time(soon, 6)
    assert seconds_left(time.monotonic() - 10) == 0  # past deadlines are 0, not negative


def test_format_seconds():
    """Durations are shown as '45s' or '2m 05s'.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    assert [format_seconds(s) for s in (0, 45, 60, 125.4, 600)] == ["0s", "45s", "1m 00s", "2m 05s", "10m 00s"]


# ---- Journal ------------------------------------------------------------------


def test_journal_is_named_by_date_and_time(tmp_path):
    """A new journal is called YYYY-MM-DD_HH-MM-SS.json and starts empty.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    path = JournalStore(tmp_path).create("What is dark matter?")
    datetime.strptime(path.stem, "%Y-%m-%d_%H-%M-%S")
    journal = JournalStore().load(path)
    assert journal.goal == "What is dark matter?" and journal.cycles == [] and journal.final_results is None


def test_two_journals_in_the_same_second_get_different_names(tmp_path):
    """Runs started in the same second never overwrite each other's journal.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    store = JournalStore(tmp_path)
    names = {store.create("a").name for _ in range(3)}
    assert len(names) == 3


def test_final_results_section_is_last_and_left_out_until_written(tmp_path):
    """"FINAL RESULTS" is absent from a new journal and always the last section once written.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    store = JournalStore(tmp_path)
    path = store.create("g")
    assert "FINAL RESULTS" not in json.loads(path.read_text())

    journal = store.load(path)
    journal.final_results = FinalResults(
        planner_approval=PlannerApproval(status="approved", search_cycles=1, reason="ok"), goal="g"
    )
    store.save(path, journal)
    store.append_cycle(path, RetrievalCycle(iteration=2, started_at=datetime.now(), completed_at=datetime.now(), model="m"))
    data = json.loads(path.read_text())
    assert list(data)[-1] == "FINAL RESULTS" and data["FINAL RESULTS"]["title"] == "FINAL RESULTS"
    assert len(data["cycles"]) == 1


def test_journal_save_leaves_no_temporary_file(tmp_path):
    """Saving writes to a temporary file and swaps it in, so a crash can't leave half a journal.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    store = JournalStore(tmp_path)
    store.create("g")
    assert [p.suffix for p in tmp_path.iterdir()] == [".json"]


# ---- Settings ------------------------------------------------------------------


def test_env_file_is_read_but_real_environment_wins(tmp_path, monkeypatch):
    """Keys in .env are loaded; a variable already set in the environment is not overwritten.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    env = tmp_path / ".env"
    env.write_text('# comment\nTEST_KEY_ONE=from-file\nTEST_KEY_TWO="quoted"\nTEST_KEY_THREE=from-file\n')
    monkeypatch.delenv("TEST_KEY_ONE", raising=False)
    monkeypatch.delenv("TEST_KEY_TWO", raising=False)
    monkeypatch.setenv("TEST_KEY_THREE", "from-environment")
    config._load_dotenv(env)
    assert os.environ["TEST_KEY_ONE"] == "from-file"
    assert os.environ["TEST_KEY_TWO"] == "quoted"
    assert os.environ["TEST_KEY_THREE"] == "from-environment"
    monkeypatch.delenv("TEST_KEY_ONE")
    monkeypatch.delenv("TEST_KEY_TWO")


def test_folders_point_to_the_project():
    """Reports go to Results/, journals to Journal/ and agent logs to Agents/Logs/ in the project folder.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    import importlib.util

    # Load the settings file afresh: the tests themselves redirect these folders to a temporary place.
    spec = importlib.util.spec_from_file_location("fresh_config", config.__file__)
    fresh = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(fresh)
    assert fresh.RESULTS_DIR == fresh.PROJECT_ROOT / "Results"
    assert fresh.JOURNAL_DIR == fresh.PROJECT_ROOT / "Journal"
    assert fresh.AGENT_LOG_DIR == fresh.PROJECT_ROOT / "Agents" / "Logs"
    assert (fresh.PROJECT_ROOT / "interface.py").exists()
