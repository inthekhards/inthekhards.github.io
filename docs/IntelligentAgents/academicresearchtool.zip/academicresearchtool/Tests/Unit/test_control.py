"""Unit tests: one function or class at a time, in isolation (no Ollama, no internet).

Section: Stop and Pause controls.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import threading

import pytest

from App.control import ResearchStopped, RunControl


def test_stopped_run_ends_at_the_next_checkpoint():
    """After Stop, the next checkpoint ends the run.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    control = RunControl()
    control.stop()
    with pytest.raises(ResearchStopped):
        control.checkpoint()


def test_paused_run_waits_until_resumed():
    """While paused, a checkpoint waits until Resume and records the paused time.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    control = RunControl()
    control.pause()
    threading.Timer(0.3, control.resume).start()
    waited = control.checkpoint()
    assert waited >= 0.25 and control.paused_seconds >= 0.25


def test_stop_wakes_a_paused_run():
    """Stop also ends a run that is currently paused.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    control = RunControl()
    control.pause()
    threading.Timer(0.2, control.stop).start()
    with pytest.raises(ResearchStopped):
        control.checkpoint()
