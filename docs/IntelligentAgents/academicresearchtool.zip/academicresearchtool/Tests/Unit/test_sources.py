"""Unit tests: one function or class at a time, in isolation (no Ollama, no internet).

Section: Scholarly database clients (arXiv, OpenAlex, CORE).

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import asyncio

import httpx
import pytest

from App.sources import ArxivProvider, CoreProvider, OpenAlexProvider
from Tests.Support.retrieval_fakes import ARXIV_XML, CORE_JSON, OPENALEX_JSON


def test_openalex_quality_signals():
    """OpenAlex peer review, venue, publisher and ORCID data are read correctly.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    work = {
        "id": "W1", "display_name": "T", "type": "article", "is_retracted": False,
        "primary_location": {"source": {"display_name": "Science", "type": "journal", "is_core": True, "host_organization_name": "AAAS"}},
        "authorships": [{"author": {"display_name": "A", "orcid": "https://orcid.org/1"}}, {"author": {"display_name": "B", "orcid": None}}],
    }
    r = OpenAlexProvider().parse_work(work, "q")
    assert (r.peer_reviewed, r.established_venue, r.venue, r.publisher, r.verified_authors) == (True, True, "Science", "AAAS", 1)

    work["type"] = "preprint"
    work["primary_location"]["source"]["type"] = "repository"
    assert OpenAlexProvider().parse_work(work, "q").peer_reviewed is False


def test_arxiv_published_version_counts_as_peer_reviewed():
    """An arXiv preprint with a journal reference counts as peer-reviewed.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    xml = """<feed xmlns="http://www.w3.org/2005/Atom" xmlns:arxiv="http://arxiv.org/schemas/atom">
      <entry><id>http://arxiv.org/abs/1</id><title>A</title><arxiv:journal_ref>Phys. Rev. D 1 (2020)</arxiv:journal_ref></entry>
      <entry><id>http://arxiv.org/abs/2</id><title>B</title></entry></feed>"""
    published, preprint = ArxivProvider().parse(xml, "q")
    assert (published.peer_reviewed, published.venue) == (True, "Phys. Rev. D 1 (2020)")
    assert (preprint.peer_reviewed, preprint.publication_type) == (False, "preprint")


def test_core_thesis_is_not_peer_reviewed():
    """A CORE thesis is marked as not peer-reviewed.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    r = CoreProvider().parse_work({"id": 1, "title": "T", "fieldOfStudy": "Thesis", "publisher": "University of York"}, "q")
    assert (r.peer_reviewed, r.publication_type, r.publisher) == (False, "thesis", "University of York")


def test_arxiv_query_syntax():
    """Keywords become arXiv's query syntax (all:term AND all:"phrase").

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    assert ArxivProvider.build_query('sleep "memory consolidation"') == 'all:sleep AND all:"memory consolidation"'
    assert ArxivProvider.build_query('unbalanced "quote') == "all:unbalanced AND all:quote"


def test_arxiv_parse():
    """arXiv's Atom response is read into clean results.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    [r] = ArxivProvider().parse(ARXIV_XML, "planner q")
    assert r.title == "Neural Replay During Sleep"
    assert r.authors == ["Ada Lovelace", "Alan Turing"]
    assert (r.year, r.doi, r.source_id) == (2021, "10.1000/xyz", "2101.00001v2")
    assert r.pdf_url == "https://arxiv.org/pdf/2101.00001v2"
    assert r.query == "planner q"


def test_openalex_parse_rebuilds_abstract_and_strips_doi():
    """OpenAlex abstracts are rebuilt from word positions and DOIs are cleaned.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    results = [r for w in OPENALEX_JSON["results"] if (r := OpenAlexProvider().parse_work(w, "q"))]
    assert len(results) == 1
    assert results[0].abstract == "Sleep helps memory"
    assert results[0].doi == "10.1126/science.1063049"
    assert results[0].citation_count == 512


def test_core_parse_dedupes_authors():
    """CORE's repeated author names ('Gais, Steffen' / 'Steffen Gais') are merged.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    r = CoreProvider().parse_work(CORE_JSON["results"][0], "q")
    assert r.authors == ["Gais, Steffen", "Born, Jan"]
    assert r.url == "https://core.ac.uk/works/42"


def test_provider_retries_rate_limit():
    """A rate-limited request (HTTP 429) is retried.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    calls = []

    def handler(request):
        calls.append(request)
        return httpx.Response(429) if len(calls) == 1 else httpx.Response(200, json=CORE_JSON)

    async def search():
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            return await CoreProvider(api_key="KEY").search(client, "sleep", "sleep", 5)

    results = asyncio.run(search())
    assert len(results) == 1 and len(calls) == 2
    assert calls[0].headers["Authorization"] == "Bearer KEY"


def test_timed_out_database_is_not_retried():
    """A database that timed out isn't retried (it would waste the time limit).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    calls = []

    def handler(request):
        calls.append(request)
        raise httpx.ReadTimeout("slow", request=request)

    async def search():
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            return await CoreProvider().search(client, "q", "q", 5)

    with pytest.raises(httpx.ReadTimeout):
        asyncio.run(search())
    assert len(calls) == 1


def test_queries_are_cleaned_before_searching():
    """Questions become plain keywords: filler words and search syntax removed, phrases kept.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    from App.sources import clean_query

    assert clean_query("How does sleep affect memory consolidation?") == "sleep affect memory consolidation"
    assert clean_query('sleep "memory consolidation"') == 'sleep "memory consolidation"'  # phrases kept whole
    assert clean_query("dark matter* (DM)") == "dark matter DM"  # wildcards and brackets removed
    assert clean_query("Qu'est-ce que la matière noire ?", "fr") == "matière noire"


def test_escape_codes_in_titles_are_decoded():
    """Escape codes in titles (a backslash-u code for an apostrophe) are decoded to the real character.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    r = CoreProvider().parse_work({"id": 1, "title": "Social-Emotional Learning Curricula\\u27s Impact"}, "q")
    assert r.title == "Social-Emotional Learning Curricula's Impact"


def test_arxiv_works_in_every_search_cycle():
    """arXiv searches still work in the 2nd and 3rd search cycles (each cycle runs in a new event loop).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    provider = ArxivProvider(delay=0.05)  # with a delay, requests queue up on arXiv's one-at-a-time lock
    empty = '<feed xmlns="http://www.w3.org/2005/Atom"></feed>'

    async def one_cycle():
        transport = httpx.MockTransport(lambda request: httpx.Response(200, text=empty))
        async with httpx.AsyncClient(transport=transport) as client:
            return await asyncio.gather(*(provider.search(client, f"q{i}", "q", 1) for i in range(3)), return_exceptions=True)

    for _ in range(3):
        assert not any(isinstance(r, Exception) for r in asyncio.run(one_cycle()))


def test_arxiv_status_notes_are_not_venues():
    """'Submitted to …' / 'Prepared for …' aren't publications; 'Accepted in X' keeps the venue X.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    assert ArxivProvider.publication_venue("Submitted to Nature") is None
    assert ArxivProvider.publication_venue("Prepared for the 1994 summer school") is None
    assert ArxivProvider.publication_venue("Accepted for publication in ApJ") == "ApJ"
    assert ArxivProvider.publication_venue("Phys. Rev. D 1 (2020)") == "Phys. Rev. D 1 (2020)"
    xml = """<feed xmlns="http://www.w3.org/2005/Atom" xmlns:arxiv="http://arxiv.org/schemas/atom">
      <entry><id>http://arxiv.org/abs/1</id><title>A</title><arxiv:journal_ref>Submitted to PRL</arxiv:journal_ref></entry></feed>"""
    [result] = ArxivProvider().parse(xml, "q")
    assert result.peer_reviewed is False and result.venue == "arXiv"
