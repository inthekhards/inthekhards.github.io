"""Unit tests: one function or class at a time, in isolation (no Ollama, no internet).

Section: Model connection (Ollama client, streaming, time limits).

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import threading
import time
from types import SimpleNamespace

import httpx
import pytest

from Agents.plan import default_planner_llm
from App import config
from App.control import ResearchStopped, RunControl
from App.llm import OllamaLLM
from App.models import SearchPlan
from Tests.Support.llm_fakes import FakeClient
from Tests.Support.stream_fakes import Stream


def test_stop_cuts_off_a_model_mid_answer():
    """Stop ends a model's answer mid-stream and closes the connection.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    stream = Stream(['{"queries": ', '["a"], ', '"rationale": "r"}'] * 20)
    llm = OllamaLLM()
    llm.client = SimpleNamespace(chat=lambda **kw: stream)
    llm.control = RunControl()
    threading.Timer(0.12, llm.control.stop).start()
    with pytest.raises(ResearchStopped):
        llm.generate_structured("p", SearchPlan)
    assert stream.closed  # the connection is closed, so Ollama stops generating


def test_time_limit_cuts_off_a_long_answer(monkeypatch):
    """An answer that runs past the time limit is cut off.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    import ollama

    stream = Stream(["x"] * 200, delay=0.02)
    monkeypatch.setattr(ollama, "Client", lambda host, timeout: SimpleNamespace(chat=lambda **kw: stream))
    llm = OllamaLLM()
    started = time.monotonic()
    with pytest.raises(httpx.TimeoutException):
        llm.generate_structured("p", SearchPlan, timeout=2.5)
    assert time.monotonic() - started < 3.5 and stream.closed


def test_planner_uses_deepseek_r1_with_thinking():
    """The planner uses DeepSeek R1 with thinking on and DeepSeek's recommended settings.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    llm = default_planner_llm()
    assert llm.model == config.PLANNER_MODEL == "deepseek-r1:8b"
    assert llm.think is True
    assert llm.temperature == 0.6
    assert llm.system_in_prompt is True


def test_r1_settings_are_sent_and_system_prompt_is_merged():
    """R1's settings are sent to Ollama and its instructions go in the user message.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    llm = default_planner_llm()
    llm.client = FakeClient('{"queries": ["a"], "rationale": "r"}', thinking="Let me reason...")

    result = llm.generate_structured("PROMPT", SearchPlan, system="SYSTEM")

    call = llm.client.calls[0]
    assert call["think"] is True
    assert call["options"] == {"temperature": 0.6, "num_ctx": 16384}
    assert call["messages"] == [{"role": "user", "content": "SYSTEM\n\nPROMPT"}]
    assert result.queries == ["a"]
    assert llm.last_thinking == "Let me reason..."


def test_inline_think_block_is_stripped_before_validation():
    """A <think>…</think> block left in an answer is removed before checking the JSON.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    llm = OllamaLLM(model="deepseek-r1:8b")
    llm.client = FakeClient('<think>\nreasoning {not json}\n</think>\n{"queries": ["b"], "rationale": "r"}')

    assert llm.generate_structured("p", SearchPlan).queries == ["b"]


def test_general_model_keeps_system_message_and_temperature_zero():
    """Non-R1 models keep a separate system message and their own settings.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    llm = OllamaLLM()
    llm.client = FakeClient('{"queries": ["c"], "rationale": "r"}')
    llm.generate_structured("PROMPT", SearchPlan, system="SYSTEM")

    call = llm.client.calls[0]
    assert call["messages"][0] == {"role": "system", "content": "SYSTEM"}
    assert call["options"] == {"temperature": 0.0}
    assert call["think"] is None


def test_timeout_creates_a_time_limited_client_and_is_not_retried(monkeypatch):
    """A call with a time limit uses that limit and isn't retried after timing out.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    import httpx
    import ollama

    created = []

    class SlowClient:
        def __init__(self, host, timeout):
            created.append(timeout)

        def chat(self, **kwargs):
            raise httpx.ReadTimeout("too slow")

    monkeypatch.setattr(ollama, "Client", SlowClient)
    llm = OllamaLLM(timeout=300)
    try:
        llm.generate_structured("p", SearchPlan, timeout=42)
    except httpx.TimeoutException:
        pass
    assert len(created) == 2  # the default client, then one call with the time left
    assert 40 < created[1] <= 42


def test_no_time_left_fails_immediately():
    """With no time left, a model call fails immediately without contacting Ollama.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    import httpx
    import pytest

    llm = OllamaLLM()
    llm.client = FakeClient('{"queries": ["a"], "rationale": "r"}')
    with pytest.raises(httpx.TimeoutException):
        llm.generate_structured("p", SearchPlan, timeout=1)
    assert llm.client.calls == []



def test_authorship_notes_are_not_sent_to_the_model():
    """The code's authorship notes (in class comments) are left out of the answer format sent to the model.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    import json

    from App.llm import answer_format
    from App.models import BatchJudgement, ReportDraft, ResearchPlan

    for model in (ResearchPlan, BatchJudgement, ReportDraft):
        sent = answer_format(model)
        assert "Claude Code" not in json.dumps(sent)
        assert sent["description"] and sent["properties"]  # everything else is unchanged
