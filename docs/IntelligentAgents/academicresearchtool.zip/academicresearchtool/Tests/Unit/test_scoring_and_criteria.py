"""Unit tests: one function or class at a time, in isolation (no Ollama, no internet).

Section: Quality scoring, planner criteria and decisions, Ollama status check.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

from datetime import datetime
from types import SimpleNamespace

import httpx

from Agents.plan import default_criteria
from Agents.proc import ProcessingAgent
from App.harvard import HarvardFormatter
from App.llm import OllamaLLM
from App.models import AcceptanceCriteria, RankedResult, RawResult, ResearchState, Source, SufficiencyVerdict
from Tests.Support.harvard_fakes import ACCESSED, source
from Tests.Support.workflow_fakes import PLAN, FakeLLM, make_planner

THIS_YEAR = datetime.now().year


def record(**kw) -> RawResult:
    return RawResult(title="T", source=Source.OPENALEX, query="q", **kw)


# ---- Quality score ---------------------------------------------------------------


def test_quality_score_is_between_0_and_1():
    """The best and worst possible sources score inside 0-1.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    best = record(peer_reviewed=True, established_venue=True, venue="Nature", citation_count=10_000, year=2000,
                  authors=["A", "B"], verified_authors=2)
    worst = record(peer_reviewed=False, citation_count=0, year=2000, authors=["A"], verified_authors=0)
    assert ProcessingAgent.quality(best, 10)[0] == 1.0
    assert 0 <= ProcessingAgent.quality(worst, 0)[0] < 0.25


def test_new_papers_are_not_penalised_for_few_citations():
    """A paper from this year with 0 citations isn't scored as poorly cited.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    new = record(citation_count=0, year=THIS_YEAR)
    old = record(citation_count=0, year=THIS_YEAR - 10)
    assert ProcessingAgent.quality(new, 5)[0] > ProcessingAgent.quality(old, 5)[0]


def test_unknown_signals_score_in_the_middle():
    """Missing information (no peer-review status, citations or ORCID data) is neutral, not bad.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    unknown = ProcessingAgent.quality(record(), 5)[0]
    bad = ProcessingAgent.quality(record(peer_reviewed=False, citation_count=0, year=2000, authors=["A"], verified_authors=0), 5)[0]
    assert unknown > bad


def test_quality_notes_explain_the_score():
    """The notes say why a source is strong (shown to the planner when it reviews).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    notes = ProcessingAgent.quality(
        record(peer_reviewed=True, established_venue=True, venue="Science", citation_count=500, year=THIS_YEAR - 9,
               authors=["A", "B"], verified_authors=1), 7
    )[1]
    assert notes == ["Peer-reviewed", "500 citations (~50/yr)", "Established venue: Science", "1 of 2 authors ORCID-verified"]


# ---- The planner's criteria and decisions ----------------------------------------


def state_with(ranked, criteria: AcceptanceCriteria) -> ResearchState:
    return ResearchState(goal="g", research_plan=PLAN.model_copy(update={"acceptance_criteria": criteria}), ranked_results=ranked)


def ranked_result(year=2020, peer_reviewed=True, quality=0.6) -> RankedResult:
    return RankedResult(title="T", source=Source.OPENALEX, query="q", article_id="x", year=year,
                        peer_reviewed=peer_reviewed, quality_score=quality)


def test_measured_criteria(tmp_path):
    """Article count, peer-reviewed share, average quality and recency are measured in code.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    criteria = AcceptanceCriteria(min_relevant_articles=3, min_peer_reviewed_share=0.5, min_average_quality=0.5,
                                  max_age_years=5, every_subtask_covered=True)
    ranked = [ranked_result(year=THIS_YEAR), ranked_result(year=THIS_YEAR - 20, peer_reviewed=False, quality=0.2)]
    checks = make_planner(FakeLLM(), tmp_path=tmp_path).measure_criteria(state_with(ranked, criteria))
    assert [(c.criterion, c.met, c.detail) for c in checks] == [
        ("At least 3 relevant articles", False, "2 found"),
        ("At least 50% peer-reviewed", True, "50% (1 of 2)"),
        ("Average quality at least 0.50", False, "0.40"),
        ("Most articles from the last 5 years", True, f"1 of 2 published in {THIS_YEAR - 5} or later"),
    ]


def test_criteria_that_need_reading_are_listed_for_the_planner():
    """Subtask coverage and question-specific requirements are judged by the planner model.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    criteria = default_criteria().model_copy(update={"other_requirements": ["Includes a meta-analysis"]})
    assert criteria.judged() == ["Every subtask has supporting evidence", "Includes a meta-analysis"]


def test_routing_after_review(tmp_path):
    """Search again only if the results aren't acceptable, cycles remain, and there is time.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    planner = make_planner(FakeLLM(), tmp_path=tmp_path)
    route = planner.route_after_evaluation
    assert route(ResearchState(goal="g", sufficient=True, iteration_count=1)) == "approve"
    assert route(ResearchState(goal="g", sufficient=False, iteration_count=1)) == "plan"
    assert route(ResearchState(goal="g", sufficient=False, iteration_count=3)) == "approve"
    assert route(ResearchState(goal="g", sufficient=False, iteration_count=1, out_of_time=True)) == "approve"


def test_approval_records_why(tmp_path):
    """The approval says 'approved' when criteria are met and 'best available' otherwise.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    planner = make_planner(FakeLLM(), tmp_path=tmp_path)
    ok = planner.approve_results(ResearchState(goal="g", sufficient=True, evaluation=SufficiencyVerdict(sufficient=True, reason="Good."), iteration_count=1))
    weak = planner.approve_results(ResearchState(goal="g", sufficient=False, iteration_count=3,
                                                 evaluation=SufficiencyVerdict(sufficient=False, reason="r", gaps=["No reviews"])))
    assert (ok["planner_approval"].status, ok["planner_approval"].reason) == ("approved", "Good.")
    assert weak["planner_approval"].status == "best_available" and "No reviews" in weak["planner_approval"].reason


# ---- More reference types --------------------------------------------------------


def test_book_and_book_chapter_references():
    """Books have an italic title and publisher; chapters say 'in' the italic book title.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    book = source("Thinking, fast and slow", ["Daniel Kahneman"], year=2011, publication_type="book",
                  publisher="Farrar, Straus and Giroux", doi="10.1/book")
    chapter = source("Memory systems", ["Larry Squire"], year=2004, publication_type="book-chapter",
                     venue="The Cognitive Neurosciences", pages="691–702")
    h = HarvardFormatter([book, chapter], ACCESSED)
    assert h.reference(0) == "Kahneman, D. (2011) *Thinking, fast and slow*. Farrar, Straus and Giroux. doi: 10.1/book."
    assert h.reference(1) == "Squire, L. (2004) 'Memory systems', in *The Cognitive Neurosciences*, pp. 691–702."


def test_reference_without_authors_starts_with_the_title():
    """Sources with no listed authors are cited by title.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    s = source("Annual report on sleep", [], year=2020, url="https://example.org/report")
    h = HarvardFormatter([s], ACCESSED)
    assert h.reference(0).startswith("*Annual report on sleep* (2020).")
    assert h.in_text(0) == "'Annual report on sleep', 2020"


# ---- Ollama status check -------------------------------------------------------------


def test_status_check_reports_each_problem():
    """The status line says whether Ollama is running and whether the model is installed.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    llm = OllamaLLM(model="qwen3.5:9b")

    llm.client = SimpleNamespace(list=lambda: (_ for _ in ()).throw(httpx.ConnectError("refused")))
    ok, message = llm.check_health()
    assert not ok and "Is the Ollama app running?" in message

    llm.client = SimpleNamespace(list=lambda: SimpleNamespace(models=[SimpleNamespace(model="llama3.1:8b")]))
    ok, message = llm.check_health()
    assert not ok and message.endswith("Run: ollama pull qwen3.5:9b")

    llm.client = SimpleNamespace(list=lambda: SimpleNamespace(models=[SimpleNamespace(model="qwen3.5:9b")]))
    assert llm.check_health() == (True, "Ollama ready · model qwen3.5:9b")
