"""Unit tests: one function or class at a time, in isolation (no Ollama, no internet).

Section: Agent activity logs.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

from types import SimpleNamespace

import httpx
import pytest

from App.activity_log import ActivityLog
from App.llm import OllamaLLM
from App.models import SearchPlan
from Tests.Support.stream_fakes import Stream


def test_each_agent_gets_its_own_log_named_like_the_journal(tmp_path):
    """Logs go to Agents/Logs/<Agent>/<run>.log, one per agent, named after the run's journal.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    log = ActivityLog("2026-10-04_19-30-00", tmp_path)
    log.write("Planner Agent", "Planned the research.")
    log.write("Retrieval Agent", "Searched the databases.")
    assert sorted(p.relative_to(tmp_path).as_posix() for p in tmp_path.rglob("*.log")) == [
        "Planner/2026-10-04_19-30-00.log", "Retrieval/2026-10-04_19-30-00.log",
    ]
    assert sorted(p.name for p in tmp_path.iterdir()) == ["Planner", "Processing", "Retrieval", "Storage"]


def test_log_lines_are_timestamped_with_a_level(tmp_path):
    """Each line starts with the date, time and level; long messages continue on indented lines.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    log = ActivityLog("run", tmp_path)
    log.write("Storage Agent", "First line\nsecond line", "WARN")
    first, second = (tmp_path / "Storage" / "run.log").read_text().splitlines()
    assert first[:4].isdigit() and "  WARN   First line" in first
    assert second.strip() == "second line" and second.startswith(" " * 28)


def test_unknown_agent_names_are_ignored(tmp_path):
    """Writing for an agent that doesn't exist does nothing (and doesn't crash).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    ActivityLog("run", tmp_path).write("Nobody", "hello")
    assert not list(tmp_path.rglob("*.log"))


class Client:
    def __init__(self, stream=None, error=None):
        self.stream, self.error = stream, error

    def chat(self, **kwargs):
        if self.error:
            raise self.error
        return self.stream


def model_with_log(client) -> tuple[OllamaLLM, list]:
    lines = []
    llm = OllamaLLM(model="qwen3.5:9b")
    llm.client = client
    llm.log = lambda message, level="INFO": lines.append((level, message))
    return llm, lines


def test_successful_model_calls_are_logged():
    """A model answer is logged with the model, the request type and how long it took.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    llm, lines = model_with_log(Client(Stream(['{"queries": ["a"], "rationale": "r"}'], delay=0)))
    llm.generate_structured("p", SearchPlan)
    level, message = lines[-1]
    assert level == "INFO" and message.startswith("Model qwen3.5:9b (SearchPlan): answered in")


def test_failed_and_retried_model_calls_are_logged():
    """Retries are logged as warnings and a final failure as an error.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    llm, lines = model_with_log(Client(error=httpx.ConnectError("refused")))
    with pytest.raises(httpx.ConnectError):
        llm.generate_structured("p", SearchPlan)
    assert [level for level, _ in lines] == ["WARN", "WARN", "ERROR"]
    assert "attempt 1 failed (ConnectError); trying again" in lines[0][1]
    assert "failed after" in lines[-1][1] and "ConnectError" in lines[-1][1]


def test_timeouts_are_logged(monkeypatch):
    """A model that runs out of time is logged as a warning with the time limit.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    import ollama

    monkeypatch.setattr(ollama, "Client", lambda host, timeout: SimpleNamespace(chat=lambda **kw: Stream(["x"] * 200, delay=0.02)))
    llm, lines = model_with_log(None)
    with pytest.raises(httpx.TimeoutException):
        llm.generate_structured("p", SearchPlan, timeout=2.5)
    assert lines[-1][0] == "WARN" and "ran out of time" in lines[-1][1] and "time limit 2 s" in lines[-1][1]
