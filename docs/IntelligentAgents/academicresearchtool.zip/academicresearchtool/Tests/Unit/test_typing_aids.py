"""Unit tests: one function or class at a time, in isolation (no Ollama, no internet).

Section: Spell check, autocorrect and autofill.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

from collections import Counter

import pytest

from App.typing_aids import TypingAssistant
from Tests.Support.typing_fakes import QUESTIONS


def test_finds_misspellings_but_not_acronyms_names_or_research_words(assistant):
    """Misspellings are found; acronyms, names and research words are not flagged.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    text = "How does sleep afect memroy and neuroplasticity in SEL, according to Piaget?"
    assert [w for _, _, w in assistant.misspelled(text)] == ["afect", "memroy"]


@pytest.mark.parametrize("typo, fixed", [("memroy", "memory"), ("afect", "affect"), ("teh", "the"),
                                         ("adolescnts", "adolescents"), ("elementery", "elementary")])
def test_clear_typos_are_autocorrected(assistant, typo, fixed):
    """Clear typos are autocorrected.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    assert assistant.autocorrection(typo) == fixed


@pytest.mark.parametrize("word", ["sel", "SEL", "Piaget", "neuroplasticity", "memory", "covid19"])
def test_words_that_are_never_autocorrected(assistant, word):
    """Acronyms, names, known terms and words with digits are never autocorrected.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    assert assistant.autocorrection(word) is None


def test_suggestions_for_right_click(assistant):
    """Right-click suggestions put the most likely correction first.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    assert assistant.suggestions("consolidaton")[0] == "consolidation"


def test_autofill_suggests_past_questions_then_words(assistant):
    """Autofill suggests past questions first, then common words.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    assert assistant.completion("Find me res") == QUESTIONS[0][len("Find me res"):]
    assert assistant.completion("How does sle") == "ep"
    assert assistant.completion("ab") is None  # too short to guess


def test_added_words_are_no_longer_flagged(assistant):
    """'Add to dictionary' stops a word being flagged.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    assert assistant.is_misspelled("metacognition")
    assistant.add_word("metacognition")
    assert not assistant.is_misspelled("metacognition")


def test_other_languages_use_their_own_dictionary():
    """Other research languages use their own dictionary.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    french = TypingAssistant("fr", questions=[], vocabulary=Counter())
    assert not french.is_misspelled("mémoire") and french.autocorrection("mémoir") == "mémoire"
