"""Unit tests: one function or class at a time, in isolation (no Ollama, no internet).

Section: Retrieval agent.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import re

import httpx

from Agents import ret
from Agents.ret import RetrievalAgent
from App.journal import JournalStore
from App.models import (
    ProviderQueries,
    QueryTranslation,
    RawResult,
    ResearchState,
    Source,
)
from App.sources import ArxivProvider, CoreProvider, OpenAlexProvider
from Tests.Support.retrieval_fakes import ScriptedQwen, api_handler


def test_retrieval_never_keeps_foreign_results(tmp_path, monkeypatch):
    """Results in other languages or scripts never enter the journal.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    from Agents.ret import RetrievalAgent
    from App.journal import JournalStore
    from App.models import ResearchState

    class Provider:
        source = Source.OPENALEX

        async def search(self, client, query, planner_query, limit, language=None):
            return [
                RawResult(title="Social and emotional learning in schools", authors=["Ann Smith"], source=self.source, query=planner_query, language="en"),
                RawResult(title="Integrating SEL", authors=["Наталія Павлущенко"], source=self.source, query=planner_query, language="en"),
                RawResult(title="Apprentissage socio-émotionnel à l'école", source=self.source, query=planner_query, language="fr"),
            ]

    class Down:
        model = "x"

        def generate_structured(self, *a, **k):
            raise httpx.ConnectError("down")

    agent = RetrievalAgent(llm=Down(), providers=[Provider()], journal_store=JournalStore(tmp_path))
    update = agent.run(ResearchState(goal="g", search_queries=["social emotional learning"], iteration_count=1))

    journal = JournalStore().load(update["journal_path"])
    assert [r.title for r in journal.all_raw_results()] == ["Social and emotional learning in schools"]
    assert journal.cycles[0].searches[0].filtered_out == 2
    assert any("Dropped 2 results not fully in English" in e.message for e in update["activity_log"])


def test_databases_are_filtered_to_the_language(tmp_path, monkeypatch):
    """OpenAlex and CORE are filtered to the research language; arXiv is English-only.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    sent = []

    def handler(request):
        sent.append(request)
        return httpx.Response(200, json={"results": []})

    monkeypatch.setattr(ret, "make_http_client", lambda: httpx.AsyncClient(transport=httpx.MockTransport(handler)))

    class Down:
        model = "q"

        def generate_structured(self, *a, **k):
            raise httpx.ConnectError("down")

    agent = RetrievalAgent(
        llm=Down(), providers=[ArxivProvider(delay=0), OpenAlexProvider(api_key=None), CoreProvider(api_key=None)],
        journal_store=JournalStore(tmp_path),
    )
    update = agent.run(ResearchState(goal="g", search_queries=["matière noire"], iteration_count=1, language="fr"))

    hosts = [r.url.host for r in sent]
    assert not any("arxiv" in h for h in hosts)  # arXiv is English-only
    openalex = next(r for r in sent if "openalex" in r.url.host)
    core = next(r for r in sent if "core" in r.url.host)
    assert openalex.url.params["filter"] == "language:fr"
    assert core.url.params["q"] == "(matière noire) AND language.code:fr"
    assert any("Not searching arXiv" in e.message for e in update["activity_log"])


def test_qwen_queries_are_sent_and_journal_written(agent_factory):
    """Qwen's rewritten queries are sent to each database and every search is recorded.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    qwen = ScriptedQwen(
        QueryTranslation(
            translations=[
                ProviderQueries(planner_query="sleep memory", arxiv=None, openalex='"sleep" memory', core="sleep memory consolidation"),
            ]
        )
    )
    sent = []

    def handler(request):
        sent.append((request.url.host, dict(request.url.params)))
        return api_handler(request)

    agent = agent_factory(qwen, handler)
    update = agent.run(ResearchState(goal="sleep and memory", search_queries=["sleep memory"], iteration_count=1))

    hosts = {host for host, _ in sent}
    assert not any("arxiv" in h for h in hosts)  # Qwen said arXiv doesn't cover this
    assert ('api.openalex.org', 'sleep memory') in {(h, p.get("search")) for h, p in sent}  # quotes on one word dropped
    assert "<query>sleep memory</query>" in qwen.prompts[0]

    path = update["journal_path"]
    assert re.fullmatch(r"\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}\.json", path.rsplit("/", 1)[-1])
    journal = JournalStore().load(path)
    assert journal.goal == "sleep and memory"
    assert [s.source for s in journal.cycles[0].searches] == [Source.ARXIV, Source.OPENALEX, Source.CORE]
    assert journal.cycles[0].searches[0].provider_query is None
    assert journal.cycles[0].model == "qwen3.5:9b"

    report = update["retrieval_report"]
    assert report.status == "complete"
    assert report.results_by_source == {"arxiv": 0, "openalex": 1, "core": 1}
    assert update["query_hits"] == {"sleep memory": 2}


def test_falls_back_to_planner_queries_when_qwen_fails(agent_factory):
    """If Qwen fails, the planner's queries are sent unchanged.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    agent = agent_factory(ScriptedQwen(error=httpx.ConnectError("down")))
    update = agent.run(ResearchState(goal="g", search_queries=["neural networks"], iteration_count=1))

    assert update["retrieval_report"].results_by_source == {"arxiv": 1, "openalex": 1, "core": 1}
    assert any("unchanged" in e.message for e in update["activity_log"])


def test_failing_provider_is_recorded_not_fatal(agent_factory):
    """One database failing is recorded; the others' results are kept.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    def handler(request):
        return httpx.Response(403) if "core" in request.url.host else api_handler(request)

    agent = agent_factory(ScriptedQwen(error=httpx.ConnectError("down")), handler)
    update = agent.run(ResearchState(goal="g", search_queries=["q"], iteration_count=1))

    report = update["retrieval_report"]
    assert report.status == "complete"
    assert report.errors == ["core · q: HTTP 403"]
    core_record = JournalStore().load(update["journal_path"]).cycles[0].searches[2]
    assert core_record.error == "HTTP 403"


def test_all_providers_failing_reports_failed(agent_factory):
    """If every database fails, the retrieval report says 'failed'.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    agent = agent_factory(ScriptedQwen(error=httpx.ConnectError("down")), lambda r: httpx.Response(403))
    update = agent.run(ResearchState(goal="g", search_queries=["q"], iteration_count=1))
    assert update["retrieval_report"].status == "failed"


def test_later_cycles_append_to_same_journal(agent_factory):
    """Later search cycles are added to the same journal.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    agent = agent_factory(ScriptedQwen(error=httpx.ConnectError("down")))
    first = agent.run(ResearchState(goal="g", search_queries=["a"], iteration_count=1))
    second = agent.run(
        ResearchState(goal="g", search_queries=["b"], iteration_count=2, journal_path=first["journal_path"])
    )

    assert second["journal_path"] == first["journal_path"]
    journal = JournalStore().load(first["journal_path"])
    assert [c.iteration for c in journal.cycles] == [1, 2]
    assert second["retrieval_report"].total_results == 6


def test_article_limit_is_shared_fairly(agent_factory):
    """The article limit is shared across databases and queries.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    from App.budget import scope_limits

    def handler(request):
        if "openalex" in request.url.host:
            n = int(request.url.params["per_page"])
            return httpx.Response(200, json={"results": [{"id": f"W{i}", "display_name": f"OA {i}"} for i in range(n)]})
        return api_handler(request)

    agent = agent_factory(ScriptedQwen(error=httpx.ConnectError("down")), handler)
    update = agent.run(ResearchState(goal="g", search_queries=["a", "b"], iteration_count=1, limits=scope_limits("general")))

    report = update["retrieval_report"]
    assert report.new_results == 8  # arXiv and CORE return 1 each per query; OpenAlex 2 each (ceil(10 / 6))
    assert report.results_by_source == {"arxiv": 2, "openalex": 2 * 2, "core": 2}


def test_interleave_takes_best_of_each_search_first():
    """Each search's best result is taken first when trimming to the limit.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    from App.models import RawResult

    def r(t):
        return RawResult(title=t, source=Source.CORE, query="q")

    picked = RetrievalAgent.interleave([[r("a1"), r("a2"), r("a3")], [r("b1")], [r("c1"), r("c2")]], 4)
    assert [x.title for x in picked] == ["a1", "b1", "c1", "a2"]


def test_short_on_time_skips_query_rewriting(agent_factory):
    """When short on time, retrieval skips the model and searches straight away.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    import time as clock

    qwen = ScriptedQwen(error=AssertionError("should not be called"))
    agent = agent_factory(qwen)
    agent.deadline = clock.monotonic() + 20  # enough for the searches, not for the model too
    update = agent.run(ResearchState(goal="g", search_queries=["q"], iteration_count=1))

    assert qwen.prompts == []
    assert any("Short on time" in e.message for e in update["activity_log"])
    assert update["retrieval_report"].new_results == 3


def test_wildcards_never_reach_openalex(agent_factory):
    """'?' and '*' are removed so OpenAlex never rejects a query.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    sent = []

    def handler(request):
        sent.append(request)
        return api_handler(request)

    agent = agent_factory(ScriptedQwen(error=httpx.ConnectError("down")), handler)
    agent.run(ResearchState(goal="g", search_queries=["What is dark matter?"], iteration_count=1))

    openalex = next(r for r in sent if "openalex" in r.url.host)
    core = next(r for r in sent if "core" in r.url.host)
    assert openalex.url.params["search"] == "dark matter"
    assert core.url.params["q"] == "(dark matter) AND language.code:en"
