"""Unit tests: one function or class at a time, in isolation (no Ollama, no internet).

Section: Storage agent.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

from datetime import datetime

import pytest

from Agents.sto import StorageAgent, _slugify, fallback_title
from App.journal import JournalStore
from App.models import (
    FinalResults,
    PlannerApproval,
    RankedResult,
    ResearchState,
    Source,
)
from Tests.Support.storage_fakes import Broken, Recorder, journal_with_final, ranked
from Tests.Support.workflow_fakes import FakeLLM, make_planner


def test_french_report_headings_and_harvard_wording(tmp_path):
    """A French report uses French headings, Harvard wording and dates.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    sources = [
        RankedResult(title="La matière noire", authors=["Marie Curie", "Pierre Curie"], year=None, source=Source.CORE,
                     query="q", article_id="a", url="https://core.ac.uk/works/1", summary="Une revue.")
    ]
    final = FinalResults(
        planner_approval=PlannerApproval(status="approved", search_cycles=1, reason="ok"),
        goal="Qu'est-ce que la matière noire ?", language="fr", ranked_results=sources,
        written_at=datetime(2026, 10, 4, 12, 0),
    )
    agent = StorageAgent(llm=None, results_dir=tmp_path)
    text = agent.render(agent.fallback_draft(final), final)

    for heading in ("## Aperçu", "## Principaux résultats", "## Sources classées", "## Bibliographie"):
        assert heading in text
    assert "Curie, M. et Curie, P. (sans date) *La matière noire*. Disponible à l'adresse: https://core.ac.uk/works/1 " \
           "(Consulté le: 4 octobre 2026)." in text
    assert "(Curie et Curie, sans date)" in text


def test_file_names_drop_accents():
    """Report file names drop accents ('matière' → 'matiere').

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    assert _slugify("La matière noire : une énigme") == "la-matiere-noire-une-enigme"


def test_fallback_title_comes_from_the_question():
    """Without a model, the report title comes from the question.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    assert fallback_title("does sleep help memory?") == "Does sleep help memory"


def test_report_name_comes_from_title_and_never_overwrites(tmp_path):
    """The file is named after the title and never overwrites an earlier report.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    agent = StorageAgent(llm=Broken(), results_dir=tmp_path)
    first = agent.report_path("Sleep & Memory: A Review")
    first.write_text("x")
    assert first.name == "sleep-memory-a-review.md"
    assert agent.report_path("Sleep & Memory: A Review").name == "sleep-memory-a-review-2.md"


def test_fallback_report_when_model_is_unavailable(tmp_path):
    """If the storage model is unavailable, a report is still written from the sources' descriptions.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    path = journal_with_final(tmp_path, ranked(3))
    agent = StorageAgent(llm=Broken(), results_dir=tmp_path / "reports", journal_store=JournalStore(tmp_path))
    update = agent.run(ResearchState(goal="Does sleep help memory?", journal_path=path, storage_authorized=True))

    report = open(update["report_path"], encoding="utf-8").read()
    assert update["report_path"].endswith("does-sleep-help-memory.md")
    assert "- Finding 1 (Lovelace, 2021)." in report
    assert "1. Lovelace, A. (2021) 'Paper 1', *Journal X*. doi: 10.1/1." in report
    assert "synthesis" not in report.lower() and "model" not in report.lower()
    assert any("Synthesis model unavailable" in e.message for e in update["activity_log"])


def test_no_results_report_skips_the_model(tmp_path):
    """With no results, a short 'nothing found' report is written without calling the model.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    path = journal_with_final(tmp_path, [])
    agent = StorageAgent(llm=Broken(), results_dir=tmp_path / "reports", journal_store=JournalStore(tmp_path))
    update = agent.run(ResearchState(goal="g", journal_path=path, storage_authorized=True))
    assert "No relevant academic sources were found" in open(update["report_path"], encoding="utf-8").read()


def test_short_on_time_turns_thinking_off(tmp_path):
    """With under 90 s left, the storage model writes without its thinking phase.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    import time as clock

    path = journal_with_final(tmp_path, ranked(2))
    writer = Recorder()
    agent = StorageAgent(llm=writer, results_dir=tmp_path / "reports", journal_store=JournalStore(tmp_path))
    agent.deadline = clock.monotonic() + 60
    agent.run(ResearchState(goal="g", journal_path=path, storage_authorized=True))

    assert writer.calls[0]["think"] is False and 55 < writer.calls[0]["timeout"] <= 60


def test_nearly_out_of_time_writes_summary_report_without_model(tmp_path):
    """With under 25 s left, the report is written without the model.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    import time as clock

    path = journal_with_final(tmp_path, ranked(2))
    writer = Recorder()
    agent = StorageAgent(llm=writer, results_dir=tmp_path / "reports", journal_store=JournalStore(tmp_path))
    agent.deadline = clock.monotonic() + 10
    update = agent.run(ResearchState(goal="g", journal_path=path, storage_authorized=True))

    assert writer.calls == []
    assert "- Finding 1 (Lovelace, 2021)." in open(update["report_path"], encoding="utf-8").read()


def test_storage_refuses_without_planner_authorisation(tmp_path):
    """The storage agent refuses to write unless the planner has authorised it.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    from App.models import ResearchState

    planner = make_planner(FakeLLM(), tmp_path=tmp_path)
    with pytest.raises(RuntimeError, match="not authorised storage"):
        planner.storage.run(ResearchState(goal="g", journal_path=str(tmp_path / "x.json")))


def test_storage_refuses_when_journal_has_no_final_results(tmp_path):
    """The storage agent refuses to write if the journal has no FINAL RESULTS.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    from App.models import ResearchState

    planner = make_planner(FakeLLM(), tmp_path=tmp_path)
    path = JournalStore(tmp_path).create("g")
    with pytest.raises(RuntimeError, match='No "FINAL RESULTS"'):
        planner.storage.run(ResearchState(goal="g", journal_path=str(path), storage_authorized=True))
