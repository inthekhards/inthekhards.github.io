"""Unit tests: one function or class at a time, in isolation (no Ollama, no internet).

Section: Reading the requested number of articles.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import pytest

from App.question import requested_article_count


@pytest.mark.parametrize(
    "question, expected",
    [
        ("Find me research on social and emotional learning in elementary school. Limit it to 5 articles.", 5),
        ("Give me the top three papers on dark matter", 3),
        ("I need 7 peer-reviewed studies about sleep", 7),
        ("no more than 4 sources on climate anxiety", 4),
        ("Trouve cinq articles sur la matière noire", 5),
        ("What is dark matter?", None),
        ("Effects of COVID-19 on schools in 2020", None),
        ("How did World War 2 affect literacy?", None),
        ("Summarise 10 years of research on bilingualism", None),
        ("Résume une étude sur le sommeil", None),  # "une" here means "a", not "one"
        ("Find research on SEL. Limit it to 5.", 5),
        ("Does getting only 5 hours of sleep affect memory?", None),
        ("Research on students at the top 10 universities", None),
        ("Effects of at most 2 cups of coffee a day", None),
        ("Children up to 5 years old and language learning", None),
    ],
)
def test_requested_article_count(question, expected):
    """The number of articles asked for is read from the question; other numbers are ignored.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    assert requested_article_count(question) == expected
