"""Unit tests: one function or class at a time, in isolation (no Ollama, no internet).

Section: Harvard (Cite Them Right) referencing.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

from datetime import date

from App.harvard import HarvardFormatter, parse_name
from App.models import (
    RankedResult,
    Source,
)
from Tests.Support.harvard_fakes import ACCESSED, source


def test_name_parsing():
    """Author names become 'Surname, I.' (particles, hyphens, capitals, stray initials, 'Surname, First').

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    assert (parse_name("Gianfranco Bertone").surname, parse_name("Gianfranco Bertone").initials) == ("Bertone", "G.")
    assert parse_name("Douglas P. Finkbeiner").reference_form == "Finkbeiner, D.P."
    assert parse_name("Gais, Steffen").reference_form == "Gais, S."
    assert parse_name("Nima Arkani-hamed A").reference_form == "Arkani-Hamed, N."  # stray initial, lower-case part
    assert parse_name("Johannes van der Waals").reference_form == "van der Waals, J."
    assert parse_name("Jean-Paul Sartre").reference_form == "Sartre, J.-P."
    assert parse_name("SMITH, JOHN").reference_form == "Smith, J."
    assert parse_name("Global Argon Dark Matter Collaboration").reference_form == "Global Argon Dark Matter Collaboration"
    assert parse_name("The XENON Collaboration").reference_form == "XENON Collaboration"


def test_journal_article_reference():
    """A journal article is formatted as in the Design Proposal: authors (year) 'title', *journal*, vol(issue), pages. doi.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    s = source(
        "History of dark matter.", ["Gianfranco Bertone", "Dan Hooper"], venue="Reviews of Modern Physics",
        volume="90", issue="4", pages="045002", doi="10.1103/revmodphys.90.045002", peer_reviewed=True,
    )
    assert HarvardFormatter([s], ACCESSED).reference(0) == (
        "Bertone, G. and Hooper, D. (2018) 'History of dark matter', *Reviews of Modern Physics*, 90(4), 045002. "
        "doi: 10.1103/revmodphys.90.045002."
    )


def test_page_ranges_use_pp():
    """Page ranges are written 'pp. 187–212'.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    s = source("A theory", ["A Smith"], venue="J", volume="12", pages="187–212")
    assert "*J*, 12, pp. 187–212." in HarvardFormatter([s], ACCESSED).reference(0)


def test_preprint_reference_matches_design_doc_style():
    """A preprint reads 'arXiv [Preprint]. Available at: … (Accessed: …)'.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    s = source(
        "OpenAlex: a fully-open index", ["Jason Priem", "Heather Piwowar", "Richard Orr"], year=2022,
        source=Source.ARXIV, venue="arXiv", peer_reviewed=False, publication_type="preprint",
        doi="10.48550/arXiv.2205.01833",
    )
    assert HarvardFormatter([s], ACCESSED).reference(0) == (
        "Priem, J., Piwowar, H. and Orr, R. (2022) 'OpenAlex: a fully-open index', arXiv [Preprint]. "
        "Available at: https://doi.org/10.48550/arXiv.2205.01833 (Accessed: 4 October 2026)."
    )


def test_thesis_reference():
    """A thesis has an italic title, 'Thesis', the institution and an accessed date.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    s = source("Sleep and memory in adolescents", ["Jane Doe"], year=2019, publication_type="thesis",
               publisher="University of York", url="https://core.ac.uk/works/1")
    assert HarvardFormatter([s], ACCESSED).reference(0) == (
        "Doe, J. (2019) *Sleep and memory in adolescents*. Thesis. University of York. "
        "Available at: https://core.ac.uk/works/1 (Accessed: 4 October 2026)."
    )


def test_in_text_citations_follow_cite_them_right():
    """In-text citations name up to 3 authors and use 'et al.' for 4 or more.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    sources = [
        source("One", ["Ann Smith"]),
        source("Two", ["Ann Smith", "Bob Jones"]),
        source("Three", ["Ann Smith", "Bob Jones", "Cy Brown"]),
        source("Four", ["Ann Smith", "Bob Jones", "Cy Brown", "Di Green"], year=None),
    ]
    h = HarvardFormatter(sources, ACCESSED)
    assert [h.in_text(i) for i in range(4)] == [
        "Smith, 2018", "Smith and Jones, 2018", "Smith, Jones and Brown, 2018", "Smith et al., no date",
    ]


def test_same_authors_same_year_get_letters():
    """Same authors, same year get 2018a / 2018b.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    h = HarvardFormatter([source("Zebra study", ["Ann Smith"]), source("Apple study", ["Ann Smith"])], ACCESSED)
    assert [h.in_text(0), h.in_text(1)] == ["Smith, 2018b", "Smith, 2018a"]  # lettered by title
    assert "(2018b)" in h.reference(0)


def test_numbered_citations_become_harvard():
    """[1] or [2, 5] become (Smith, 2018; Jones, 2020); invented numbers are removed.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    h = HarvardFormatter([source("One", ["Ann Smith"]), source("Two", ["Bob Jones"], year=2020)], ACCESSED)
    assert h.convert_citations("Sleep helps [1]. Both agree [1, 2]. Also [2][1]. Bad [7].") == (
        "Sleep helps (Smith, 2018). Both agree (Smith, 2018; Jones, 2020). Also (Jones, 2020; Smith, 2018). Bad."
    )
    assert h.convert_citations("Range [1-2] works") == "Range (Smith, 2018; Jones, 2020) works"


def test_reference_list_is_alphabetical_and_ranked_list_keeps_rank():
    """The reference list is alphabetical; the ranked list keeps rank order.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    sources = [source("Best", ["Zoe Young"]), source("Second", ["Adam Able"]), source("Third", ["Mia Moore"])]
    h = HarvardFormatter(sources, ACCESSED)
    assert [r.split(",")[0] for r in h.ranked_references()] == ["Young", "Able", "Moore"]
    assert [r.split(",")[0] for r in h.alphabetical_references()] == ["Able", "Moore", "Young"]


def test_very_long_author_lists_use_et_al():
    """More than 10 authors become 'First, A. et al.' in the reference list.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    s = source("Big collaboration", [f"Person {chr(65 + i)} Name{i}" for i in range(12)], venue="J")
    assert HarvardFormatter([s], ACCESSED).reference(0).startswith("Name0, P.A. et al. (2018)")


def test_english_dates_and_words_are_unchanged():
    """English references use 'Available at' and 'Accessed: 4 October 2026'.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    s = RankedResult(title="T", authors=["Ann Smith"], year=2020, source=Source.CORE, query="q", article_id="t", url="https://x.org")
    assert HarvardFormatter([s], date(2026, 10, 4)).reference(0).endswith("Available at: https://x.org (Accessed: 4 October 2026).")


def test_surnames_that_look_like_particles_keep_their_capital():
    """'Du', 'De' as whole surnames stay capitalised; particles before a surname stay lower-case.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    assert parse_name("Ning Du").reference_form == "Du, N."
    assert parse_name("Luis De").reference_form == "De, L."
    assert parse_name("Marie du Pont").reference_form == "du Pont, M."
    h = HarvardFormatter([source("Axion search", ["Ning Du", "A", "B", "C"], year=2018)], ACCESSED)
    assert h.in_text(0) == "Du et al., 2018"
