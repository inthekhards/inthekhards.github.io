"""Unit tests: one function or class at a time, in isolation (no Ollama, no internet).

Section: Model choices and settings.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

from App.model_catalog import make_llm, profile
from App.models import (
    SearchPlan,
)


def test_defaults_are_deepseek_for_planning_and_qwen_for_the_rest():
    """Default models: DeepSeek R1 plans; Qwen 3.5 retrieves, processes and writes.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    assert [make_llm(r).model for r in ("planner", "retrieval", "processing", "storage")] == [
        "deepseek-r1:8b", "qwen3.5:9b", "qwen3.5:9b", "qwen3.5:9b",
    ]


def test_each_model_gets_its_own_settings():
    """Each model gets suitable settings (thinking, temperature, instruction style).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    r1 = make_llm("planner", "deepseek-r1:8b")
    assert (r1.think, r1.system_in_prompt, r1.temperature) == (True, True, 0.6)
    llama = make_llm("planner", "llama3.1:8b")
    assert llama.think is None  # Llama 3.1 has no thinking phase: never ask it to think
    assert make_llm("processing", "gemma4:e4b").temperature == 0.2
    assert profile("someone/custom:7b").can_think is None


def test_models_without_thinking_ignore_the_think_override():
    """Models without a thinking phase (Llama) are never asked to think.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    class Client:
        calls = []

        def chat(self, **kwargs):
            self.calls.append(kwargs)
            from types import SimpleNamespace

            return iter([SimpleNamespace(message=SimpleNamespace(content='{"queries": ["a"], "rationale": "r"}', thinking=None))])

    llm = make_llm("storage", "llama3.1:8b")
    llm.client = Client()
    llm.generate_structured("p", SearchPlan, think=False)
    assert llm.client.calls[0]["think"] is None


def test_only_local_models_are_allowed():
    """Cloud models are refused; the menu only lists local models.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    import pytest

    from App.model_catalog import CATALOG, is_cloud_model

    assert not any(is_cloud_model(option.tag) for option in CATALOG)
    assert is_cloud_model("kimi-k3:cloud") and is_cloud_model("gpt-oss:120b-cloud")
    with pytest.raises(ValueError, match="Only local models"):
        make_llm("planner", "kimi-k3:cloud")
