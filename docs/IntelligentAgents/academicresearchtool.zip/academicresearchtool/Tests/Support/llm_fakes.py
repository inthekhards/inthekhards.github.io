"""A fake Ollama client that streams a scripted answer.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

from types import SimpleNamespace


class FakeClient:
    def __init__(self, content: str, thinking: str | None = None):
        self.content = content
        self.thinking = thinking
        self.calls: list[dict] = []

    def chat(self, **kwargs):
        """Streams the answer in two pieces, like Ollama does with stream=True.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        self.calls.append(kwargs)
        half = len(self.content) // 2
        return iter([
            SimpleNamespace(message=SimpleNamespace(content=self.content[:half], thinking=self.thinking)),
            SimpleNamespace(message=SimpleNamespace(content=self.content[half:], thinking=None)),
        ])
