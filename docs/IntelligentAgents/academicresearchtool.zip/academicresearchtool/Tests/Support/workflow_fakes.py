"""Stand-ins for a whole research run: a scripted planner model, a fake database, scripted retrieval/processing/storage models, and a planner built from them.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

from Agents.plan import PlannerAgent
from Agents.ret import RetrievalAgent
from App.journal import JournalStore
from App.models import (
    AcceptanceCriteria,
    ArticleJudgement,
    BatchJudgement,
    QueryTranslation,
    RawResult,
    ReportDraft,
    ReportFindings,
    ResearchPlan,
    ResearchSubtask,
    SearchPlan,
    Source,
    SufficiencyVerdict,
)

PLAN = ResearchPlan(
    objective="Understand how sleep affects memory consolidation.",
    scope="detailed",
    scope_reason="A specific question.",
    subtasks=[
        ResearchSubtask(description="Sleep stages and memory", search_terms=["sleep stages memory", "REM sleep memory"]),
        ResearchSubtask(description="Sleep deprivation effects", search_terms=["sleep deprivation memory"]),
    ],
    acceptance_criteria=AcceptanceCriteria(
        min_relevant_articles=3,
        min_peer_reviewed_share=0.0,
        min_average_quality=0.0,
        max_age_years=None,
        every_subtask_covered=True,
        other_requirements=["Includes a review article"],
    ),
)


class FakeLLM:
    """Returns scripted responses per schema, in order. An Exception in the script is raised.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    def __init__(self, plan=PLAN, refinements=(), verdicts=()):
        self.responses = {ResearchPlan: [plan], SearchPlan: list(refinements), SufficiencyVerdict: list(verdicts)}
        self.prompts: list[tuple[type, str]] = []

    def check_health(self):
        return True, "ok"

    def generate_structured(self, prompt, schema, system=None, **kwargs):
        self.prompts.append((schema, prompt))
        response = self.responses[schema].pop(0)
        if isinstance(response, Exception):
            raise response
        return response


class FakeProvider:
    """Stands in for a scholarly API: returns ``n`` results for any query.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    source = Source.OPENALEX

    def __init__(self, n: int):
        self.n = n

    async def search(self, client, query, planner_query, limit, language=None):
        return [
            RawResult(title=f"{planner_query} paper {i}", source=self.source, query=planner_query, abstract="An abstract.")
            for i in range(self.n)
        ]


class PassThroughTranslator:
    """Stands in for Qwen: sends each planner query unchanged (forces the fallback path).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    model = "fake-qwen"

    def check_health(self):
        return True, "ok"

    def generate_structured(self, prompt, schema, system=None, **kwargs):
        return QueryTranslation(translations=[])


class FakeReader:
    """Stands in for Qwen in processing: every article is relevant (8/10), credibility 6.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    model = "fake-qwen"

    def check_health(self):
        return True, "ok"

    def generate_structured(self, prompt, schema, system=None, **kwargs):
        count = prompt.count("<article index=")
        return BatchJudgement(
            articles=[
                ArticleJudgement(index=i, relevant=True, relevance=8, credibility=6, summary=f"Summary {i}.", relevance_reason="On topic.")
                for i in range(1, count + 1)
            ]
        )


class FakeWriter:
    """Stands in for Qwen in the storage agent.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    model = "fake-qwen"

    def __init__(self):
        self.prompts = []

    def check_health(self):
        return True, "ok"

    def generate_structured(self, prompt, schema, system=None, **kwargs):
        self.prompts.append(prompt)
        return ReportDraft(
            title="Sleep and Memory: A Review",
            overview="Sleep supports memory [1]. Invented source [99].",
            findings=[ReportFindings(subtask="Sleep stages and memory", points=["Point [2]."])],
        )


def make_planner(llm, results_per_query=3, tmp_path=None) -> PlannerAgent:
    retrieval = RetrievalAgent(
        llm=PassThroughTranslator(),
        providers=[FakeProvider(results_per_query)],
        journal_store=JournalStore(tmp_path / "Journal"),
    )
    planner = PlannerAgent(llm=llm, retrieval=retrieval, processing_llm=FakeReader(), storage_llm=FakeWriter())
    planner.storage.results_dir = tmp_path
    return planner


def run(planner: PlannerAgent, goal="How does sleep affect memory?"):
    return planner.graph.invoke({"goal": goal}, config={"recursion_limit": 30})


def plan_with_scope(scope: str) -> ResearchPlan:
    return PLAN.model_copy(update={"scope": scope, "scope_reason": f"A {scope} question."})
