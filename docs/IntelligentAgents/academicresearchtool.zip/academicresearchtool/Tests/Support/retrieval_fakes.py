"""Recorded-style arXiv / OpenAlex / CORE responses, a scripted Qwen for query rewriting, and the agent_factory fixture.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import httpx
import pytest

from Agents import ret
from Agents.ret import RetrievalAgent
from App.journal import JournalStore
from App.sources import ArxivProvider, CoreProvider, OpenAlexProvider

ARXIV_XML = """<?xml version="1.0" encoding="UTF-8"?>
<feed xmlns="http://www.w3.org/2005/Atom" xmlns:arxiv="http://arxiv.org/schemas/atom">
  <entry>
    <id>http://arxiv.org/abs/2101.00001v2</id>
    <published>2021-01-04T00:00:00Z</published>
    <title>Neural Replay  During
      Sleep</title>
    <summary>  We study replay. </summary>
    <author><name>Ada Lovelace</name></author>
    <author><name>Alan Turing</name></author>
    <arxiv:doi>10.1000/xyz</arxiv:doi>
    <link href="https://arxiv.org/pdf/2101.00001v2" rel="related" title="pdf"/>
  </entry>
</feed>"""


OPENALEX_JSON = {
    "results": [
        {
            "id": "https://openalex.org/W1",
            "display_name": "The REM Sleep-Memory Consolidation Hypothesis",
            "doi": "https://doi.org/10.1126/science.1063049",
            "publication_year": 2001,
            "authorships": [{"author": {"display_name": "Jerome M. Siegel"}}],
            "abstract_inverted_index": {"Sleep": [0], "helps": [1], "memory": [2]},
            "primary_location": {"landing_page_url": "https://science.org/x"},
            "best_oa_location": None,
            "cited_by_count": 512,
        },
        {"id": "https://openalex.org/W2", "display_name": None},  # no title: dropped
    ]
}


CORE_JSON = {
    "results": [
        {
            "id": 42,
            "title": "Sleep and memory",
            "authors": [{"name": "Gais, Steffen"}, {"name": "Steffen Gais"}, {"name": "Born, Jan"}, {"name": "Gais Steffen"}],
            "abstract": "Open access paper.",
            "yearPublished": 2004,
            "doi": "10.1101/lm.70504",
            "downloadUrl": "https://core.ac.uk/download/42.pdf",
            "links": [{"type": "display", "url": "https://core.ac.uk/works/42"}],
            "citationCount": 3,
        }
    ]
}


def mock_client(handler):
    return lambda: httpx.AsyncClient(transport=httpx.MockTransport(handler), follow_redirects=True)


def api_handler(request: httpx.Request) -> httpx.Response:
    host = request.url.host
    if "arxiv" in host:
        return httpx.Response(200, text=ARXIV_XML)
    if "openalex" in host:
        return httpx.Response(200, json=OPENALEX_JSON)
    if "core" in host:
        return httpx.Response(200, json=CORE_JSON)
    return httpx.Response(404)


class ScriptedQwen:
    model = "qwen3.5:9b"

    def __init__(self, translation=None, error=None):
        self.translation = translation
        self.error = error
        self.prompts = []

    def generate_structured(self, prompt, schema, system=None, **kwargs):
        self.prompts.append(prompt)
        if self.error:
            raise self.error
        return self.translation


@pytest.fixture
def agent_factory(tmp_path, monkeypatch):
    def make(llm, handler=api_handler):
        monkeypatch.setattr(ret, "make_http_client", mock_client(handler))
        providers = [ArxivProvider(delay=0), OpenAlexProvider(api_key=None), CoreProvider(api_key=None)]
        return RetrievalAgent(llm=llm, providers=providers, journal_store=JournalStore(tmp_path / "Journal"))

    return make
