"""Sample past questions, the spelling assistant fixture, and a test window (window fixture) for the question box.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

from collections import Counter
import time
from types import SimpleNamespace

import pytest

from App.typing_aids import TypingAssistant

QUESTIONS = ["Find me research on social and emotional learning in elementary school. Limit it to 5 articles."]


@pytest.fixture(scope="module")
def assistant():
    return TypingAssistant("en", questions=list(QUESTIONS), vocabulary=Counter({"neuroplasticity": 3}))


@pytest.fixture
def window(monkeypatch):
    import tkinter as tk

    import interface

    monkeypatch.setattr(interface.ResearchApp, "_check_ollama", lambda self: None)
    monkeypatch.setattr("App.typing_aids.past_questions", lambda *a: list(QUESTIONS))
    monkeypatch.setattr("App.typing_aids.research_vocabulary", lambda *a: Counter())  # not the user's own journals
    root = tk.Tk()
    root.withdraw()
    app = interface.ResearchApp(root)
    start = time.time()
    while app.assist.assistant is None and time.time() - start < 5:
        root.update()
        time.sleep(0.02)
    yield app
    close_window(root, app)


def close_window(root, app) -> None:
    """Close a test window and free its Tk objects now, on the main thread (if left to the
    garbage collector they may be freed later from another test's thread, which Tk forbids).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    import gc

    del app
    root.destroy()
    gc.collect()


def type_into(app, text):
    for ch in text:
        app.prompt.insert("insert", ch)
        app.assist._on_key_release(SimpleNamespace(keysym={" ": "space", "?": "question"}.get(ch, ch)))
    app.assist.refresh()
