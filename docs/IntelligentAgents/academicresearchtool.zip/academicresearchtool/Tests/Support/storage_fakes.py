"""Stand-ins for the storage agent: ranked sources, journals with FINAL RESULTS, and models that fail or record their calls.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

from App.journal import JournalStore
from App.models import FinalResults, PlannerApproval, RankedResult, Source


def ranked(n: int) -> list[RankedResult]:
    return [
        RankedResult(
            title=f"Paper {i}", authors=["Ada Lovelace"], year=2020 + i, venue="Journal X", source=Source.OPENALEX,
            query="q", article_id=f"doi:{i}", summary=f"Finding {i}. More.", doi=f"10.1/{i}",
        )
        for i in range(1, n + 1)
    ]


def journal_with_final(tmp_path, results) -> str:
    store = JournalStore(tmp_path)
    path = store.create("Does sleep help memory?")
    journal = store.load(path)
    journal.final_results = FinalResults(
        planner_approval=PlannerApproval(status="approved", search_cycles=1, reason="Good."),
        goal="Does sleep help memory?",
        ranked_results=results,
    )
    store.save(path, journal)
    return str(path)


class Broken:
    model = "qwen3.5:9b"

    def generate_structured(self, *args, **kwargs):
        import httpx

        raise httpx.ConnectError("down")


class Recorder:
    model = "qwen3.5:9b"

    def __init__(self):
        self.calls = []

    def generate_structured(self, prompt, schema, system=None, **kwargs):
        from App.models import ReportDraft

        self.calls.append(kwargs)
        return ReportDraft(title="T", overview="O [1].", findings=[])
