"""Sample sources and a fixed 'accessed' date for the Harvard referencing tests.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

from datetime import date

from App.models import RankedResult, Source

ACCESSED = date(2026, 10, 4)


def source(title, authors, year=2018, **kw) -> RankedResult:
    kw.setdefault("source", Source.OPENALEX)
    return RankedResult(title=title, authors=authors, year=year, query="q", article_id=title, **kw)
