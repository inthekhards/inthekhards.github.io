"""Stand-ins for the processing agent: sample articles, a scripted Qwen, and journals pre-filled with raw results.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

from datetime import datetime

import httpx

from Agents.plan import default_criteria
from Agents.proc import ProcessingAgent
from App.journal import JournalStore
from App.models import (
    ArticleJudgement,
    BatchJudgement,
    RawResult,
    ResearchPlan,
    ResearchState,
    ResearchSubtask,
    RetrievalCycle,
    Source,
)

GOAL = "How does sleep affect memory consolidation?"


PLAN = ResearchPlan(
    objective=GOAL,
    scope="general",
    scope_reason="Short question.",
    subtasks=[ResearchSubtask(description="Sleep and memory", search_terms=["sleep memory"])],
    acceptance_criteria=default_criteria(),
)


def raw(title, source=Source.OPENALEX, query="sleep memory", **kw) -> RawResult:
    return RawResult(title=title, source=source, query=query, abstract=kw.pop("abstract", f"Abstract of {title}."), **kw)


class FakeQwen:
    """Scores articles by title: 'Unrelated' → 1/10, anything else → 8/10. Records each batch.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    model = "qwen3.5:9b"

    def __init__(self, fail=False, skip_index=None):
        self.fail = fail
        self.skip_index = skip_index
        self.batches: list[list[str]] = []

    def generate_structured(self, prompt, schema, system=None, **kwargs):
        titles = [line[len("Title: ") :] for line in prompt.splitlines() if line.startswith("Title: ")]
        self.batches.append(titles)
        if self.fail:
            raise httpx.ConnectError("down")
        articles = []
        for i, title in enumerate(titles, 1):
            if i == self.skip_index:
                continue
            score = 1 if "Unrelated" in title else 8
            articles.append(
                ArticleJudgement(
                    index=i, relevant=score >= 5, relevance=score, credibility=7,
                    summary=f"Qwen summary of {title}.", relevance_reason="Because.",
                )
            )
        return BatchJudgement(articles=articles)


def journal_with(tmp_path, *cycles: list[RawResult]) -> str:
    store = JournalStore(tmp_path)
    path = store.create(GOAL)
    for i, results in enumerate(cycles, 1):
        store.append_cycle(path, RetrievalCycle(iteration=i, started_at=datetime.now(), completed_at=datetime.now(), model="q", raw_results=results))
    return str(path)


def state(path, iteration=1) -> ResearchState:
    return ResearchState(goal=GOAL, research_plan=PLAN, journal_path=path, iteration_count=iteration)


def agent(tmp_path, llm=None, **kw) -> ProcessingAgent:
    return ProcessingAgent(llm=llm or FakeQwen(), journal_store=JournalStore(tmp_path), batch_size=kw.pop("batch_size", 5), **kw)
