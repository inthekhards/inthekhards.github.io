"""A slow streamed model answer, for testing Stop and time limits mid-answer.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import time
from types import SimpleNamespace


class Stream:
    """A streamed model answer that takes a little while per piece.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    def __init__(self, pieces, delay=0.05):
        self.pieces, self.delay, self.closed = pieces, delay, False

    def __iter__(self):
        for piece in self.pieces:
            time.sleep(self.delay)
            yield SimpleNamespace(message=SimpleNamespace(content=piece, thinking=None))

    def close(self):
        self.closed = True
