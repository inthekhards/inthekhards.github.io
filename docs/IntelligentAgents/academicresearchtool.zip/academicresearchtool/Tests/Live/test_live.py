"""Live tests: the real Ollama models and the real arXiv / OpenAlex / CORE APIs.

Section: Live evaluation with real models and APIs.

Skipped unless pytest is run with ``--live`` (needs Ollama running, the models
installed, and the internet). Measured values (timings, counts, accuracy) are
recorded with ``record_property`` so they appear in the test report.
The full research run takes about 10-15 minutes on a 16 GB M1.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import asyncio
import re
import time

import pytest

from Agents.plan import PlannerAgent, default_criteria
from Agents.proc import Article, ProcessingAgent
from Agents.ret import RetrievalAgent
from App.journal import JournalStore
from App.languages import foreign_script
from App.model_catalog import CATALOG, DEFAULT_MODELS, make_llm
from App.models import RawResult, ResearchPlan, ResearchState, ResearchSubtask, SearchPlan, Source
from App.sources import ArxivProvider, CoreProvider, OpenAlexProvider, make_http_client


def installed_models() -> list[str]:
    tags = []
    for option in CATALOG:
        if make_llm("retrieval", option.tag).check_health()[0]:
            tags.append(option.tag)
    return tags


# ---- Models ----------------------------------------------------------------------


def test_default_models_are_installed(record_property):
    """DeepSeek R1 (planner) and Qwen 3.5 (other agents) are installed and Ollama is running.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    for role, tag in DEFAULT_MODELS.items():
        ok, message = make_llm(role, tag).check_health()
        record_property(f"{role} model", f"{tag}: {message}")
        assert ok, message


@pytest.mark.parametrize("tag", [o.tag for o in CATALOG])
def test_model_returns_valid_structured_output(tag, record_property):
    """Each installed model answers with JSON that passes the Pydantic schema.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    llm = make_llm("retrieval", tag)
    if not llm.check_health()[0]:
        pytest.skip(f"{tag} is not installed")
    started = time.monotonic()
    plan = llm.generate_structured("Give 2 short academic search queries about sleep and memory.", SearchPlan, timeout=240)
    record_property("seconds", round(time.monotonic() - started, 1))
    record_property("queries", "; ".join(plan.queries))
    assert plan.queries and all(q.strip() for q in plan.queries)


# ---- Scholarly APIs --------------------------------------------------------------------


@pytest.mark.parametrize("provider", [ArxivProvider(), OpenAlexProvider(), CoreProvider()], ids=["arxiv", "openalex", "core"])
def test_database_answers_in_english(provider, record_property):
    """Each database returns results for a real query, all of them readable English.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    async def search():
        async with make_http_client() as client:
            return await provider.search(client, "social emotional learning elementary", "q", 5, language="en")

    started = time.monotonic()
    results = asyncio.run(search())
    record_property("seconds", round(time.monotonic() - started, 1))
    record_property("results", len(results))
    record_property("first title", results[0].title if results else "-")
    assert results
    assert all(RetrievalAgent.fits_language(r, "en") for r in results if r.language in (None, "en"))


# ---- Relevance-labelled evaluation (Design Proposal: "relevance-labelled queries") -----

QUESTION = "How does sleep affect memory consolidation?"
LABELLED = [  # (title, abstract, relevant?)
    ("Sleep's function in the spontaneous recovery and consolidation of memories",
     "Sleep after learning stabilises and strengthens new memories through hippocampal replay.", True),
    ("The memory function of sleep",
     "We review evidence that slow-wave sleep and REM sleep support the consolidation of declarative memories.", True),
    ("Sleep deprivation impairs memory consolidation in adolescents",
     "Adolescents deprived of sleep after learning recalled fewer words than rested peers.", True),
    ("Overnight memory consolidation and sleep spindles",
     "Sleep spindle density predicted overnight improvement in memory recall.", True),
    ("Graphene transistors for high-frequency electronics",
     "We fabricate graphene field-effect transistors operating above 100 GHz.", False),
    ("Corporate tax policy and foreign direct investment",
     "Lower corporate tax rates attract foreign direct investment in emerging markets.", False),
    ("Hamstring injuries in professional football",
     "We report the incidence of hamstring strains across five football seasons.", False),
    ("Coral reef bleaching under ocean warming",
     "Marine heatwaves caused widespread coral bleaching on the Great Barrier Reef.", False),
]


def test_processing_model_judges_relevance_correctly(record_property):
    """Qwen labels 8 hand-labelled articles as relevant or not; accuracy, precision and recall are recorded.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    agent = ProcessingAgent()
    if not agent.llm.check_health()[0]:
        pytest.skip("processing model not installed")
    plan = ResearchPlan(objective=QUESTION, scope="general", scope_reason="test",
                        subtasks=[ResearchSubtask(description=QUESTION, search_terms=["sleep memory"])],
                        acceptance_criteria=default_criteria())
    state = ResearchState(goal=QUESTION, research_plan=plan)
    articles = [
        Article(record=RawResult(title=t, abstract=a, source=Source.OPENALEX, query="q"), keys=[f"title:{i}"],
                found_in=[Source.OPENALEX], queries=["q"])
        for i, (t, a, _) in enumerate(LABELLED)
    ]
    started = time.monotonic()
    judgements, _, failures, _ = agent.assess(articles, state)
    predicted = [judgements[a.article_id].relevant for a in articles]
    actual = [label for _, _, label in LABELLED]
    tp = sum(p and a for p, a in zip(predicted, actual))
    fp = sum(p and not a for p, a in zip(predicted, actual))
    fn = sum(a and not p for p, a in zip(predicted, actual))
    accuracy = sum(p == a for p, a in zip(predicted, actual)) / len(actual)
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    record_property("model", agent.model_name)
    record_property("seconds", round(time.monotonic() - started, 1))
    record_property("accuracy", f"{accuracy:.0%}")
    record_property("precision", f"{precision:.0%}")
    record_property("recall", f"{recall:.0%}")
    record_property("articles the model could not judge", failures)
    assert accuracy >= 0.75


# ---- A full research run ---------------------------------------------------------------


def test_full_research_run(tmp_path, record_property):
    """A real question goes through all four agents with real models and APIs (about 10-15 minutes).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    planner = PlannerAgent(retrieval=RetrievalAgent(journal_store=JournalStore(tmp_path / "Journal")))
    planner.storage.results_dir = tmp_path / "Results"
    stages = []
    started = time.monotonic()
    path = planner.run("What is dark matter? Limit it to 3 articles.", on_progress=stages.append, language="en")
    report = path.read_text()
    ranked = report.split("## Ranked Sources")[1].split("## Reference List")[0] if "## Ranked Sources" in report else ""
    sources = len(re.findall(r"^\d+\. ", ranked, re.M))

    record_property("total time", f"{(time.monotonic() - started) / 60:.1f} min")
    record_property("time per agent (s)", {k: round(v) for k, v in planner.budget.used.items()})
    record_property("report title", report.splitlines()[0].removeprefix("# "))
    record_property("sources in report", sources)
    assert report.startswith("# ")
    assert 1 <= sources <= 3  # the question asked for 3
    assert foreign_script(report) is None
