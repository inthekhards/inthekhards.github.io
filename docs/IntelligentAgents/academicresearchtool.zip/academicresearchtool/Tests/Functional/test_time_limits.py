"""Functional tests: whole features from the user's point of view (scripted models, no internet).

Section: Time limits and search scope.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import threading

from App.control import RunControl
from App.journal import JournalStore
from App.models import (
    ResearchSubtask,
    SufficiencyVerdict,
)
from Tests.Support.workflow_fakes import FakeLLM, make_planner, plan_with_scope, run


def test_paused_time_is_not_charged_to_agents(tmp_path):
    """Time spent paused doesn't count against any agent's time limit.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    planner = make_planner(FakeLLM(verdicts=[SufficiencyVerdict(sufficient=True, reason="ok")]), tmp_path=tmp_path)
    control = RunControl()
    paused_once = []

    def progress(message):
        if message.startswith("Processing agent is ranking") and not paused_once:
            paused_once.append(True)
            control.pause()
            threading.Timer(0.5, control.resume).start()

    planner.run("How does sleep affect memory?", on_progress=progress, control=control)
    assert control.paused_seconds >= 0.4
    assert max(planner.budget.used.values()) < 0.4


def test_general_questions_get_small_search_limits(tmp_path):
    """General questions get the general scope's limits (5 min per agent, 10 articles per search).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    llm = FakeLLM(plan=plan_with_scope("general"), verdicts=[SufficiencyVerdict(sufficient=True, reason="Good.")])
    final = run(make_planner(llm, tmp_path=tmp_path))

    assert (final["limits"].scope, final["limits"].seconds_per_agent, final["limits"].articles_per_search) == ("general", 300, 10)
    assert final["extra_time"] is None
    assert set(final["seconds_used"]) == {"Planner Agent", "Retrieval Agent", "Processing Agent", "Storage Agent"}


def test_general_scope_caps_articles_and_queries(tmp_path):
    """A general question sends at most 3 queries and pulls at most 10 articles per search.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    many_terms = plan_with_scope("general").model_copy(
        update={"subtasks": [ResearchSubtask(description=f"Subtask {i}", search_terms=[f"term {i}"]) for i in range(6)]}
    )
    llm = FakeLLM(plan=many_terms, verdicts=[SufficiencyVerdict(sufficient=True, reason="Good.")])
    final = run(make_planner(llm, results_per_query=8, tmp_path=tmp_path))

    assert final["search_queries"] == ["term 0", "term 1", "term 2"]  # 3 queries for general questions
    assert final["retrieval_report"].new_results == 10  # 10 articles per search


def test_extended_scope_asks_permission_and_uses_more_time_if_allowed(tmp_path):
    """Extended searches ask the user first and use 10 min / 40 articles if allowed.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    asked = []
    planner = make_planner(FakeLLM(plan=plan_with_scope("extended"), verdicts=[SufficiencyVerdict(sufficient=True, reason="Good.")]), tmp_path=tmp_path)
    planner.ask_permission = lambda message: asked.append(message) or True
    final = run(planner)

    assert len(asked) == 1 and "10m 00s" in asked[0] and "40 articles" in asked[0]
    assert (final["limits"].scope, final["limits"].seconds_per_agent, final["extra_time"]) == ("extended", 600, "approved")


def test_extended_scope_falls_back_to_normal_limits_if_declined(tmp_path):
    """If the user declines extra time, the normal (detailed) limits are used.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    planner = make_planner(FakeLLM(plan=plan_with_scope("extended"), verdicts=[SufficiencyVerdict(sufficient=True, reason="Good.")]), tmp_path=tmp_path)
    planner.ask_permission = lambda message: False
    final = run(planner)

    assert (final["limits"].scope, final["limits"].seconds_per_agent, final["extra_time"]) == ("detailed", 300, "declined")
    assert JournalStore().load(final["journal_path"]).final_results.extra_time == "declined"


def test_waiting_for_the_user_is_not_charged(tmp_path):
    """Time waiting for the user to answer a pop-up isn't charged to the planner.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    import time as clock

    planner = make_planner(FakeLLM(plan=plan_with_scope("extended"), verdicts=[SufficiencyVerdict(sufficient=True, reason="Good.")]), tmp_path=tmp_path)
    planner.ask_permission = lambda message: clock.sleep(0.5) or True
    final = run(planner)
    assert final["seconds_used"]["Planner Agent"] < 0.4


def test_no_more_searches_when_time_runs_out(tmp_path):
    """No new search cycle starts when an agent has run out of time.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    llm = FakeLLM(verdicts=[SufficiencyVerdict(sufficient=False, reason="Weak.", gaps=["More"])])
    planner = make_planner(llm, tmp_path=tmp_path)
    planner.budget.charge("Retrieval Agent", 10_000)  # retrieval has used up its time
    final = run(planner)

    assert final["iteration_count"] == 1 and final["out_of_time"] is True
    assert final["planner_approval"].reason.startswith("Time limit reached after 1 search cycle(s)")


def test_planner_out_of_time_decides_on_measured_criteria(tmp_path):
    """When the planner is out of time it decides on measured criteria and still produces a report.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    llm = FakeLLM()  # no review scripted: calling the model would fail the test
    planner = make_planner(llm, tmp_path=tmp_path)
    for agent in ("Planner Agent", "Retrieval Agent", "Processing Agent", "Storage Agent"):
        planner.budget.charge(agent, 10_000)  # every agent has used up its time
    final = run(planner)

    assert "time limit was reached" in final["evaluation"].reason
    assert SufficiencyVerdict not in [s for s, _ in llm.prompts]
    assert final["report_path"]  # still produces a report from what it has
