"""Functional tests: whole features from the user's point of view (scripted models, no internet).

Section: Research workflow (plan, retrieve, process, review loop).

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

from pydantic import ValidationError
import pytest

from App import config
from App.journal import JournalStore
from App.models import (
    ResearchPlan,
    ResearchSubtask,
    SearchPlan,
    SufficiencyVerdict,
)
from Tests.Support.workflow_fakes import PLAN, FakeLLM, make_planner, run


def test_first_cycle_breaks_question_into_subtasks(tmp_path):
    """The planner breaks the question into subtasks and sends their search terms to retrieval.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    llm = FakeLLM(verdicts=[SufficiencyVerdict(sufficient=True, reason="Good coverage.")])
    final = run(make_planner(llm, tmp_path=tmp_path))

    assert final["research_plan"] == PLAN
    # One query per subtask first, so a small query limit still covers every subtask.
    assert final["query_history"] == ["sleep stages memory", "sleep deprivation memory", "REM sleep memory"]
    assert final["iteration_count"] == 1
    assert final["sufficient"] is True


def test_sufficient_results_go_straight_to_storage(tmp_path):
    """If the first results are acceptable, there is no second search.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    llm = FakeLLM(verdicts=[SufficiencyVerdict(sufficient=True, reason="Good coverage.")])
    final = run(make_planner(llm, tmp_path=tmp_path))

    assert final["report_path"]
    assert [s for s, _ in llm.prompts] == [ResearchPlan, SufficiencyVerdict]


def test_inaccurate_results_trigger_new_search_mix(tmp_path):
    """Unacceptable results trigger a new mix of search terms guided by the review's gaps.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    llm = FakeLLM(
        refinements=[SearchPlan(queries=["slow wave sleep consolidation", "hippocampal replay"], rationale="Target gaps.")],
        verdicts=[
            SufficiencyVerdict(sufficient=False, reason="Results are off-topic.", gaps=["Sleep deprivation effects"]),
            SufficiencyVerdict(sufficient=True, reason="Now covered."),
        ],
    )
    final = run(make_planner(llm, tmp_path=tmp_path))

    assert final["iteration_count"] == 2
    assert final["search_queries"] == ["slow wave sleep consolidation", "hippocampal replay"]
    refine_prompt = next(p for s, p in llm.prompts if s is SearchPlan)
    assert "Results are off-topic." in refine_prompt
    assert "Sleep deprivation effects" in refine_prompt
    assert "sleep stages memory (3 found, 3 relevant)" in refine_prompt


def test_stops_after_three_cycles_when_never_sufficient(tmp_path):
    """The search loop stops after at most 3 cycles.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    not_ok = SufficiencyVerdict(sufficient=False, reason="Still weak.", gaps=["More detail"])
    llm = FakeLLM(
        refinements=[SearchPlan(queries=[f"query {i}"], rationale="Try again.") for i in range(2)],
        verdicts=[not_ok] * 3,
    )
    final = run(make_planner(llm, tmp_path=tmp_path))

    assert final["iteration_count"] == config.MAX_ITERATIONS == 3
    assert final["sufficient"] is False
    assert final["report_path"]


def test_too_few_results_skips_llm_review(tmp_path):
    """With no relevant results the planner doesn't ask its model to review nothing.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    llm = FakeLLM(refinements=[SearchPlan(queries=[f"broader {i}"], rationale="Broaden.") for i in range(2)])
    final = run(make_planner(llm, results_per_query=0, tmp_path=tmp_path))

    assert final["iteration_count"] == 3
    assert SufficiencyVerdict not in [s for s, _ in llm.prompts]
    assert final["evaluation"].reason == "No relevant results were found."


def test_repeated_queries_are_filtered_out(tmp_path):
    """A query already tried is never sent again (ignoring case and spacing).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    llm = FakeLLM(
        refinements=[SearchPlan(queries=["Sleep Stages Memory", "  new   angle  ", "new angle"], rationale="Mixed.")],
        verdicts=[
            SufficiencyVerdict(sufficient=False, reason="Gaps.", gaps=["x"]),
            SufficiencyVerdict(sufficient=True, reason="Done."),
        ],
    )
    final = run(make_planner(llm, tmp_path=tmp_path))

    assert final["search_queries"] == ["new angle"]


def test_falls_back_when_llm_output_is_invalid(tmp_path):
    """If the planner model returns invalid output, the question itself is searched instead.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    bad = ValidationError.from_exception_data("ResearchPlan", [])
    llm = FakeLLM(plan=bad, verdicts=[SufficiencyVerdict(sufficient=True, reason="Fine.")])
    final = run(make_planner(llm, results_per_query=5, tmp_path=tmp_path), goal="quantum error correction")

    assert final["search_queries"] == ["quantum error correction"]
    assert any("Could not break down" in e.message for e in final["activity_log"])


def test_run_reports_unreachable_ollama(tmp_path):
    """A run stops straight away with a clear message if Ollama can't be reached.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    llm = FakeLLM()
    llm.check_health = lambda: (False, "Can't reach Ollama")
    with pytest.raises(RuntimeError, match="Can't reach Ollama"):
        make_planner(llm, tmp_path=tmp_path).run("anything")


def test_run_reports_missing_retrieval_model(tmp_path):
    """A run stops straight away with a clear message if a model isn't installed.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    planner = make_planner(FakeLLM(), tmp_path=tmp_path)
    planner.retrieval.llm.check_health = lambda: (False, "Model 'qwen3.5:9b' isn't pulled")
    with pytest.raises(RuntimeError, match="qwen3.5:9b"):
        planner.run("anything")


def test_retrieval_writes_journal_and_planner_dispatches_processing(tmp_path):
    """Retrieval writes the journal and reports back; the planner then dispatches processing.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    llm = FakeLLM(verdicts=[SufficiencyVerdict(sufficient=True, reason="Good.")])
    final = run(make_planner(llm, tmp_path=tmp_path))

    journal = JournalStore().load(final["journal_path"])
    assert final["journal_path"].startswith(str(tmp_path / "Journal"))
    assert len(journal.cycles) == 1 and len(journal.all_raw_results()) == 9
    assert final["retrieval_report"].status == "complete"
    messages = [e.message for e in final["activity_log"]]
    assert any("Dispatching the Processing Agent" in m for m in messages)
    assert any("Read 9 raw results from the journal" in m for m in messages)


def test_empty_journal_skips_processing(tmp_path):
    """If retrieval finds nothing, processing is skipped.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    llm = FakeLLM(refinements=[SearchPlan(queries=[f"broader {i}"], rationale="Broaden.") for i in range(2)])
    final = run(make_planner(llm, results_per_query=0, tmp_path=tmp_path))

    messages = [e.message for e in final["activity_log"]]
    assert any("skipping processing" in m for m in messages)
    assert not any("raw results from the journal" in e.message for e in final["activity_log"])
    assert len(JournalStore().load(final["journal_path"]).cycles) == 3


def test_fallback_queries_never_use_criteria_as_search_terms(tmp_path):
    """Backup queries never use criteria text like 'At least 50% peer-reviewed' as search terms.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    strict = PLAN.model_copy(update={"acceptance_criteria": PLAN.acceptance_criteria.model_copy(update={"min_relevant_articles": 25})})
    review_failed = ValidationError.from_exception_data("SufficiencyVerdict", [])
    refine_failed = ValidationError.from_exception_data("SearchPlan", [])
    llm = FakeLLM(plan=strict, refinements=[refine_failed] * 2, verdicts=[review_failed] * 3)
    final = run(make_planner(llm, tmp_path=tmp_path))

    assert not any("relevant articles" in q for q in final["query_history"])
    assert "Sleep stages and memory" in final["query_history"]


def test_stops_early_when_no_new_search_terms_remain(tmp_path):
    """The search stops early when there are no new search terms left to try.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    refine_failed = ValidationError.from_exception_data("SearchPlan", [])
    one_term = ResearchPlan(
        objective="q", scope="general", scope_reason="r", acceptance_criteria=PLAN.acceptance_criteria,
        subtasks=[ResearchSubtask(description="How does sleep affect memory?", search_terms=["How does sleep affect memory?"])],
    )
    llm = FakeLLM(plan=one_term, refinements=[refine_failed] * 2, verdicts=[SufficiencyVerdict(sufficient=False, reason="Weak.")])
    final = run(make_planner(llm, tmp_path=tmp_path))

    assert final["query_history"] == ["How does sleep affect memory?"]
    assert len(JournalStore().load(final["journal_path"]).cycles) == 1
    assert final["planner_approval"].status == "best_available"
    assert any("stopping the search early" in e.message for e in final["activity_log"])
