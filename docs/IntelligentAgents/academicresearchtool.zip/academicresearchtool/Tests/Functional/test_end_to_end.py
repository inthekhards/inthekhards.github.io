"""Functional tests: whole features from the user's point of view (scripted models, no internet).

Section: End to end: a question goes through all four agents to a finished report.

The real arXiv, OpenAlex and CORE client code is used, with recorded-style responses
served instead of the internet. The models are scripted, so the results are the
same every time. The responses include traps the tool must handle: the same paper
in two databases, a retracted paper, an English paper with a Cyrillic author name,
and a French paper.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import json
import re

import httpx
import pytest

from Agents import ret
from Agents.plan import PlannerAgent
from Agents.ret import RetrievalAgent
from App.journal import JournalStore
from App.languages import foreign_script
from App.models import (
    AcceptanceCriteria,
    ArticleJudgement,
    BatchJudgement,
    ProviderQueries,
    QueryTranslation,
    ReportDraft,
    ReportFindings,
    ResearchPlan,
    ResearchSubtask,
    SufficiencyVerdict,
)
from App.sources import ArxivProvider, CoreProvider, OpenAlexProvider

QUESTION = "Find me research on social and emotional learning in elementary school."

DURLAK = {
    "id": "https://openalex.org/W2104409419",
    "display_name": "The Impact of Enhancing Students' Social and Emotional Learning: A Meta-Analysis of "
                    "School-Based Universal Interventions",
    "doi": "https://doi.org/10.1111/j.1467-8624.2010.01564.x",
    "type": "article",
    "publication_year": 2011,
    "language": "en",
    "is_retracted": False,
    "cited_by_count": 9800,
    "biblio": {"volume": "82", "issue": "1", "first_page": "405", "last_page": "432"},
    "authorships": [
        {"author": {"display_name": "Joseph A. Durlak", "orcid": "https://orcid.org/0000-0001-1"}},
        {"author": {"display_name": "Roger P. Weissberg", "orcid": None}},
        {"author": {"display_name": "Allison B. Dymnicki", "orcid": None}},
        {"author": {"display_name": "Rebecca D. Taylor", "orcid": None}},
        {"author": {"display_name": "Kriston B. Schellinger", "orcid": None}},
    ],
    "abstract_inverted_index": {"A": [0], "meta-analysis": [1], "of": [2], "social": [3], "and": [4],
                                "emotional": [5], "learning": [6], "programs": [7], "in": [8], "schools.": [9]},
    "primary_location": {"landing_page_url": "https://doi.org/10.1111/j.1467-8624.2010.01564.x",
                         "source": {"display_name": "Child Development", "type": "journal", "is_core": True,
                                    "host_organization_name": "Wiley"}},
    "best_oa_location": None,
}

OPENALEX = {"results": [
    DURLAK,
    {  # English article, but an author name in Cyrillic: must never appear
        "id": "W2", "display_name": "Integrating Socio-Emotional Learning into Primary Education", "type": "article",
        "publication_year": 2024, "language": "en", "cited_by_count": 0,
        "authorships": [{"author": {"display_name": "Наталія Миколаївна Павлущенко"}}],
        "primary_location": {"source": {"display_name": "Ukrainian Journal", "type": "journal"}},
    },
    {  # French article: must never appear in English research
        "id": "W3", "display_name": "L'apprentissage socio-émotionnel à l'école primaire", "type": "article",
        "publication_year": 2019, "language": "fr", "authorships": [{"author": {"display_name": "Marie Dubois"}}],
    },
    {  # retracted: must never appear
        "id": "W4", "display_name": "Social and emotional learning boosts reading scores", "type": "article",
        "publication_year": 2016, "language": "en", "is_retracted": True,
        "authorships": [{"author": {"display_name": "Sam Retracted"}}],
    },
    {
        "id": "W5", "display_name": "Promoting Social and Emotional Learning in Elementary Classrooms",
        "doi": "https://doi.org/10.1080/example.2018", "type": "article", "publication_year": 2018, "language": "en",
        "cited_by_count": 120, "biblio": {"volume": "47", "issue": "2", "first_page": "100", "last_page": "118"},
        "authorships": [{"author": {"display_name": "Kelsey L. Kaspar", "orcid": "https://orcid.org/0000-0002-2"}},
                        {"author": {"display_name": "Susan L. Massey"}}],
        "primary_location": {"source": {"display_name": "Early Childhood Education Journal", "type": "journal",
                                        "host_organization_name": "Springer"}},
    },
]}

CORE = {"results": [
    {  # the Durlak paper again (same DOI): must be merged, not listed twice
        "id": 7, "title": "The impact of enhancing students' social and emotional learning",
        "authors": [{"name": "Durlak, Joseph A."}], "yearPublished": 2011, "doi": "10.1111/j.1467-8624.2010.01564.x",
        "language": {"code": "en"}, "abstract": "Meta-analysis of 213 school-based SEL programs.",
    },
    {
        "id": 8, "title": "Teachers' Perceptions of Social-Emotional Learning in Elementary School",
        "authors": [{"name": "Whittenberg, Stephanie"}], "yearPublished": 2020, "fieldOfStudy": "Thesis",
        "publisher": "Liberty University", "language": {"code": "en"},
        "links": [{"type": "display", "url": "https://core.ac.uk/works/8"}],
        "abstract": "A phenomenological study of elementary teachers' perceptions of social-emotional learning.",
    },
]}

ARXIV = """<feed xmlns="http://www.w3.org/2005/Atom" xmlns:arxiv="http://arxiv.org/schemas/atom">
  <entry><id>http://arxiv.org/abs/2305.00001v1</id><published>2023-05-01T00:00:00Z</published>
    <title>Social Emotional Learning Agents for Children</title>
    <summary>We design conversational agents that support social emotional learning in elementary school.</summary>
    <author><name>Hanqing Zhou</name></author></entry>
</feed>"""


def serve(request: httpx.Request) -> httpx.Response:
    host = request.url.host
    if "openalex" in host:
        return httpx.Response(200, json=OPENALEX)
    if "core" in host:
        return httpx.Response(200, json=CORE)
    return httpx.Response(200, text=ARXIV)


class ScriptedModels:
    """Answers each agent's request like a model would, so the run is repeatable.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    model = "scripted"

    def __init__(self, requested_articles=None, draft_title="Social and Emotional Learning in Elementary Schools"):
        self.requested_articles = requested_articles
        self.draft_title = draft_title
        self.seen: list[str] = []

    def check_health(self):
        return True, "ok"

    def generate_structured(self, prompt, schema, system=None, **kwargs):
        self.seen.append(schema.__name__)
        if schema is ResearchPlan:
            return ResearchPlan(
                objective="Summarise research on SEL in elementary schools.", scope="general",
                scope_reason="A broad question.", requested_articles=self.requested_articles,
                subtasks=[
                    ResearchSubtask(description="Effects of SEL programmes on pupils", search_terms=["social emotional learning outcomes"]),
                    ResearchSubtask(description="How teachers implement SEL", search_terms=["SEL teacher implementation"]),
                ],
                acceptance_criteria=AcceptanceCriteria(min_relevant_articles=2, min_peer_reviewed_share=0.3,
                                                       min_average_quality=0.3, max_age_years=None, every_subtask_covered=True),
            )
        if schema is QueryTranslation:
            queries = re.findall(r"<query>(.*?)</query>", prompt)
            return QueryTranslation(translations=[ProviderQueries(planner_query=q, arxiv=q, openalex=q, core=q) for q in queries])
        if schema is BatchJudgement:
            titles = [line[len("Title: "):] for line in prompt.splitlines() if line.startswith("Title: ")]
            on_topic = re.compile(r"social[- ](and )?emotional|socio-emotional", re.I)
            return BatchJudgement(articles=[
                ArticleJudgement(index=i, relevant=bool(on_topic.search(t)), relevance=9 if on_topic.search(t) else 2,
                                 credibility=7, summary=f"Summary of {t[:40]}.", relevance_reason="About SEL.")
                for i, t in enumerate(titles, 1)
            ])
        if schema is SufficiencyVerdict:
            return SufficiencyVerdict(sufficient=True, reason="Covers both subtasks with strong sources.")
        if schema is ReportDraft:
            return ReportDraft(
                title=self.draft_title,
                overview="SEL programmes improve pupils' social skills and achievement [1]. Teachers value them [2, 3].",
                findings=[ReportFindings(subtask="Effects of SEL programmes on pupils", points=["Large positive effects [1]."]),
                          ReportFindings(subtask="How teachers implement SEL", points=["Teachers need training [3]."])],
            )
        raise AssertionError(f"unexpected request: {schema.__name__}")


@pytest.fixture
def research(tmp_path, monkeypatch):
    """Runs a question through the whole tool and returns (report text, journal data, models).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    monkeypatch.setattr(ret, "make_http_client", lambda: httpx.AsyncClient(transport=httpx.MockTransport(serve)))

    def go(question=QUESTION, **model_options):
        models = ScriptedModels(**model_options)
        store = JournalStore(tmp_path / "Journal")
        retrieval = RetrievalAgent(llm=models, journal_store=store,
                                   providers=[ArxivProvider(delay=0), OpenAlexProvider(api_key=None), CoreProvider(api_key=None)])
        planner = PlannerAgent(llm=models, retrieval=retrieval, processing_llm=models, storage_llm=models)
        planner.storage.results_dir = tmp_path / "Results"
        path = planner.run(question, language="en")
        journal = json.loads(next((tmp_path / "Journal").glob("*.json")).read_text())
        return path, path.read_text(), journal, models

    return go


def test_question_to_finished_report(research):
    """One question produces a reader-only report with the four sections, named after its title.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    path, report, journal, models = research()
    assert path.name == "social-and-emotional-learning-in-elementary-schools.md" and path.parent.name == "Results"
    assert re.findall(r"^## (.+)$", report, re.M) == ["Overview", "Key Findings", "Ranked Sources", "Reference List"]
    assert models.seen[0] == "ResearchPlan" and models.seen[-1] == "ReportDraft"  # planner first, storage last


def test_traps_are_filtered_out(research):
    """Duplicates are merged; retracted, French and Cyrillic-author papers never appear.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    _, report, _, _ = research()
    assert report.count("Durlak, J.A.") == 2  # once in Ranked Sources, once in the Reference List
    for unwanted in ("Retracted", "apprentissage", "Integrating Socio-Emotional", "Павлущенко"):
        assert unwanted not in report
    assert foreign_script(report) is None


def test_harvard_references_are_correct(research):
    """References follow Harvard (Cite Them Right), with Harvard in-text citations and an alphabetical list.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    _, report, _, _ = research()
    assert ("Durlak, J.A., Weissberg, R.P., Dymnicki, A.B., Taylor, R.D. and Schellinger, K.B. (2011) 'The Impact of "
            "Enhancing Students' Social and Emotional Learning: A Meta-Analysis of School-Based Universal "
            "Interventions', *Child Development*, 82(1), pp. 405–432. doi: 10.1111/j.1467-8624.2010.01564.x.") in report
    assert "(Durlak et al., 2011)" in report and "[1]" not in report
    references = report.split("## Reference List")[1].strip().split("\n\n")
    surnames = [r.split(",")[0] for r in references]
    assert surnames == sorted(surnames, key=str.lower)


def test_best_source_is_ranked_first(research):
    """The highly cited, peer-reviewed meta-analysis outranks the thesis and the preprint.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    _, report, _, _ = research()
    ranked = report.split("## Ranked Sources")[1].split("## Reference List")[0]
    first = ranked.strip().splitlines()[0]
    assert first.startswith("1. Durlak, J.A.")


def test_journal_records_everything_with_final_results_last(research):
    """The journal keeps the raw data, the assessments, the rankings, then FINAL RESULTS at the end.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    _, _, journal, _ = research()
    assert list(journal)[-1] == "FINAL RESULTS"
    final = journal["FINAL RESULTS"]
    assert final["planner_approval"]["status"] == "approved" and final["language"] == "en"
    assert journal["cycles"][0]["raw_results"] and journal["assessments"] and journal["processing_cycles"]
    assert sum(s["filtered_out"] for s in journal["cycles"][0]["searches"]) >= 2  # French + Cyrillic dropped


def test_requested_number_of_articles_is_respected(research):
    """'Limit it to 2 articles' gives exactly 2 sources in the report, even though more were found.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    _, report, journal, _ = research(QUESTION + " Limit it to 2 articles.")
    ranked = report.split("## Ranked Sources")[1].split("## Reference List")[0]
    assert len(re.findall(r"^\d+\. ", ranked, re.M)) == 2
    assert len(journal["FINAL RESULTS"]["ranked_results"]) == 2
