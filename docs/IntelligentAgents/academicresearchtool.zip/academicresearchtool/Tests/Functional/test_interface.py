"""Functional tests: whole features from the user's point of view (scripted models, no internet).

Section: Question box and run controls.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import time
from types import SimpleNamespace

from App.control import RunControl
from Tests.Support.typing_fakes import QUESTIONS, close_window, type_into


def test_interface_stop_and_reset(monkeypatch):
    """Pause/Resume, Stop and Reset buttons change state correctly and Reset clears the window.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    import tkinter as tk

    import interface

    monkeypatch.setattr(interface.ResearchApp, "_check_ollama", lambda self: None)  # no background model check
    root = tk.Tk()
    root.withdraw()
    app = interface.ResearchApp(root)
    try:
        assert str(app.pause_button.cget("state")) == "disabled" and str(app.stop_button.cget("state")) == "disabled"

        # Pretend a run is in progress (without starting the agents).
        app.busy, app.control, app.started_at = True, RunControl(), time.monotonic()
        app.pause_button.configure(state="normal")
        app.stop_button.configure(state="normal")

        app.toggle_pause()
        assert app.control.paused and app.pause_button.cget("text") == "▶ Resume"
        app.toggle_pause()
        assert not app.control.paused and app.pause_button.cget("text") == "⏸ Pause"

        control, old_run = app.control, app.run_id
        app.stop()
        assert control.stopped and not app.busy and app.run_id == old_run + 1
        assert str(app.stop_button.cget("state")) == "disabled"
        assert app.status.cget("text").startswith("Stopped")

        app.prompt.insert("1.0", "old question")
        app.results_notice.configure(text="Your research results are available")
        app.reset()
        assert app.prompt.get("1.0", "end").strip() == "" and app.results_notice.cget("text") == ""
    finally:
        close_window(root, app)


def test_autocorrect_in_the_box_and_one_undo_restores(window):
    """Typos typed in the box are autocorrected, and one ⌘Z restores the original word.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    type_into(window, "How does sleep afect memroy in adolescnts?")
    assert window.assist.text() == "How does sleep affect memory in adolescents?"
    assert "Corrected" in window.hint.cget("text")
    window.prompt.edit_undo()
    assert window.assist.text() == "How does sleep affect memory in adolescnts?"


def test_suggestion_is_grey_until_accepted(window):
    """Autofill text stays grey and outside the question until Tab accepts it.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    type_into(window, "Find me res")
    assert window.prompt.tag_ranges("ghost")
    assert window.assist.text() == "Find me res"  # never part of the question unless accepted
    type_into(window, "")
    window.assist._on_key_press(SimpleNamespace(keysym="Tab"))
    assert window.assist.text() == QUESTIONS[0]


def test_toggles_turn_features_off(window):
    """The Settings toggles switch spell check/autocorrect and autofill off.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    window.autofill_on.set(False)
    window.spellcheck_on.set(False)
    type_into(window, "Find me res memroy ")
    assert not window.prompt.tag_ranges("ghost") and not window.prompt.tag_ranges("misspelled")
    assert window.assist.text() == "Find me res memroy "



def test_tab_moves_on_when_there_is_no_suggestion(window):
    """Without a grey suggestion, Tab moves to the next control instead of typing a tab character.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    window.prompt.focus_force()
    window.root.update()
    window.assist._on_key_press(SimpleNamespace(keysym="Tab"))
    window.root.update()
    assert "\t" not in window.assist.text()
    assert window.root.focus_get() is not window.prompt
