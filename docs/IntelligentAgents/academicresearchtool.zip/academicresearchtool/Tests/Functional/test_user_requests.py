"""Functional tests: whole features from the user's point of view (scripted models, no internet).

Section: Requested number of articles and Stop.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import pytest

from App.control import ResearchStopped, RunControl
from App.models import SufficiencyVerdict
from Tests.Support.workflow_fakes import PLAN, FakeLLM, make_planner, run


def test_stopping_the_planner_ends_the_whole_run(tmp_path):
    """Pressing Stop ends the whole run and no report is written.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    planner = make_planner(FakeLLM(verdicts=[SufficiencyVerdict(sufficient=True, reason="ok")]), tmp_path=tmp_path)
    control = RunControl()
    seen = []

    def progress(message):
        seen.append(message)
        if message.startswith("Retrieval agent"):
            control.stop()  # press Stop while retrieval is starting

    with pytest.raises(ResearchStopped):
        planner.run("How does sleep affect memory?", on_progress=progress, control=control)
    assert not any("writing your research report" in m for m in seen)
    assert not list(tmp_path.glob("*.md"))  # no report written


def test_results_never_exceed_the_requested_number(tmp_path):
    """'Limit it to 2 articles' gives at most 2 sources even when more are found.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    llm = FakeLLM(verdicts=[SufficiencyVerdict(sufficient=True, reason="ok")])
    final = run(make_planner(llm, tmp_path=tmp_path), goal="Research on sleep and memory. Limit it to 2 articles.")

    assert final["article_limit"] == 2
    assert len(final["ranked_results"]) == 2  # 9 relevant articles were found
    report = open(final["report_path"], encoding="utf-8").read()
    ranked = report.split("## Ranked Sources")[1].split("## Reference List")[0]
    assert "1. " in ranked and "2. " in ranked and "3. " not in ranked


def test_criteria_never_demand_more_than_requested(tmp_path):
    """The planner's minimum number of articles is lowered to the number requested.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    llm = FakeLLM(verdicts=[SufficiencyVerdict(sufficient=True, reason="ok")])  # PLAN asks for at least 3
    final = run(make_planner(llm, tmp_path=tmp_path), goal="Sleep and memory, 2 articles please")
    assert final["research_plan"].acceptance_criteria.min_relevant_articles == 2


def test_model_reading_of_the_count_is_the_backup(tmp_path):
    """If the code can't read a number from the question, the planner model's reading is used.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    plan = PLAN.model_copy(update={"requested_articles": 4})
    llm = FakeLLM(plan=plan, verdicts=[SufficiencyVerdict(sufficient=True, reason="ok")])
    final = run(make_planner(llm, tmp_path=tmp_path), goal="A handful of studies on sleep and memory")
    assert final["article_limit"] == 4 and len(final["ranked_results"]) <= 4


def test_no_limit_when_none_requested(tmp_path):
    """Without a requested number, all good results (up to the maximum) are kept.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    final = run(make_planner(FakeLLM(verdicts=[SufficiencyVerdict(sufficient=True, reason="ok")]), tmp_path=tmp_path))
    assert final["article_limit"] is None and len(final["ranked_results"]) == 9


def test_model_cannot_invent_a_limit(tmp_path):
    """If the question mentions no number, a number from the planner model is ignored (real case:
    'Find me research articles on social and emotional learning' was limited to 10).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    plan = PLAN.model_copy(update={"requested_articles": 10})
    llm = FakeLLM(plan=plan, verdicts=[SufficiencyVerdict(sufficient=True, reason="ok")])
    final = run(make_planner(llm, tmp_path=tmp_path), goal="Find me research articles on social and emotional learning")
    assert final["article_limit"] is None
    assert final["research_plan"].acceptance_criteria.min_relevant_articles == PLAN.acceptance_criteria.min_relevant_articles
