"""Functional tests: whole features from the user's point of view (scripted models, no internet).

Section: Planner approval, FINAL RESULTS and the report.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

from pydantic import ValidationError

from App.journal import JournalStore
from App.models import (
    SearchPlan,
    SufficiencyVerdict,
)
from Tests.Support.workflow_fakes import PLAN, FakeLLM, make_planner, run


def test_report_is_a_document_for_the_reader(tmp_path):
    """The report has only Title, Overview, Key Findings, Ranked Sources and Reference List: no scores, models or program details.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    import re

    llm = FakeLLM(verdicts=[SufficiencyVerdict(sufficient=True, reason="Good coverage.")])
    final = run(make_planner(llm, tmp_path=tmp_path))
    report = open(final["report_path"], encoding="utf-8").read()

    assert final["report_path"].endswith("sleep-and-memory-a-review.md")  # named from the generated title
    assert report.startswith("# Sleep and Memory: A Review\n")
    assert re.findall(r"^## (.+)$", report, re.M) == ["Overview", "Key Findings", "Ranked Sources", "Reference List"]
    assert "Invented source." in report and "[99]" not in report and "[1]" not in report  # Harvard citations only
    for program_detail in ("Planner", "Score", "quality", "Methodology", "Appendix", "fake-qwen", "Limitations", "Journal/"):
        assert program_detail not in report


def test_review_uses_the_planners_own_criteria(tmp_path):
    """The planner reviews results against the criteria it set, measured in code and shown in its prompt.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    llm = FakeLLM(verdicts=[SufficiencyVerdict(sufficient=True, reason="Meets my criteria.")])
    final = run(make_planner(llm, tmp_path=tmp_path))

    review_prompt = next(p for s, p in llm.prompts if s is SufficiencyVerdict)
    assert "MET: At least 3 relevant articles (9 found)" in review_prompt
    assert "- Includes a review article" in review_prompt
    assert "search cycle 1 of 3" in review_prompt
    assert [c.criterion for c in final["evaluation"].criteria_checks][0] == "At least 3 relevant articles"


def test_measured_criteria_decide_if_the_model_review_fails(tmp_path):
    """If the planner model can't review, the measured criteria decide on their own.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    strict = PLAN.model_copy(update={"acceptance_criteria": PLAN.acceptance_criteria.model_copy(update={"min_relevant_articles": 20})})
    llm = FakeLLM(
        plan=strict,
        refinements=[SearchPlan(queries=[f"q{i}"], rationale="r") for i in range(2)],
        verdicts=[ValidationError.from_exception_data("SufficiencyVerdict", [])] * 3,
    )
    final = run(make_planner(llm, tmp_path=tmp_path))

    assert final["sufficient"] is False  # 9 + 3 + 3 = 15 articles < 20
    assert "decided on measured criteria only" in final["evaluation"].reason


def test_approval_then_final_results_then_authorised_storage(tmp_path):
    """Order is enforced: planner approves, processing writes FINAL RESULTS, planner authorises, storage writes.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    llm = FakeLLM(verdicts=[SufficiencyVerdict(sufficient=True, reason="Good.")])
    final = run(make_planner(llm, tmp_path=tmp_path))

    order = [e.message for e in final["activity_log"]]
    approve = next(i for i, m in enumerate(order) if m.startswith("Approved 9 results (approved)"))
    written = next(i for i, m in enumerate(order) if 'under "FINAL RESULTS"' in m)
    authorised = next(i for i, m in enumerate(order) if "Authorising the Storage Agent" in m)
    saved = next(i for i, m in enumerate(order) if m.startswith("Saved "))
    assert approve < written < authorised < saved
    assert final["storage_authorized"] is True


def test_final_results_are_the_last_section_of_the_journal(tmp_path):
    """The journal ends with a 'FINAL RESULTS' section holding the approved ranking.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    import json

    llm = FakeLLM(verdicts=[SufficiencyVerdict(sufficient=True, reason="Good.")])
    final = run(make_planner(llm, tmp_path=tmp_path))

    data = json.loads(open(final["journal_path"], encoding="utf-8").read())
    assert list(data)[-1] == "FINAL RESULTS"
    section = data["FINAL RESULTS"]
    assert section["title"] == "FINAL RESULTS"
    assert section["planner_approval"]["status"] == "approved"
    assert section["planner_approval"]["decided_by"] == "Planner Agent"
    assert len(section["ranked_results"]) == 9


def test_best_available_is_approved_and_labelled_after_three_cycles(tmp_path):
    """After 3 unsuccessful cycles the best results are approved and labelled 'best available' in the journal.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    not_ok = SufficiencyVerdict(sufficient=False, reason="Still weak.", gaps=["No review article"])
    llm = FakeLLM(refinements=[SearchPlan(queries=[f"q{i}"], rationale="r") for i in range(2)], verdicts=[not_ok] * 3)
    final = run(make_planner(llm, tmp_path=tmp_path))

    journal = JournalStore().load(final["journal_path"])
    assert journal.final_results.planner_approval.status == "best_available"
    assert "No review article" in journal.final_results.planner_approval.reason
    assert "Best available" not in open(final["report_path"], encoding="utf-8").read()  # program detail stays in the journal
