"""Functional tests: whole features from the user's point of view (scripted models, no internet).

Section: Agent activity logs during a research run.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import pytest

from App import config
from App.control import ResearchStopped, RunControl
from App.models import SufficiencyVerdict
from Tests.Support.workflow_fakes import FakeLLM, make_planner

AGENTS = ["Planner", "Retrieval", "Processing", "Storage"]


def run_and_read_logs(tmp_path, control=None, on_progress=None):
    planner = make_planner(FakeLLM(verdicts=[SufficiencyVerdict(sufficient=True, reason="Good.")]), tmp_path=tmp_path)
    path = planner.run("How does sleep affect memory?", control=control, on_progress=on_progress)
    return path, logs(planner)


def logs(planner) -> dict[str, str]:
    journal = next(planner.retrieval.journal_store.journal_dir.glob("*.json"))
    return {a: (config.AGENT_LOG_DIR / a / f"{journal.stem}.log").read_text() for a in AGENTS}


def test_every_agent_has_a_log_named_like_the_journal(tmp_path):
    """A run writes four logs (one per agent) that share the journal's date-and-time name.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    _, by_agent = run_and_read_logs(tmp_path)
    assert all(text for text in by_agent.values())
    journal_name = next((tmp_path / "Journal").glob("*.json")).name
    for text in by_agent.values():
        assert f"Journal: Journal/{journal_name}" in text


def test_logs_record_the_question_steps_decisions_and_time(tmp_path):
    """Each log has the question, each step with its duration, what the agent did, and its time used.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    path, by_agent = run_and_read_logs(tmp_path)
    for agent, text in by_agent.items():
        assert "Question: How does sleep affect memory?" in text
        assert "Step started (cycle 1)" in text and "Step finished in" in text
        assert "Time used:" in text and f"Run finished. Report: {config.shown_path(path)}" in text
    assert "Broke the question into 2 subtasks" in by_agent["Planner"]
    assert "Approved 9 results" in by_agent["Planner"]
    assert "Retrieval complete: pulled 9 articles" in by_agent["Retrieval"]
    assert "Read 9 raw results from the journal" in by_agent["Processing"]
    assert 'under "FINAL RESULTS"' in by_agent["Processing"]
    assert f"Saved the report to {config.shown_path(path)}" in by_agent["Storage"]


def test_logs_record_a_stop(tmp_path):
    """Pressing Stop is recorded in the logs.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    planner = make_planner(FakeLLM(verdicts=[SufficiencyVerdict(sufficient=True, reason="Good.")]), tmp_path=tmp_path)
    control = RunControl()

    def progress(message):
        if message.startswith("Processing agent is ranking"):
            control.stop()

    with pytest.raises(ResearchStopped):
        planner.run("How does sleep affect memory?", control=control, on_progress=progress)
    by_agent = logs(planner)
    assert "WARN   Run stopped by the user." in by_agent["Planner"]
    assert "Storage" in by_agent and "Saved the report" not in by_agent["Storage"]


def test_logs_record_errors(tmp_path):
    """A step that fails is recorded as an ERROR in that agent's log.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    planner = make_planner(FakeLLM(verdicts=[SufficiencyVerdict(sufficient=True, reason="Good.")]), tmp_path=tmp_path)
    planner.storage.run = lambda state: (_ for _ in ()).throw(RuntimeError("disk full"))
    planner.graph = planner.build_graph()  # the workflow is assembled from the agents' steps
    with pytest.raises(RuntimeError):
        planner.run("How does sleep affect memory?")
    assert "ERROR  Step failed: RuntimeError: disk full" in logs(planner)["Storage"]
