"""Functional tests: whole features from the user's point of view (scripted models, no internet).

Section: Using the window: asking a question, results, pop-ups and settings.

The research itself is replaced by a stand-in planner so these tests check the
window's behaviour only (the research workflow has its own functional tests).

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import time

import pytest

from App.control import ResearchStopped
import interface


class StandInPlanner:
    """Replaces PlannerAgent in the window: records what it was asked and writes a small report.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    calls: list[dict] = []
    behaviour = "report"  # or "error", "ask", "stopped"
    report_dir = None

    def __init__(self, models=None):
        self.models = models

    def run(self, goal, on_progress=None, ask_permission=None, language="en", control=None):
        StandInPlanner.calls.append({"goal": goal, "language": language, "models": self.models})
        on_progress("Planning agent is breaking down your question")
        if self.behaviour == "error":
            raise RuntimeError("Model 'qwen3.5:9b' isn't pulled. Run: ollama pull qwen3.5:9b")
        if self.behaviour == "stopped":
            raise ResearchStopped()
        if self.behaviour == "ask":
            StandInPlanner.calls[-1]["allowed"] = ask_permission("Allow each agent up to 10m 00s?")
        path = self.report_dir / "sleep-and-memory.md"
        path.write_text("# Sleep and Memory\n\n## Overview\n\nSleep helps memory (Smith, 2020).\n\n## Reference List\n\n"
                        "Smith, A. (2020) 'Sleep', *Journal of Sleep*.\n")
        return path


@pytest.fixture
def stand_in(monkeypatch, tmp_path):
    StandInPlanner.calls, StandInPlanner.behaviour, StandInPlanner.report_dir = [], "report", tmp_path
    monkeypatch.setattr(interface, "PlannerAgent", StandInPlanner)
    return StandInPlanner


def wait_until_idle(app, seconds=5):
    start = time.time()
    while app.busy and time.time() - start < seconds:
        app.root.update()
        time.sleep(0.02)


def ask(app, question):
    app.prompt.delete("1.0", "end")
    app.prompt.insert("1.0", question)
    app.submit()


def test_asking_a_question_shows_the_results_button(window, stand_in):
    """Enter a question -> the agents run -> 'Your research results are available' + button enabled.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    ask(window, "How does sleep affect memory?")
    assert window.busy and str(window.stop_button.cget("state")) == "normal"
    assert str(window.language.cget("state")) == "disabled"  # settings locked while running
    wait_until_idle(window)
    assert window.results_notice.cget("text") == "Your research results are available"
    assert str(window.results_button.cget("state")) == "normal"
    assert window.assist.text() == ""  # box cleared for the next question
    assert stand_in.calls[0]["goal"] == "How does sleep affect memory?"
    assert stand_in.calls[0]["models"]["planner"] == "deepseek-r1:8b"


def test_results_viewer_shows_the_report(window, stand_in):
    """'View Research Results' opens the report with headings and italics formatted.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    ask(window, "How does sleep affect memory?")
    wait_until_idle(window)
    window.view_results()
    viewer = next(w for w in window.root.winfo_children() if isinstance(w, interface.ResultsViewer))
    text_widget = viewer.text
    shown = text_widget.get("1.0", "end")
    assert "Sleep and Memory" in shown and "*" not in shown  # Markdown symbols are rendered, not shown
    assert text_widget.tag_ranges("italic") and text_widget.tag_ranges("h1")
    viewer.destroy()


def test_errors_are_shown_in_the_window(window, stand_in):
    """If something goes wrong, the window says what, and is ready for another try.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    stand_in.behaviour = "error"
    ask(window, "How does sleep affect memory?")
    wait_until_idle(window)
    assert window.status.cget("text").startswith("Something went wrong: RuntimeError: Model 'qwen3.5:9b' isn't pulled")
    assert str(window.send_button.cget("state")) == "normal" and str(window.results_button.cget("state")) == "disabled"


def test_a_stopped_run_says_so(window, stand_in):
    """A run that ends because of Stop shows 'Stopped', not an error.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    stand_in.behaviour = "stopped"
    ask(window, "How does sleep affect memory?")
    wait_until_idle(window)
    assert window.status.cget("text").startswith("Stopped")


def test_language_mismatch_can_switch_the_research_language(window, stand_in, monkeypatch):
    """A French question with English selected -> pop-up -> Yes switches to French research.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    monkeypatch.setattr(interface.messagebox, "askyesnocancel", lambda *a, **k: True)
    ask(window, "Qu'est-ce que la matière noire et comment la détecte-t-on ?")
    wait_until_idle(window)
    assert window.language.get() == "Français" and stand_in.calls[0]["language"] == "fr"
    assert window.assist.assistant.language == "fr"  # the spell checker switched to French too


def test_language_mismatch_cancel_does_not_start(window, stand_in, monkeypatch):
    """Cancel on the language pop-up starts nothing.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    monkeypatch.setattr(interface.messagebox, "askyesnocancel", lambda *a, **k: None)
    ask(window, "Qu'est-ce que la matière noire et comment la détecte-t-on ?")
    assert not window.busy and stand_in.calls == []


def test_extra_time_pop_up_answer_reaches_the_planner(window, stand_in, monkeypatch):
    """The planner's 'allow more time?' question is shown as a Yes/No pop-up; the answer is passed back.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    stand_in.behaviour = "ask"
    monkeypatch.setattr(interface.messagebox, "askyesno", lambda *a, **k: True)
    ask(window, "Compare every study on bilingual education outcomes")
    wait_until_idle(window)
    assert stand_in.calls[0]["allowed"] is True


def test_chosen_models_are_used(window, stand_in):
    """Models picked in Settings are the ones the agents use.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    window.model_boxes["processing"].set("llama3.1:8b")
    window.model_boxes["storage"].set("gemma4:e4b")
    ask(window, "How does sleep affect memory?")
    wait_until_idle(window)
    models = stand_in.calls[0]["models"]
    assert (models["planner"], models["retrieval"], models["processing"], models["storage"]) == (
        "deepseek-r1:8b", "qwen3.5:9b", "llama3.1:8b", "gemma4:e4b",
    )


def test_cloud_model_names_are_refused(window, monkeypatch):
    """Typing a cloud model name shows a warning and puts the default model back.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    warnings = []
    monkeypatch.setattr(interface.messagebox, "showwarning", lambda *a, **k: warnings.append(a))
    window.model_boxes["planner"].set("kimi-k3:cloud")
    window._on_model_changed("planner")
    assert warnings and window.selected_models()["planner"] == "deepseek-r1:8b"


def test_reset_to_defaults(window):
    """'Reset to defaults' puts English and the default models back.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    window.language.set("Deutsch")
    window.model_boxes["planner"].set("llama3.1:8b")
    window._reset_settings()
    assert window.selected_language() == "en" and window.selected_models()["planner"] == "deepseek-r1:8b"


def test_empty_question_does_nothing(window, stand_in):
    """Pressing Enter on an empty box starts nothing.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    ask(window, "   ")
    assert not window.busy and stand_in.calls == []


def test_only_one_progress_animation_runs(window, stand_in):
    """Stopping and immediately asking again doesn't leave two progress animations running.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    stand_in.behaviour = "stopped"
    ask(window, "How does sleep affect memory?")
    window.stop()
    ask(window, "How does sleep affect memory?")
    jobs = [j for j in window.root.tk.call("after", "info") if "animate_ellipsis" in str(window.root.tk.call("after", "info", j))]
    assert len(jobs) <= 1
    wait_until_idle(window)


def test_status_line_reports_a_bad_model_name(monkeypatch):
    """A model name that can't be used is reported on the status line instead of the check failing silently.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    monkeypatch.setattr("App.llm.OllamaLLM.check_health", lambda self: (True, "ok"))
    ok, message = interface.check_models({"planner": "deepseek-r1:8b", "storage": "kimi-k3:cloud"})
    assert not ok and "Only local models can be used" in message
    assert interface.check_models({"planner": "deepseek-r1:8b", "storage": "qwen3.5:9b"}) == (
        True, "Ollama ready · deepseek-r1:8b, qwen3.5:9b",
    )


def test_window_keeps_working_after_an_error_in_a_message(window, stand_in, monkeypatch):
    """If handling a message from the research fails, the window still finishes the run, shows
    the error, saves the details, and accepts another question.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    from App import config

    real_finish = window._finish
    calls = []

    def broken_once(**kwargs):
        if not calls:
            calls.append(1)
            raise RuntimeError("simulated window error")
        return real_finish(**kwargs)

    monkeypatch.setattr(window, "_finish", broken_once)
    ask(window, "How does sleep affect memory?")
    for _ in range(100):  # let the run finish and the failing message be handled
        window.root.update()
        time.sleep(0.02)
    assert "Something went wrong in the window: RuntimeError: simulated window error" in window.status.cget("text")
    saved = list((config.AGENT_LOG_DIR / "Interface").glob("*.log"))
    assert saved and "simulated window error" in saved[0].read_text()

    window.reset()  # the user can reset and ask again
    ask(window, "What is dark matter?")
    wait_until_idle(window)
    assert window.results_notice.cget("text") == "Your research results are available"
    assert len(stand_in.calls) == 2


def test_errors_in_buttons_are_reported_not_lost(window):
    """An error inside a button's action (e.g. Reset) is shown on the status line and the window stays usable.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    window.busy = False
    try:
        raise ValueError("button failed")
    except ValueError as exc:
        window.report_ui_error(exc)
    assert "ValueError: button failed" in window.status.cget("text")
    assert str(window.prompt.cget("state")) == "normal" and str(window.send_button.cget("state")) == "normal"


def test_question_box_gets_keyboard_focus_after_a_run(window, stand_in):
    """After a run, typing goes straight into the question box (macOS doesn't always restore focus itself).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    window.root.deiconify()
    ask(window, "How does sleep affect memory?")
    wait_until_idle(window)
    window.root.update()
    assert window.root.focus_get() is window.prompt
    window.root.withdraw()
