"""Run the test suite and write a report you can use in your documentation.

    .venv/bin/python Tests/run_tests.py              unit + functional tests, with code coverage
    .venv/bin/python Tests/run_tests.py --live       also the live tests (real models and APIs, ~15 min)
    .venv/bin/python Tests/run_tests.py --only unit  just one group: unit, functional or live

Each run creates Tests/Reports/<date_time>/ containing:
    report.md    the report (summary, coverage, every test with its result and time)
    report.html  the same report, styled for a browser (print it to PDF)
    results.csv  one row per test, for a spreadsheet or a table in Word

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import argparse
import csv
from datetime import datetime
import html
from importlib import metadata
from pathlib import Path
import platform
import re
import sys
import time

import coverage
import pytest

ROOT = Path(__file__).resolve().parent.parent
REPORTS = ROOT / "Tests" / "Reports"
GROUPS = {
    "unit": ("Unit tests", "One function or class at a time, in isolation (no Ollama, no internet)."),
    "functional": ("Functional tests", "Whole features from the user's point of view, with scripted models and recorded API responses."),
    "live": ("Live tests", "The real Ollama models and the real arXiv / OpenAlex / CORE APIs."),
}
PACKAGES = ["langgraph", "pydantic", "ollama", "httpx", "tenacity", "pyspellchecker", "pytest", "coverage"]


class Collector:
    """A pytest plugin that records every test's description, result, time and outputs.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    def __init__(self):
        self.tests: dict[str, dict] = {}

    def pytest_collection_finish(self, session):
        for item in session.items:
            module_doc = (item.module.__doc__ or "").strip()
            section = re.search(r"Section:\s*(.+?)\.?\s*$", module_doc, re.M)
            doc = (getattr(item, "function", None).__doc__ or "").strip().splitlines()
            group = next((g for g in GROUPS if item.get_closest_marker(g)), "other")
            name = item.name.removeprefix("test_")
            params = ""
            if "[" in name:
                name, params = name.split("[", 1)
                params = params.rstrip("]")
            readable = name.replace("_", " ").capitalize() + (f" ({params})" if params else "")
            self.tests[item.nodeid] = {
                "group": group,
                "file": str(item.path.relative_to(ROOT)),
                "section": section.group(1).strip() if section else item.path.stem,
                "test": readable,
                "description": doc[0] if doc else "",
                "function": item.name,
                "result": "not run",
                "seconds": 0.0,
                "outputs": {},
                "error": "",
            }

    def pytest_runtest_logreport(self, report):
        test = self.tests.get(report.nodeid)
        if test is None:
            return
        test["seconds"] += report.duration
        if report.user_properties:
            test["outputs"].update(dict(report.user_properties))
        if report.skipped:
            test["result"] = "skipped"
            reason = report.longrepr[2] if isinstance(report.longrepr, tuple) else str(report.longrepr)
            test["error"] = reason.removeprefix("Skipped: ")
        elif report.failed:
            test["result"] = "failed"
            test["error"] = str(report.longrepr)[-1500:]
        elif report.when == "call" and test["result"] == "not run":
            test["result"] = "passed"


SYMBOL = {"passed": "✅ Passed", "failed": "❌ Failed", "skipped": "⏭ Skipped", "not run": "Not run"}


def md_escape(text: str) -> str:
    return str(text).replace("|", "\\|").replace("\n", " ")


def summarise(tests: list[dict]) -> dict:
    return {
        "total": len(tests),
        "passed": sum(t["result"] == "passed" for t in tests),
        "failed": sum(t["result"] == "failed" for t in tests),
        "skipped": sum(t["result"] == "skipped" for t in tests),
        "seconds": sum(t["seconds"] for t in tests),
    }


def coverage_rows(cov: coverage.Coverage) -> list[tuple[str, int, int, float]]:
    rows = []
    data = cov.get_data()
    for filename in sorted(data.measured_files()):
        path = Path(filename)
        try:
            relative = path.relative_to(ROOT)
        except ValueError:
            continue
        _, statements, _, missing, _ = cov.analysis2(filename)
        if statements:
            rows.append((str(relative), len(statements), len(missing), 100 * (len(statements) - len(missing)) / len(statements)))
    return rows


def build_markdown(tests: list[dict], coverage_table, started: datetime, command: str) -> str:
    lines = [
        "# Test Report: Academic Research Tool",
        "",
        f"**Date:** {started:%d %B %Y, %H:%M}  ",
        f"**Command:** `{command}`  ",
        f"**Python:** {platform.python_version()} · **System:** {platform.system()} {platform.release()} ({platform.machine()})  ",
        "**Packages:** " + ", ".join(f"{p} {version(p)}" for p in PACKAGES),
        "",
        "## Summary",
        "",
        "| Test type | What it covers | Tests | Passed | Failed | Skipped | Time |",
        "|---|---|---:|---:|---:|---:|---:|",
    ]
    for group, (title, covers) in GROUPS.items():
        s = summarise([t for t in tests if t["group"] == group])
        if s["total"]:
            lines.append(f"| {title} | {covers} | {s['total']} | {s['passed']} | {s['failed']} | {s['skipped']} | {s['seconds']:.1f} s |")
    s = summarise(tests)
    lines.append(f"| **Total** | | **{s['total']}** | **{s['passed']}** | **{s['failed']}** | **{s['skipped']}** | **{s['seconds']:.1f} s** |")

    if coverage_table:
        total_statements = sum(r[1] for r in coverage_table)
        total_missing = sum(r[2] for r in coverage_table)
        lines += [
            "",
            "## Code coverage",
            "",
            "The share of each file's code that the tests ran (statements).",
            "",
            "| File | Statements | Not run | Coverage |",
            "|---|---:|---:|---:|",
        ]
        lines += [f"| `{f}` | {n} | {m} | {c:.0f}% |" for f, n, m, c in coverage_table]
        lines.append(f"| **Total** | **{total_statements}** | **{total_missing}** | "
                     f"**{100 * (total_statements - total_missing) / total_statements:.0f}%** |")

    for group, (title, covers) in GROUPS.items():
        group_tests = [t for t in tests if t["group"] == group]
        if not group_tests:
            continue
        lines += ["", f"## {title}", "", covers]
        sections: dict[tuple[str, str], list[dict]] = {}
        for t in group_tests:
            sections.setdefault((t["section"], t["file"]), []).append(t)
        for (section, file), section_tests in sections.items():
            with_outputs = any(t["outputs"] for t in section_tests)
            lines += ["", f"### {section[:1].upper() + section[1:]}", f"`{file}`", ""]
            header = "| # | Test | What it checks | Result | Time |" + (" Outputs |" if with_outputs else "")
            lines += [header, "|---:|---|---|---|---:|" + ("---|" if with_outputs else "")]
            for i, t in enumerate(section_tests, 1):
                row = (f"| {i} | {md_escape(t['test'])} | {md_escape(t['description'])} | {SYMBOL[t['result']]} | "
                       f"{t['seconds']:.2f} s |")
                if with_outputs:
                    row += " " + md_escape("; ".join(f"{k}: {v}" for k, v in t["outputs"].items())) + " |"
                lines.append(row)

    problems = [t for t in tests if t["result"] == "failed"]
    if problems:
        lines += ["", "## Failures", ""]
        for t in problems:
            lines += [f"### {t['test']}", f"`{t['file']}::{t['function']}`", "", "```", t["error"].strip(), "```", ""]
    skipped = [t for t in tests if t["result"] == "skipped"]
    if skipped:
        reasons = sorted({t["error"] for t in skipped})
        lines += ["", "## Skipped tests", ""] + [f"- {r}" for r in reasons]
    return "\n".join(lines) + "\n"


def build_html(markdown_text: str) -> str:
    """A small Markdown-to-HTML conversion for this report's own layout (headings, tables, code).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    out, in_table, in_code = [], False, False
    for line in markdown_text.splitlines():
        if line.startswith("```"):
            out.append("</pre>" if in_code else "<pre>")
            in_code = not in_code
            continue
        if in_code:
            out.append(html.escape(line))
            continue
        if line.startswith("|"):
            cells = [c.strip() for c in re.split(r"(?<!\\)\|", line.strip())[1:-1]]
            if all(re.fullmatch(r"-+:?", c) for c in cells):
                continue
            tag = "th" if not in_table else "td"
            if not in_table:
                out.append("<table>")
                in_table = True
            out.append("<tr>" + "".join(f"<{tag}>{inline(c)}</{tag}>" for c in cells) + "</tr>")
            continue
        if in_table:
            out.append("</table>")
            in_table = False
        heading = re.match(r"^(#{1,3}) (.*)", line)
        if heading:
            level = len(heading.group(1))
            out.append(f"<h{level}>{inline(heading.group(2))}</h{level}>")
        elif line.startswith("- "):
            out.append(f"<li>{inline(line[2:])}</li>")
        elif line.strip():
            out.append(f"<p>{inline(line)}</p>")
    if in_table:
        out.append("</table>")
    style = """
      body { font-family: -apple-system, Helvetica, Arial, sans-serif; max-width: 1100px; margin: 32px auto;
             padding: 0 16px; color: #1d1d1f; background: #ffffff; line-height: 1.45; }
      h1 { font-size: 26px; } h2 { margin-top: 32px; border-bottom: 1px solid #ddd; padding-bottom: 4px; }
      h3 { margin-bottom: 2px; } p code, td code { background: #f3f3f3; padding: 1px 4px; border-radius: 4px; }
      table { border-collapse: collapse; width: 100%; margin: 8px 0 16px; font-size: 13px; }
      th, td { border: 1px solid #ddd; padding: 5px 8px; text-align: left; vertical-align: top; }
      th { background: #f5f5f7; } tr:nth-child(even) td { background: #fafafa; }
      td:nth-child(n+4):not(:last-child), td:last-child:nth-child(5) { white-space: nowrap; }
      pre { background: #f6f6f6; padding: 12px; overflow-x: auto; font-size: 12px; }
      @media print { body { margin: 0; max-width: none; } h2 { page-break-after: avoid; } tr { page-break-inside: avoid; } }
    """
    return (f"<!doctype html><html><head><meta charset='utf-8'><title>Test Report</title><style>{style}</style></head>"
            f"<body>{''.join(out)}</body></html>\n")


def inline(text: str) -> str:
    text = html.escape(text.replace("\\|", "|"))
    text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
    return re.sub(r"`(.+?)`", r"<code>\1</code>", text)


def version(package: str) -> str:
    try:
        return metadata.version(package)
    except metadata.PackageNotFoundError:
        return "not installed"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--live", action="store_true", help="also run the live tests (real models and APIs)")
    parser.add_argument("--only", choices=list(GROUPS), help="run just one group of tests")
    parser.add_argument("--no-coverage", action="store_true", help="skip measuring code coverage")
    args = parser.parse_args()

    sys.path.insert(0, str(ROOT))
    pytest_args = [str(ROOT / "Tests"), "-q", "-p", "no:cacheprovider"]
    if args.live or args.only == "live":
        pytest_args.append("--live")
    if args.only:
        pytest_args += ["-m", args.only]
    command = "python Tests/run_tests.py " + " ".join(a for a in sys.argv[1:])

    cov = None
    if not args.no_coverage:
        cov = coverage.Coverage(include=[str(ROOT / "Agents" / "*"), str(ROOT / "App" / "*"), str(ROOT / "interface.py")],
                                data_file=None)
        cov.start()
    started = datetime.now()
    clock = time.monotonic()
    collector = Collector()
    exit_code = pytest.main(pytest_args, plugins=[collector])
    elapsed = time.monotonic() - clock
    coverage_table = None
    if cov:
        cov.stop()
        coverage_table = coverage_rows(cov)

    tests = list(collector.tests.values())
    folder = REPORTS / started.strftime("%Y-%m-%d_%H-%M-%S")
    folder.mkdir(parents=True, exist_ok=True)
    markdown_text = build_markdown(tests, coverage_table, started, command.strip())
    (folder / "report.md").write_text(markdown_text, encoding="utf-8")
    (folder / "report.html").write_text(build_html(markdown_text), encoding="utf-8")
    with open(folder / "results.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Type", "Section", "File", "Test", "What it checks", "Result", "Seconds", "Outputs", "Message"])
        for t in tests:
            writer.writerow([GROUPS.get(t["group"], ("Other",))[0], t["section"], t["file"], t["test"], t["description"],
                             t["result"], f"{t['seconds']:.2f}", "; ".join(f"{k}: {v}" for k, v in t["outputs"].items()),
                             t["error"][:300]])

    s = summarise(tests)
    print(f"\n{s['passed']} passed, {s['failed']} failed, {s['skipped']} skipped in {elapsed:.0f}s")
    print(f"Report written to {folder.relative_to(ROOT)}/ (report.md, report.html, results.csv)")
    return int(exit_code)


if __name__ == "__main__":
    sys.exit(main())
