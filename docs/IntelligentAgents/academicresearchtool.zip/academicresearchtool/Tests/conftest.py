"""Shared pytest set-up.

Tests are grouped by folder, and each test is labelled ("marked") by its folder so a
group can be run on its own:

    Tests/Unit/        unit tests        .venv/bin/python -m pytest Tests -m unit
    Tests/Functional/  functional tests  .venv/bin/python -m pytest Tests -m functional
    Tests/Live/        live tests        .venv/bin/python -m pytest Tests --live -m live

Live tests use the real Ollama models and the real arXiv / OpenAlex / CORE APIs, so
they are slow and need the internet; they are skipped unless ``--live`` is given.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import pytest

from App import config as app_config

# Shared fixtures (window, assistant, agent_factory) live in these helper modules.
pytest_plugins = ["Tests.Support.typing_fakes", "Tests.Support.retrieval_fakes"]

FOLDER_MARKS = {"Unit": "unit", "Functional": "functional", "Live": "live"}


def pytest_addoption(parser):
    parser.addoption("--live", action="store_true", help="also run the live tests (real models and APIs)")


def pytest_configure(config):
    config.addinivalue_line("markers", "unit: tests one function or class in isolation")
    config.addinivalue_line("markers", "functional: tests a whole feature from the user's point of view")
    config.addinivalue_line("markers", "live: uses the real Ollama models and scholarly APIs (needs --live)")


def pytest_collection_modifyitems(config, items):
    skip_live = pytest.mark.skip(reason="live test: run with --live (needs Ollama and the internet)")
    for item in items:
        for folder, mark in FOLDER_MARKS.items():
            if f"/{folder}/" in str(item.path).replace("\\", "/"):
                item.add_marker(getattr(pytest.mark, mark))
                if mark == "live" and not config.getoption("--live"):
                    item.add_marker(skip_live)


@pytest.fixture(autouse=True)
def keep_test_files_out_of_the_project(tmp_path_factory, monkeypatch):
    """Tests never write into the real Agents/Logs, Journal or Results folders.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    scratch = tmp_path_factory.mktemp("project")
    monkeypatch.setattr(app_config, "AGENT_LOG_DIR", scratch / "Agents" / "Logs")
    monkeypatch.setattr(app_config, "JOURNAL_DIR", scratch / "Journal")
    monkeypatch.setattr(app_config, "RESULTS_DIR", scratch / "Results")
