"""Desktop interface for the Academic Research Tool.

Run with:  .venv/bin/python interface.py

The user types a prompt and presses Enter (or the ➤ button). The
question is sent to the Planner Agent, while the user can see the status of the 
agents working. If the planner wants more time than usual for a big question, 
a pop-up asks first. 

When the report is ready, the "View Research Results" button opens it.

While the agents work, Pause holds the run at the next safe point (Resume carries
on), Stop ends it straight away, and Reset stops it and clears the window so a
new question can be asked.

The question box spell-checks (red underline; right-click for suggestions),
autocorrects clear typos (⌘Z undoes), and autofills: grey suggested text from past
questions and common words, accepted with Tab or →. Both can be turned off in
Settings.

Settings (below the results button): the research language (English by default)
and the model each agent uses (DeepSeek R1 plans, Qwen 3.5 does the rest by
default. Llama and Gemma can be chosen, or any local Ollama model name typed in).

Only local models are allowed. If the user would like to use additonal models, 
they can install them under the Ollama provider and select them from the menu. 

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026). 
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import queue
import re
import subprocess
import sys
import threading
import time
import tkinter as tk
import traceback
from datetime import datetime
from pathlib import Path
from tkinter import messagebox, ttk
from tkinter.scrolledtext import ScrolledText

from App import config
from App.budget import format_seconds
from App.control import ResearchStopped, RunControl
from App.languages import DEFAULT_LANGUAGE, LANGUAGES, detect_language
from App.model_catalog import CATALOG, DEFAULT_MODELS, ROLE_LABELS, ROLES, is_cloud_model, make_llm
from App.typing_aids import TypingAssistant
from Agents.plan import PlannerAgent

POLL_MS = 100
ELLIPSIS_MS = 400


class ResearchApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.events: queue.Queue[tuple[str, object]] = queue.Queue()
        self.busy = False
        self.dots = 0
        self.stage = ""
        self.report_path: Path | None = None
        self._health_job: str | None = None
        self._ellipsis_job: str | None = None
        self.control: RunControl | None = None
        self.run_id = 0  # events from a stopped run are ignored
        self.paused_total = 0.0
        self.pause_started: float | None = None

        root.title("Academic Research Tool")
        root.geometry("680x600")
        root.minsize(560, 540)
        self._last_goal = ""
        self._build_widgets()
        self.assist = PromptAssist(
            self.prompt, self.hint, self.selected_language, self.spellcheck_on, self.autofill_on
        )

        self._check_ollama()
        self.root.after(POLL_MS, self._poll_events)

    # ---- Layout ---------------------------------------------------------

    def _build_widgets(self) -> None:
        frame = ttk.Frame(self.root, padding=20)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(0, weight=1)

        ttk.Label(frame, text="Academic Research Tool", font=("Helvetica", 18, "bold")).grid(row=0, column=0, sticky="w")
        ttk.Label(frame, text="What would you like to research?").grid(row=1, column=0, sticky="w", pady=(4, 8))

        # Prompt entry with the arrow (submit) button on its right
        entry_row = ttk.Frame(frame)
        entry_row.grid(row=2, column=0, sticky="ew")
        entry_row.columnconfigure(0, weight=1)

        self.prompt = tk.Text(entry_row, height=4, wrap="word", font=("Helvetica", 13), padx=8, pady=6, undo=True)
        self.prompt.grid(row=0, column=0, sticky="ew")
        self.prompt.bind("<Return>", self._on_enter)
        self.prompt.bind("<Shift-Return>", self._on_shift_enter)  # allow newlines with Shift+Enter
        self.prompt.focus_set()

        self.send_button = ttk.Button(entry_row, text="➤", width=3, command=self.submit)
        self.send_button.grid(row=0, column=1, sticky="ns", padx=(8, 0))

        self.hint = ttk.Label(frame, text=HINT, foreground="gray")
        self.hint.grid(row=3, column=0, sticky="w", pady=(4, 0))

        # Busy indicator (animated ellipsis)
        self.status = ttk.Label(frame, text="", font=("Helvetica", 13))
        self.status.grid(row=4, column=0, sticky="w", pady=(16, 0))

        # Pause / Stop / Reset
        controls = ttk.Frame(frame)
        controls.grid(row=5, column=0, sticky="w", pady=(8, 0))
        self.pause_button = ttk.Button(controls, text="⏸ Pause", command=self.toggle_pause, state="disabled")
        self.pause_button.pack(side="left")
        self.stop_button = ttk.Button(controls, text="⏹ Stop", command=self.stop, state="disabled")
        self.stop_button.pack(side="left", padx=8)
        self.reset_button = ttk.Button(controls, text="↺ Reset", command=self.reset)
        self.reset_button.pack(side="left")

        # Results notice + button, below the prompt entry
        self.results_notice = ttk.Label(frame, text="", font=("Helvetica", 13, "bold"), foreground="#1a7f37")
        self.results_notice.grid(row=6, column=0, sticky="w", pady=(8, 4))

        self.results_button = ttk.Button(frame, text="View Research Results", command=self.view_results, state="disabled")
        self.results_button.grid(row=7, column=0, sticky="w")

        frame.rowconfigure(8, weight=1)
        self._build_settings(frame).grid(row=9, column=0, sticky="ew", pady=(12, 8))

        # Ollama health line at the bottom
        self.ollama_status = ttk.Label(frame, text="Checking Ollama…", foreground="gray", wraplength=620)
        self.ollama_status.grid(row=10, column=0, sticky="sw")

    def _build_settings(self, parent: ttk.Frame) -> ttk.LabelFrame:
        """Research language and the model for each agent.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        box = ttk.LabelFrame(parent, text="Settings", padding=10)
        box.columnconfigure(1, weight=1)
        box.columnconfigure(3, weight=1)

        ttk.Label(box, text="Research language:").grid(row=0, column=0, sticky="w", padx=(0, 8))
        self.language_names = {lang.native: code for code, lang in LANGUAGES.items()}
        self.language = ttk.Combobox(box, values=list(self.language_names), state="readonly", width=18)
        self.language.set(LANGUAGES[DEFAULT_LANGUAGE].native)
        self.language.grid(row=0, column=1, sticky="w")
        self.language.bind("<<ComboboxSelected>>", lambda e: self.assist.language_changed())

        toggles = ttk.Frame(box)
        toggles.grid(row=0, column=2, columnspan=2, sticky="e")
        self.spellcheck_on = tk.BooleanVar(value=True)
        self.autofill_on = tk.BooleanVar(value=True)
        ttk.Checkbutton(
            toggles, text="Spell check & autocorrect", variable=self.spellcheck_on, command=lambda: self.assist.refresh()
        ).pack(side="left")
        ttk.Checkbutton(
            toggles, text="Autofill", variable=self.autofill_on, command=lambda: self.assist.refresh()
        ).pack(side="left", padx=(12, 0))

        ttk.Label(box, text="Models (pick one, or type any local Ollama model name):", foreground="gray").grid(
            row=1, column=0, columnspan=4, sticky="w", pady=(10, 4)
        )
        self.model_boxes: dict[str, ttk.Combobox] = {}
        tags = [option.tag for option in CATALOG]
        for i, role in enumerate(ROLES):
            row, col = 2 + i // 2, (i % 2) * 2
            ttk.Label(box, text=f"{ROLE_LABELS[role]} agent:").grid(row=row, column=col, sticky="w", padx=(0, 8), pady=2)
            combo = ttk.Combobox(box, values=tags, width=20)
            combo.set(DEFAULT_MODELS[role])
            combo.grid(row=row, column=col + 1, sticky="ew", padx=(0, 16), pady=2)
            combo.bind("<<ComboboxSelected>>", lambda e, r=role: self._on_model_changed(r))
            combo.bind("<FocusOut>", lambda e, r=role: self._on_model_changed(r))
            self.model_boxes[role] = combo

        ttk.Button(box, text="Reset to defaults", command=self._reset_settings).grid(
            row=4, column=0, columnspan=4, sticky="w", pady=(8, 0)
        )
        return box

    def selected_language(self) -> str:
        return self.language_names.get(self.language.get(), DEFAULT_LANGUAGE)

    def selected_models(self) -> dict[str, str]:
        return {role: (box.get().strip() or DEFAULT_MODELS[role]) for role, box in self.model_boxes.items()}

    def _reset_settings(self) -> None:
        self.language.set(LANGUAGES[DEFAULT_LANGUAGE].native)
        self.assist.language_changed()
        for role, box in self.model_boxes.items():
            box.set(DEFAULT_MODELS[role])
        self._schedule_health_check()

    def _on_model_changed(self, role: str) -> None:
        tag = self.selected_models()[role]
        if is_cloud_model(tag):
            messagebox.showwarning(
                "Local models only",
                f"'{tag}' is a cloud model, which would send your research to an online service. "
                f"Only local models can be used, so the {ROLE_LABELS[role]} agent has been set back to "
                f"{DEFAULT_MODELS[role]}.",
                parent=self.root,
            )
            self.model_boxes[role].set(DEFAULT_MODELS[role])
        self._schedule_health_check()

    def _set_settings_enabled(self, enabled: bool) -> None:
        self.language.configure(state="readonly" if enabled else "disabled")
        for box in self.model_boxes.values():
            box.configure(state="normal" if enabled else "disabled")

    # ---- Submitting a prompt -------------------------------------------

    def _on_enter(self, event: tk.Event) -> str:
        self.assist.clear_suggestion()
        self.submit()
        return "break"  # stop Tk inserting a newline

    def _on_shift_enter(self, event: tk.Event) -> None:
        self.assist.clear_suggestion()  # then Tk inserts the newline as usual

    def submit(self) -> None:
        goal = self.assist.text().strip()
        if self.busy or not goal:
            return
        if not self._confirm_language(goal):
            return
        self._last_goal = goal
        language, models = self.selected_language(), self.selected_models()

        self.busy = True
        self.run_id += 1
        self.control = RunControl()
        self.paused_total, self.pause_started = 0.0, None
        self._set_settings_enabled(False)
        self.pause_button.configure(state="normal", text="⏸ Pause")
        self.stop_button.configure(state="normal")
        self.report_path = None
        self.prompt.configure(state="disabled")
        self.send_button.configure(state="disabled")
        self.results_button.configure(state="disabled")
        self.results_notice.configure(text="")
        self.stage = "Agents are working"
        self.started_at = time.monotonic()
        self._animate_ellipsis()

        threading.Thread(
            target=self._run_research, args=(goal, language, models, self.run_id, self.control), daemon=True
        ).start()

    def _confirm_language(self, goal: str) -> bool:
        """If the question looks like it's in another language than the one selected, ask
        whether to switch. Returns False if the user cancels.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        detected = detect_language(goal)
        selected = self.selected_language()
        if detected is None or detected == selected:
            return True
        found, chosen = LANGUAGES[detected], LANGUAGES[selected]
        answer = messagebox.askyesnocancel(
            "Research language",
            f"Your question looks like it's written in {found.native}, but the research language is "
            f"set to {chosen.native}.\n\nSwitch the research language to {found.native}?\n\n"
            f"Yes: research in {found.native}   No: keep {chosen.native}   Cancel: don't start",
            parent=self.root,
        )
        if answer is None:
            return False
        if answer:
            self.language.set(found.native)
            self.assist.language_changed()  # setting the menu from code doesn't fire its "selected" event
        return True

    def _run_research(self, goal: str, language: str, models: dict[str, str], run_id: int, control: RunControl) -> None:
        """Runs on a worker thread. Talks to the UI only through ``self.events``.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        try:
            path = PlannerAgent(models=models).run(
                goal,
                on_progress=lambda msg: self.events.put(("progress", (run_id, msg))),
                ask_permission=lambda message: self._ask_permission(message, run_id),
                language=language,
                control=control,
            )
            self.events.put(("done", (run_id, path)))
        except ResearchStopped:
            self.events.put(("stopped", (run_id, None)))
        except Exception as exc:  # surface any failure in the window
            self.events.put(("error", (run_id, f"{type(exc).__name__}: {exc}")))

    def _ask_permission(self, message: str, run_id: int) -> bool:
        """Called from the worker thread: show a Yes/No pop-up on the UI thread and wait for the answer.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        answer = {"allowed": False}
        answered = threading.Event()
        self.events.put(("ask", (run_id, (message, answer, answered))))
        answered.wait()
        return answer["allowed"]

    # ---- Pause / Stop / Reset ------------------------------------------

    def toggle_pause(self) -> None:
        if not self.busy or not self.control:
            return
        if self.control.paused:
            self.control.resume()
            if self.pause_started is not None:
                self.paused_total += time.monotonic() - self.pause_started
                self.pause_started = None
            self.pause_button.configure(text="⏸ Pause")
            self.stage = "Resuming"
        else:
            self.control.pause()
            self.pause_started = time.monotonic()
            self.pause_button.configure(text="▶ Resume")
            self.stage = "Pausing after the current step"

    def stop(self) -> None:
        """End the run now. The window is ready for a new question straight away.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        if not self.busy or not self.control:
            return
        self.control.stop()
        self.run_id += 1  # ignore anything the stopped run still reports
        self._finish(stopped=True)

    def reset(self) -> None:
        """Stop any run and clear the window back to the start.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        if self.busy:
            self.stop()
        self.prompt.configure(state="normal")
        self.prompt.delete("1.0", "end")
        self.assist.refresh()
        self.status.configure(text="")
        self.results_notice.configure(text="")
        self.results_button.configure(state="disabled")
        self.report_path = None
        self.prompt.focus_set()

    def _poll_events(self) -> None:
        """Handle messages from the research thread. Always schedules the next check, even if
        handling a message fails, so the window can never stop listening.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        try:
            while True:
                try:
                    kind, payload = self.events.get_nowait()
                except queue.Empty:
                    break
                try:
                    self._handle_event(kind, payload)
                except Exception as exc:  # one bad message must not break the window
                    if kind in ("done", "error", "stopped"):
                        # The run is over even if showing its result failed: never stay "busy".
                        self.busy, self.control = False, None
                    self.report_ui_error(exc)
        finally:
            self.root.after(POLL_MS, self._poll_events)

    def _handle_event(self, kind: str, payload) -> None:
        if kind == "ollama":
            ok, message = payload
            self.ollama_status.configure(text=("✓ " if ok else "⚠ ") + message, foreground="gray" if ok else "#b35900")
            return
        run_id, payload = payload
        if run_id != self.run_id:  # from a run that was stopped
            if kind == "ask":
                payload[2].set()  # unblock it; the answer stays "no"
            return
        if kind == "progress":
            self.stage = str(payload)
        elif kind == "ask":
            message, answer, answered = payload
            self.stage = "Waiting for your answer"
            try:
                answer["allowed"] = messagebox.askyesno("Allow more time?", message, parent=self.root)
            finally:
                self.stage = "Agents are working"
                answered.set()  # never leave the research waiting
        elif kind == "done":
            self._finish(report=payload)
        elif kind == "error":
            self._finish(error=str(payload))
        elif kind == "stopped":
            self._finish(stopped=True)

    def report_ui_error(self, exc: BaseException) -> None:
        """An unexpected error in the window: show it, save the details, and keep the window usable.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        details = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
        print(details, file=sys.stderr)
        saved = save_window_error(details)
        where = f" Details: {config.shown_path(saved)}" if saved else ""
        self.status.configure(text=f"Something went wrong in the window: {type(exc).__name__}: {exc}.{where}",
                              foreground="#c62828")
        if not self.busy:
            self._restore_controls()

    def _animate_ellipsis(self) -> None:
        # Only one animation loop at a time (a quick Stop-then-Enter would otherwise start a second one).
        if self._ellipsis_job:
            self.root.after_cancel(self._ellipsis_job)
            self._ellipsis_job = None
        if not self.busy:
            return
        self.dots = (self.dots % 3) + 1
        paused = self.paused_total + (time.monotonic() - self.pause_started if self.pause_started else 0.0)
        elapsed = format_seconds(time.monotonic() - self.started_at - paused)
        self.status.configure(text=f"{self.stage}{'.' * self.dots}  ({elapsed})", foreground="")
        self._ellipsis_job = self.root.after(ELLIPSIS_MS, self._animate_ellipsis)

    def _restore_controls(self) -> None:
        """Make the window ready for a new question.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        self._set_settings_enabled(True)
        self.prompt.configure(state="normal")
        self.send_button.configure(state="normal")
        self.pause_button.configure(state="disabled", text="⏸ Pause")
        self.stop_button.configure(state="disabled")
        # On macOS a text box that was disabled doesn't always get keyboard focus back by itself.
        self.prompt.focus_set()

    def _finish(self, report: Path | None = None, error: str | None = None, stopped: bool = False) -> None:
        self.busy = False
        self.control = None
        self._restore_controls()

        if stopped:
            self.status.configure(text="Stopped. Edit your question and press Enter to run it again.", foreground="gray")
            return
        if error:
            self.status.configure(text=f"Something went wrong: {error}", foreground="#c62828")
            return

        self.report_path = report
        self.status.configure(text="")
        self.results_notice.configure(text="Your research results are available")
        self.results_button.configure(state="normal")
        self.prompt.delete("1.0", "end")
        self.assist.remember_question(self._last_goal)

    # ---- Ollama health check -------------------------------------------

    def _schedule_health_check(self) -> None:
        """Re-check the selected models shortly after the user stops changing them.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        if self._health_job:
            self.root.after_cancel(self._health_job)
        self.ollama_status.configure(text="Checking Ollama…", foreground="gray")
        self._health_job = self.root.after(400, self._check_ollama)

    def _check_ollama(self) -> None:
        self._health_job = None
        models = self.selected_models()

        threading.Thread(target=lambda: self.events.put(("ollama", check_models(models))), daemon=True).start()

    # ---- Results viewer ------------------------------------------------

    def view_results(self) -> None:
        if not self.report_path or not self.report_path.exists():
            return
        ResultsViewer(self.root, self.report_path)


def check_models(models: dict[str, str]) -> tuple[bool, str]:
    """(ok, message) for the status line: is Ollama running and is every chosen model installed?

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    problems = []
    for role, tag in models.items():
        try:
            ok, message = make_llm(role, tag).check_health()
        except Exception as exc:  # e.g. a cloud model name: report it rather than fail silently
            ok, message = False, str(exc)
        if not ok:
            problems.append(message)
    if problems:
        return False, " · ".join(dict.fromkeys(problems))
    return True, f"Ollama ready · {', '.join(dict.fromkeys(models.values()))}"


HINT = "Press Enter to send · Shift+Enter for a new line · Tab accepts a suggestion"


class PromptAssist:
    """Spell check, autocorrect and autofill for the question box (a ``tk.Text``).

    The autofill suggestion is shown as grey text after the cursor. It is never part
    of the question unless accepted with Tab or →; any other key removes it.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    WORD_END_KEYS = {"space", "period", "comma", "question", "exclam", "semicolon", "colon"}

    def __init__(self, text: tk.Text, hint: ttk.Label, language, spellcheck_on: tk.BooleanVar, autofill_on: tk.BooleanVar):
        self.box = text
        self.hint = hint
        self.language = language  # callable returning the selected language code
        self.spellcheck_on = spellcheck_on
        self.autofill_on = autofill_on
        self.assistant: TypingAssistant | None = None
        self._job: str | None = None
        self._hint_job: str | None = None
        self.box.tag_configure("ghost", foreground="#9a9a9a")
        try:
            self.box.tag_configure("misspelled", underline=True, underlinefg="#d32f2f")
        except tk.TclError:  # older Tk without coloured underlines
            self.box.tag_configure("misspelled", underline=True)
        self.box.bind("<KeyPress>", self._on_key_press, add="+")
        self.box.bind("<KeyRelease>", self._on_key_release, add="+")
        self.box.bind("<Button-1>", lambda e: self.clear_suggestion(), add="+")
        for button in ("<Button-2>", "<Button-3>", "<Control-Button-1>"):  # right-click on each platform
            self.box.bind(button, self._context_menu, add="+")
        # Reading the journals' vocabulary is done off the UI thread; Tk widgets are only
        # touched here on the main thread, which picks up the result when it's ready.
        # The thread only holds plain data (never the window), so closing the window
        # early can't leave Tk objects to be cleaned up from the wrong thread.
        loaded: list[TypingAssistant] = []
        self._loaded = loaded
        language_code = self.language()
        threading.Thread(target=lambda: loaded.append(TypingAssistant(language_code)), daemon=True).start()
        self._wait_for_load()

    def _wait_for_load(self) -> None:
        if self._loaded:
            self.assistant = self._loaded[0]
            self.assistant.set_language(self.language())  # in case it changed while loading
            self.refresh()
        else:
            self.box.after(100, self._wait_for_load)

    # ---- The question text, without any suggestion -------------------------------

    def text(self) -> str:
        self.clear_suggestion()
        return self.box.get("1.0", "end-1c")

    def clear_suggestion(self) -> None:
        ranges = self.box.tag_ranges("ghost")
        if ranges:
            undo = self.box.cget("undo")
            self.box.configure(undo=False)  # suggestions never enter the undo history
            self.box.delete(ranges[0], ranges[-1])
            self.box.configure(undo=undo)

    def _accept_suggestion(self) -> bool:
        ranges = self.box.tag_ranges("ghost")
        if not ranges:
            return False
        self.box.tag_remove("ghost", ranges[0], ranges[-1])
        self.box.mark_set("insert", ranges[-1])
        self.box.edit_separator()
        self.schedule()
        return True

    # ---- Keys ------------------------------------------------------------------------

    def _on_key_press(self, event: tk.Event) -> str | None:
        if event.keysym in ("Tab", "Right") and self._accept_suggestion():
            return "break"
        if event.keysym == "Tab":
            # No suggestion to accept: move to the next control (as Tab normally does)
            # instead of typing a tab character into the question.
            self.box.tk_focusNext().focus_set()
            return "break"
        if event.keysym not in ("Shift_L", "Shift_R", "Meta_L", "Meta_R", "Control_L", "Control_R", "Alt_L", "Alt_R"):
            self.clear_suggestion()
        return None

    def _on_key_release(self, event: tk.Event) -> None:
        if event.keysym in self.WORD_END_KEYS:
            self._autocorrect_previous_word()
        self.schedule()

    def schedule(self) -> None:
        if self._job:
            self.box.after_cancel(self._job)
        self._job = self.box.after(250, self.refresh)

    def language_changed(self) -> None:
        if self.assistant:
            self.assistant.set_language(self.language())
        self.refresh()

    def remember_question(self, question: str) -> None:
        if self.assistant and question and question not in self.assistant.questions:
            self.assistant.questions.insert(0, question)

    # ---- Spell check, autocorrect, autofill ---------------------------------------------

    def refresh(self) -> None:
        """Re-underline misspellings and update the autofill suggestion.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        self._job = None
        self.box.tag_remove("misspelled", "1.0", "end")
        if not self.assistant or str(self.box.cget("state")) == "disabled":
            return
        self.clear_suggestion()
        content = self.box.get("1.0", "end-1c")
        cursor = len(self.box.get("1.0", "insert"))
        if self.spellcheck_on.get():
            for start, end, _ in self.assistant.misspelled(content):
                if end == cursor:
                    continue  # still being typed
                self.box.tag_add("misspelled", f"1.0+{start}c", f"1.0+{end}c")
        at_end = self.box.compare("insert", "==", "end-1c")
        if self.autofill_on.get() and at_end and content.strip():
            completion = self.assistant.completion(content)
            if completion:
                undo = self.box.cget("undo")
                self.box.configure(undo=False)
                self.box.insert("end-1c", completion, "ghost")
                self.box.configure(undo=undo)
                self.box.mark_set("insert", f"end-1c-{len(completion)}c")

    def _autocorrect_previous_word(self) -> None:
        if not self.assistant or not self.spellcheck_on.get():
            return
        before = self.box.get("1.0", "insert-1c")
        match = re.search(r"([^\W\d_]+)$", before)
        if not match:
            return
        word = match.group(1)
        correction = self.assistant.autocorrection(word)
        if not correction:
            return
        # Fixed positions: "insert"-relative ones would move once the old word is deleted.
        end = self.box.index("insert-1c")
        start = self.box.index(f"{end}-{len(word)}c")
        self._replace((start, end), correction, refresh=False)
        self._show_hint(f"Corrected “{word}” → “{correction}” (⌘Z to undo)")

    def _show_hint(self, message: str) -> None:
        self.hint.configure(text=message, foreground="#1a7f37")
        if self._hint_job:
            self.hint.after_cancel(self._hint_job)
        self._hint_job = self.hint.after(4000, lambda: self.hint.configure(text=HINT, foreground="gray"))

    def _context_menu(self, event: tk.Event) -> str:
        """Right-click: spelling suggestions for an underlined word, plus cut/copy/paste.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        self.clear_suggestion()
        index = self.box.index(f"@{event.x},{event.y}")
        menu = tk.Menu(self.box, tearoff=False)
        word_range = None
        for start, end in zip(*[iter(self.box.tag_ranges("misspelled"))] * 2):
            if self.box.compare(start, "<=", index) and self.box.compare(index, "<", end):
                word_range = (start, end)
        if word_range and self.assistant:
            word = self.box.get(*word_range)
            suggestions = self.assistant.suggestions(word)
            for suggestion in suggestions:
                menu.add_command(label=suggestion, command=lambda s=suggestion: self._replace(word_range, s))
            if not suggestions:
                menu.add_command(label="No suggestions", state="disabled")
            menu.add_separator()
            menu.add_command(label=f"Add “{word}” to dictionary", command=lambda: (self.assistant.add_word(word), self.refresh()))
            menu.add_command(label="Ignore", command=lambda: (self.assistant.ignore(word), self.refresh()))
            menu.add_separator()
        menu.add_command(label="Cut", command=lambda: self.box.event_generate("<<Cut>>"))
        menu.add_command(label="Copy", command=lambda: self.box.event_generate("<<Copy>>"))
        menu.add_command(label="Paste", command=lambda: self.box.event_generate("<<Paste>>"))
        menu.tk_popup(event.x_root, event.y_root)
        return "break"

    def _replace(self, word_range, replacement: str, refresh: bool = True) -> None:
        """Swap a word as ONE undo step, so a single ⌘Z brings the original word back.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        autoseparators = self.box.cget("autoseparators")
        self.box.configure(autoseparators=False)  # Tk would otherwise split the delete from the insert
        self.box.edit_separator()
        self.box.delete(*word_range)
        self.box.insert(word_range[0], replacement)
        self.box.edit_separator()
        self.box.configure(autoseparators=autoseparators)
        if refresh:
            self.refresh()


class ResultsViewer(tk.Toplevel):
    """A window that shows a Markdown report with light formatting.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    def __init__(self, master: tk.Misc, path: Path):
        super().__init__(master)
        self.title(path.name)
        self.geometry("760x620")

        text = ScrolledText(self, wrap="word", font=("Helvetica", 13), padx=16, pady=12)
        text.pack(fill="both", expand=True)
        self.text = text
        text.tag_configure("h1", font=("Helvetica", 20, "bold"), spacing3=8)
        text.tag_configure("h2", font=("Helvetica", 16, "bold"), spacing1=12, spacing3=4)
        text.tag_configure("h3", font=("Helvetica", 14, "bold"), spacing1=8)
        text.tag_configure("bold", font=("Helvetica", 13, "bold"))
        text.tag_configure("italic", font=("Helvetica", 13, "italic"))

        for line in path.read_text(encoding="utf-8").splitlines():
            heading = re.match(r"^(#{1,3})\s+(.*)", line)
            if heading:
                text.insert("end", heading.group(2) + "\n", f"h{len(heading.group(1))}")
            else:
                self._insert_inline(text, line + "\n")
        text.configure(state="disabled")

        buttons = ttk.Frame(self, padding=8)
        buttons.pack(fill="x")
        ttk.Button(buttons, text="Open Results folder", command=lambda: open_path(config.RESULTS_DIR)).pack(side="left")
        ttk.Button(buttons, text="Open in default app", command=lambda: open_path(path)).pack(side="left", padx=8)
        ttk.Button(buttons, text="Close", command=self.destroy).pack(side="right")

    @staticmethod
    def _insert_inline(text: ScrolledText, line: str) -> None:
        """Render **bold** and *italic* spans (e.g. journal names); everything else as plain text.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        for chunk in re.split(r"(\*\*.+?\*\*|\*[^*\s][^*]*\*)", line):
            if chunk.startswith("**") and chunk.endswith("**") and len(chunk) > 4:
                text.insert("end", chunk[2:-2], "bold")
            elif chunk.startswith("*") and chunk.endswith("*") and len(chunk) > 2:
                text.insert("end", chunk[1:-1], "italic")
            else:
                text.insert("end", chunk)


def open_path(path: Path) -> None:
    """Open a file or folder with the operating system's default app.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    if sys.platform == "darwin":
        subprocess.run(["open", str(path)], check=False)
    elif sys.platform.startswith("win"):
        import os

        os.startfile(path)  # type: ignore[attr-defined]
    else:
        subprocess.run(["xdg-open", str(path)], check=False)


def save_window_error(details: str) -> Path | None:
    """Append a window error to Agents/Logs/Interface/<date>.log; returns the file (None if it can't be written).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    try:
        folder = Path(config.AGENT_LOG_DIR) / "Interface"
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / f"{datetime.now():%Y-%m-%d}.log"
        with open(path, "a", encoding="utf-8") as f:
            f.write(f"{datetime.now():%Y-%m-%d %H:%M:%S}  ERROR  {details.rstrip()}\n\n")
        return path
    except OSError:
        return None


def main() -> None:
    root = tk.Tk()
    app = ResearchApp(root)
    # Errors in any button or key handler (e.g. Reset) are shown and saved instead of only printed.
    root.report_callback_exception = lambda exc_type, exc, tb: app.report_ui_error(exc)
    root.mainloop()


if __name__ == "__main__":
    main()
