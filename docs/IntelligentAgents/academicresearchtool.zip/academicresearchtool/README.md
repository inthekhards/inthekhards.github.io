# Academic Research Tool

This tool is to be used to find academic research for questions or prompts that a user presents. 

To launch this application, follow the installation instructions below. Then you can run `interface.py` from your terminal or Visual Studio Code. 

# Overview 

The Academic Research Tool is an application that takes your prompt, searches and filters for the best information related to your topic before sending you the results. Instead of you doing the work of searching for academic articles, the AI agents in this tool do that for you with their own reasoning and skills. The planner agent is responsible for creating search terms and orchestrating the retrieval, processing and storage agents. The planner agent also reviews what the processing agent filters and ranks before outputting the results. The retrieval agent calls the arXiv, OpenAlex and CORE APIs to fetch articles and information. The processing agent reads, filters, ranks, and summarizes them for the planner agent's approval. The planner agent may loop the process up to 3 times for the best results. The storage agent displays the final results in markdown. The final results can be found in the /Results folder if they are ever needed to be revisited again. References are published in Harvard Cite Them Right format. Each agent is powered by an LLM for their decision-making and actions, which the user can control. This program is run locally with Ollama and the models accessed by it. 


# Installation

## Before you start

- About 24 GB of free space to download all LLMs. You also need minimum 8 GB of RAM to run the application, 16 GB RAM recommended. 
- The installation instructions assume the `academicresearchtool` folder is in your **Downloads** folder. If you want to change how to install this, you need to change the `cd` paths to the folder you put it in. 
- Do not copy the `.venv` folder from another computer: create it fresh in step 2.


## Mac (Terminal)

### 1. Python 3.14

Download and run the macOS installer for Python 3.14.8 from https://www.python.org/downloads/ (it includes Tkinter). Then check:

```bash
python3 --version
python3 -c "import tkinter; print('tkinter OK')"
```

### 2. Virtual environment and pinned libraries

```bash
cd ~/Downloads/academicresearchtool
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 3. Ollama

Download Ollama from https://ollama.com/download, move it to Applications and open it once. Alternatively, you can install it with bash. You do not have to do both of these actions. 

```bash
brew install ollama
brew services start ollama
```

Check it is running:

```bash
ollama --version
```

### 4. Models (use these exact names: the app looks for them)

```bash
ollama pull deepseek-r1:8b
ollama pull qwen3.5:9b
ollama pull llama3.1:8b
ollama pull gemma4:e4b
```

### 5. Launch

```bash
cd ~/Downloads/academicresearchtool
source .venv/bin/activate
python interface.py
```


## Windows (PowerShell)

### 1. Python 3.14

Download the Windows installer from https://www.python.org/downloads/. Close and reopen PowerShell, then check:

```powershell
py -3.14 --version
py -3.14 -c "import tkinter; print('tkinter OK')"
```

### 2. Virtual environment and pinned libraries

```powershell
cd $HOME\Downloads\academicresearchtool
py -3.14 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
```

These commands use the virtual environment's Python directly, so there is no need to "activate" it (PowerShell blocks the activation script by default).

### 3. Ollama 0.40.3

```powershell
winget install Ollama.Ollama --version 0.40.3
```

Close and reopen PowerShell again. Ollama starts by itself (look for its icon by the clock). Check it:

```powershell
ollama --version
```

### 4. Models (use these exact names: the app looks for them)

```powershell
ollama pull deepseek-r1:8b
ollama pull qwen3.5:9b
ollama pull llama3.1:8b
ollama pull gemma4:e4b
```

### 5. Launch

```powershell
cd $HOME\Downloads\academicresearchtool
.venv\Scripts\python.exe interface.py
```


## Running it from Visual Studio Code

Open the `academicresearchtool` folder in VS Code, open the Command Palette (Cmd+Shift+P on Mac, Ctrl+Shift+P on Windows), choose **Python: Select Interpreter** and pick the one in `.venv`. Then open `interface.py` and press Run. Without this step VS Code may use a Python that doesn't have the libraries installed.


## Optional: API keys

A free OpenAlex key (https://openalex.org/settings/api) and CORE key (https://core.ac.uk/services/api) give higher daily search limits. Create a file called `.env` in the `academicresearchtool` folder containing:

```
OPENALEX_API_KEY=your-key
CORE_API_KEY=your-key
```

Do not share or submit the `.env` file if you use personal API keys. 


## Running the tests

Mac:

```bash
.venv/bin/python Tests/run_tests.py
```

Windows:

```powershell
.venv\Scripts\python.exe Tests\run_tests.py
```

Each run writes a report (report.html, report.md, results.csv) to `Tests/Reports/`.


# Manual Installation 

To install this program with what it was developed with, you can install: 

Python 3.14.8 Released September 30, 2026. -- Download here: https://www.python.org/downloads/ 

Tkinter (bundled with Python, no separate install) -- Documentation: https://docs.python.org/3/library/tkinter.html

Python libraries: 
httpx 0.28.1 -- Download here: https://pypi.org/project/httpx/ 
langgraph 1.2.12 -- Download here: https://pypi.org/project/langgraph/
pydantic 2.13.5 -- Download here: https://pypi.org/project/pydantic/ 
tenacity 9.1.4 -- Download here: https://pypi.org/project/tenacity/ 
pytest 9.1.1 -- Download here: https://pypi.org/project/pytest/ 
pyspellchecker 0.9.0 -- Download here: https://pypi.org/project/pyspellchecker/ 
coverage 7.16.2 -- Download here: https://pypi.org/project/coverage/ 

Ollama 0.40.3 -- Download here: https://ollama.com/download 

LLM Models: 
Deepseek R1 -- https://ollama.com/library/deepseek-r1 
Qwen 3.5 -- https://ollama.com/library/qwen3.5 
Llama 3.1 -- https://ollama.com/library/llama3.1 
Gemma 4 -- https://ollama.com/library/gemma4 

Visual Studio Code: https://code.visualstudio.com/

Claude (Claude Code): https://claude.com/product/claude-code 


# AI Use Declaration 
I have used Artificial Intelligence responsibly and ethically, in accordance with the assignment brief. All AI use has been declared and evidenced. I have used Claude Code (Opus 5.5) by Anthropic (2026) to assist in developing the coding/programming, refactoring, testing, technical commenting, spellcheck, and debugging parts of this assignment. I have also used Claude (Sonnet 5.5) by Anthropic (2026) to assist with spellcheck and formatting my citations in Harvard Cite Them Right.  


# References

Anthropic (2026) Claude Code [Desktop AI coding tool]. Model: [Opus 5.5]. Available at: https://claude.com/product/claude-code (Accessed: 12 October 2026).

Anthropic (2026) Claude [Desktop AI tool]. Model: [Sonnet 5.5]. Available at: https://claude.com (Accessed: 12 October 2026).

Barrus, T. (2026) pyspellchecker (Version 0.9.0) [Python library]. Available at: https://pypi.org/project/pyspellchecker/ (Accessed: 12 October 2026).

Batchelder, N. (2026) coverage (Version 7.16.2) [Python library]. Available at: https://pypi.org/project/coverage/ (Accessed: 12 October 2026).

Christie, T. (2026) httpx (Version 0.28.1) [Python library]. Available at: https://pypi.org/project/httpx/ (Accessed: 12 October 2026).

Colvin, S. (2026) pydantic (Version 2.13.5) [Python library]. Available at: https://pypi.org/project/pydantic/ (Accessed: 12 October 2026).

Cornell University (no date) arXiv API user's manual. Available at: https://info.arxiv.org/help/api/user-manual.html (Accessed: 12 October 2026).

Danjou, J. (2026) tenacity (Version 9.1.4) [Python library]. Available at: https://pypi.org/project/tenacity/ (Accessed: 12 October 2026).

DeepSeek-AI (2025) DeepSeek-R1 [Large language model]. Available at: https://ollama.com/library/deepseek-r1 (Accessed: 12 October 2026).

Google DeepMind (2026) Gemma 4 [Large language model]. Available at: https://ollama.com/library/gemma4 (Accessed: 12 October 2026).

Harding, K., Goodwin, C., Dimbu, K. and Etuk, I. (2026) Design proposal for an academic and information gathering multi-agent artificial intelligence tool. Unpublished group assignment, IA_PCOM7E: Intelligent Agents July 2026. University of Essex Online.

Knoth, P. and Zdrahal, Z. (2012) 'CORE: three access levels to underpin open access', D-Lib Magazine, 18(11/12). Available at: https://dlib.org/dlib/november12/knoth/11knoth.html (Accessed: 12 October 2026).

Krekel, H. and pytest-dev team (2026) pytest (Version 9.1.1) [Python library]. Available at: https://pypi.org/project/pytest/ (Accessed: 12 October 2026).

LangChain Inc. (2026) langgraph (Version 1.2.12) [Python library]. Available at: https://pypi.org/project/langgraph/ (Accessed: 12 October 2026).

Meta (2024) Llama 3.1 [Large language model]. Available at: https://ollama.com/library/llama3.1 (Accessed: 12 October 2026).

Microsoft (2026) Visual Studio Code [Software]. Available at: https://code.visualstudio.com/ (Accessed: 12 October 2026).

Ollama (2026) Ollama (Version 0.40.3) [Software]. Available at: https://ollama.com/download (Accessed: 12 October 2026).

Ollama (2026) Ollama (Version 0.6.3) [Python library]. Available at: https://pypi.org/project/ollama/ (Accessed: 12 October 2026).

Priem, J., Piwowar, H. and Orr, R. (2022) 'OpenAlex: a fully-open index of scholarly works, authors, venues, institutions, and concepts', arXiv [Preprint]. Available at: https://doi.org/10.48550/arXiv.2205.01833 (Accessed: 12 October 2026).

Python Software Foundation (2026) Python (Version 3.14.8) [Programming language]. Released 30 September 2026. Available at: https://www.python.org/downloads/ (Accessed: 12 October 2026).

Python Software Foundation (2026b) tkinter: Python interface to Tcl/Tk. Available at: https://docs.python.org/3/library/tkinter.html (Accessed: 12 October 2026).

Qwen Team (2026) Qwen 3.5 [Large language model]. Available at: https://ollama.com/library/qwen3.5 (Accessed: 12 October 2026).

# Appendix 

Anthropic (2026) Claude Code (Opus 5.5) [Desktop AI coding tool]. Prompt log of the development of an academic research multi-agent tool, 2–12 October 2026. Unpublished; submitted as ‘Claude Code prompt log.md’.

# Author 

K. Harding (2026)

# Questions 

For any questions or concerns about the project (code, not installing, etc) please contact me at kb24760@essex.ac.uk. 