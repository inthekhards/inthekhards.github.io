"""Spell check, autocorrect and autofill for the question box.

Works offline with pyspellchecker's dictionaries (one per research language),
extended with the vocabulary of the user's own research: every word in the
questions, titles and abstracts saved in ``Journal/``. That way academic terms
the user works with ("neuroplasticity", "metacognition") aren't marked as errors.

Autocorrect is deliberately cautious: it only fixes lowercase words where one
correction is clearly the right one, and never touches acronyms, names, words
with digits or hyphens, or words the user has used before.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import json
import re
from collections import Counter
from pathlib import Path

from spellchecker import SpellChecker

from App import config

WORD = re.compile(r"[^\W\d_]+(?:['’][^\W\d_]+)?")
MIN_PREFIX = 3  # letters typed before a word is completed


def past_questions(journal_dir: Path | None = None) -> list[str]:
    """The user's previous research questions, most recent first (from the journals).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    journal_dir = journal_dir or config.JOURNAL_DIR
    questions = []
    for path in sorted(journal_dir.glob("*.json"), reverse=True):
        try:
            goal = json.loads(path.read_text(encoding="utf-8")).get("goal", "").strip()
        except (OSError, ValueError):
            continue
        if goal and goal not in questions:
            questions.append(goal)
    return questions


def research_vocabulary(journal_dir: Path | None = None) -> Counter:
    """How often each word appears in the user's journals (questions, titles, abstracts).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    journal_dir = journal_dir or config.JOURNAL_DIR
    counts: Counter = Counter()
    for path in journal_dir.glob("*.json"):
        try:
            journal = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        texts = [journal.get("goal", "")]
        for cycle in journal.get("cycles", []):
            for result in cycle.get("raw_results", []):
                texts += [result.get("title") or "", result.get("abstract") or ""]
        for text in texts:
            counts.update(w.lower() for w in WORD.findall(text))
    return counts


class TypingAssistant:
    def __init__(self, language: str = "en", questions: list[str] | None = None, vocabulary: Counter | None = None):
        self.questions = questions if questions is not None else past_questions()
        self.vocabulary = vocabulary if vocabulary is not None else research_vocabulary()
        self.user_words = {w.lower() for q in self.questions for w in WORD.findall(q)}
        self.ignored: set[str] = set()
        self.language = ""
        self.set_language(language)

    def set_language(self, language: str) -> None:
        if language == self.language:
            return
        self.language = language
        try:
            self.spell = SpellChecker(language=language)
        except ValueError:  # no dictionary for this language
            self.spell = SpellChecker(language="en")
        self.spell.word_frequency.load_words(list(self.vocabulary.elements()))
        # Words for autofill, most common first, grouped by their first letters.
        frequency = self.spell.word_frequency.dictionary
        ranked = sorted(frequency, key=frequency.get, reverse=True)
        self._by_prefix: dict[str, list[str]] = {}
        for word in ranked:
            if len(word) > MIN_PREFIX and WORD.fullmatch(word):
                self._by_prefix.setdefault(word[:MIN_PREFIX], []).append(word)

    # ---- Spelling ----------------------------------------------------------------

    def add_word(self, word: str) -> None:
        """'Add to dictionary' for this session.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        self.user_words.add(word.lower())
        self.spell.word_frequency.load_words([word.lower()])

    def ignore(self, word: str) -> None:
        self.ignored.add(word.lower())

    def _checkable(self, word: str) -> bool:
        """Only lowercase words of 3+ letters are checked: acronyms (SEL), names (Piaget) and
        mixed-case terms (McDonald, iPhone) are left alone.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        return len(word) >= 3 and word.islower() and word not in self.ignored

    def is_misspelled(self, word: str) -> bool:
        lower = word.lower()
        return self._checkable(word) and lower not in self.user_words and lower not in self.spell

    def misspelled(self, text: str) -> list[tuple[int, int, str]]:
        """(start, end, word) for each misspelled word in ``text``.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        return [(m.start(), m.end(), m.group()) for m in WORD.finditer(text) if self.is_misspelled(m.group())]

    def suggestions(self, word: str, limit: int = 5) -> list[str]:
        candidates = self.spell.candidates(word.lower()) or set()
        frequency = self.spell.word_frequency.dictionary
        return sorted(candidates - {word.lower()}, key=lambda w: -frequency.get(w, 0))[:limit]

    def autocorrection(self, word: str) -> str | None:
        """The correction to apply automatically, or None if it isn't clear-cut.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        if not self.is_misspelled(word) or "'" in word or "’" in word:
            return None
        lower = word.lower()
        close = self.spell.known(self.spell.edit_distance_1(lower)) - {lower}
        if not close:
            return None
        frequency = self.spell.word_frequency.dictionary
        ranked = sorted(close, key=lambda w: -frequency.get(w, 0))
        best = ranked[0]
        runner_up = frequency.get(ranked[1], 0) if len(ranked) > 1 else 0
        # Short words have many near neighbours, so they need an even clearer winner.
        needed = 50 if len(lower) <= 3 else 5
        if frequency.get(best, 0) >= needed * max(1, runner_up):
            return best
        return None

    # ---- Autofill ----------------------------------------------------------------

    def completion(self, text: str) -> str | None:
        """Text to add after the cursor (which is at the end of ``text``), or None.

        Past questions are suggested first (after a few typed words), then the most
        common word starting with the letters being typed.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        stripped = text.lstrip()
        if len(stripped) >= 8:
            for question in self.questions:
                if question.lower().startswith(stripped.lower()) and len(question) > len(stripped):
                    return question[len(stripped):]
        match = re.search(r"([^\W\d_]+)$", text)
        if not match or len(match.group(1)) < MIN_PREFIX:
            return None
        typed = match.group(1)
        prefix = typed.lower()
        for word in self._by_prefix.get(prefix[:MIN_PREFIX], []):
            if word.startswith(prefix) and len(word) > len(prefix) + 1:
                rest = word[len(prefix):]
                return rest.upper() if typed.isupper() else rest
        return None
