"""Reads explicit instructions from the user's question that the agents must obey.

Currently: how many articles the user asked for ("5 articles", "top three papers",
"limit it to 5", "cinq articles"). The user then gets that many articles or fewer.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import re

NUMBER_WORDS = {
    # English
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9,
    "ten": 10, "eleven": 11, "twelve": 12, "fifteen": 15, "twenty": 20,
    # French
    "deux": 2, "trois": 3, "quatre": 4, "cinq": 5, "sept": 7, "huit": 8, "neuf": 9, "dix": 10,
    # Spanish / Italian / Portuguese
    "uno": 1, "dos": 2, "tres": 3, "cuatro": 4, "cinco": 5, "seis": 6, "siete": 7, "ocho": 8, "nueve": 9, "diez": 10,
    "due": 2, "tre": 3, "quattro": 4, "sei": 6, "sette": 7, "otto": 8, "nove": 9, "dieci": 10,
    "dois": 2, "duas": 2, "três": 3, "quatro": 4, "oito": 8, "dez": 10,
    # German
    "eins": 1, "zwei": 2, "drei": 3, "vier": 4, "fünf": 5, "sechs": 6, "sieben": 7, "acht": 8, "neun": 9, "zehn": 10,
}

# Words for "articles" in the supported languages.
ARTICLE_WORDS = (
    r"articles?|papers?|sources?|studies|study|publications?|references?|results?|journals?|works?"
    r"|art[ií]culos?|fuentes|estudios|articoli|fonti|studi|artigos?|fontes|estudos|artikel|quellen|studien"
    r"|études?|publicaciones|pubblicazioni|publicações|veröffentlichungen"
)
NUMBER = r"(\d{1,3}|" + "|".join(sorted(NUMBER_WORDS, key=len, reverse=True)) + r")"

PATTERNS = [
    # "5 articles", "five peer-reviewed papers", "3 recent studies"
    re.compile(rf"\b{NUMBER}\s+(?:[\w-]+\s+){{0,3}}?(?:{ARTICLE_WORDS})\b", re.I),
    # "Limit it to 5.", "limited to five", "no more than 5", "at most 5", "maximum of 5", "only 3" -
    # only when the number ends the phrase, so "only 5 hours of sleep", "the top 10 universities"
    # or "children up to 5 years old" are not mistaken for a number of articles.
    re.compile(
        rf"\b(?:limit(?:ed)?(?:\s+\w+)?\s+to|no\s+more\s+than|at\s+most|max(?:imum)?(?:\s+of)?|up\s+to|top|only)\s+{NUMBER}"
        r"(?=\s*(?:[.,;:!?)]|$))",
        re.I,
    ),
]


def _to_int(token: str) -> int | None:
    token = token.lower()
    if token.isdigit():
        return int(token)
    return NUMBER_WORDS.get(token)


def requested_article_count(question: str) -> int | None:
    """The number of articles the user explicitly asked for, or None if they didn't say.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    for pattern in PATTERNS:
        for match in pattern.finditer(question):
            number = _to_int(match.group(1))
            if number and 0 < number <= 100:
                return number
    return None


QUANTITY_WORDS = re.compile(
    r"\b(handful|few|couple|several|dozen|pair|quelques|algunos|algunas|einige|alcuni|alcune|alguns|algumas)\b", re.I
)


def mentions_quantity(question: str) -> bool:
    """Does the question mention any number or amount at all? The planner model's reading of
    a requested number is only used if so, so it can't invent a limit for a question like
    "Find me research articles on social and emotional learning".

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    return bool(re.search(r"\d", question) or re.search(rf"\b{NUMBER}\b", question, re.I) or QUANTITY_WORDS.search(question))
