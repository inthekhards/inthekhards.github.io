"""Harvard (Cite Them Right) references and in-text citations for the research report.

The formats follow the reference list in the project's Design Proposal:

    Journal:  Bertone, G. and Hooper, D. (2018) 'History of dark matter', *Reviews of
              Modern Physics*, 90(4), 045002. doi: 10.1103/RevModPhys.90.045002.
    Preprint: Priem, J., Piwowar, H. and Orr, R. (2022) 'OpenAlex: ...', arXiv [Preprint].
              Available at: https://doi.org/10.48550/arXiv.2205.01833 (Accessed: 4 October 2026).
    Thesis:   Smith, J. (2019) *Title*. Thesis. University of York. Available at: URL
              (Accessed: 4 October 2026).

In-text citations name up to three authors and use "et al." for four or more, e.g.
(Bertone and Hooper, 2018) or (Arkani-Hamed et al., 2009). Works by the same
authors in the same year get 2018a, 2018b, ... in both places. Italics are written
as Markdown (*Journal*). The connecting words ("and", "Available at", "Accessed",
"no date") and dates follow the research language.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import re
from dataclasses import dataclass
from datetime import date

from App.languages import DEFAULT_LANGUAGE, get_language
from App.models import RankedResult, Source

# Lower-case name particles that belong to the surname (van der Waals, de Souza, ...).
PARTICLES = {"van", "von", "de", "der", "den", "del", "della", "di", "da", "le", "la", "du", "dos", "das", "ter", "ten"}
MAX_AUTHORS_LISTED = 10  # longer author lists (large collaborations) become "First, A. et al."
# Group authors are written in full, never as "Surname, I." (e.g. "LIGO Scientific Collaboration").
GROUP_WORDS = re.compile(
    r"\b(collaboration|consortium|group|team|project|committee|organi[sz]ation|institute|society|"
    r"association|network|council|agency|department|ministry|university|centre|center)\b",
    re.I,
)


@dataclass
class Person:
    surname: str
    initials: str  # e.g. "D.P."

    @property
    def reference_form(self) -> str:
        return f"{self.surname}, {self.initials}" if self.initials else self.surname


def _fix_case(word: str, particle_allowed: bool = True) -> str:
    """'arkani-hamed' → 'Arkani-Hamed', 'SMITH' → 'Smith'; leaves 'McDonald' alone.

    Particles ('van', 'de', 'du') are lower-case only before the main surname: a
    surname that is itself 'Du' or 'De' keeps its capital.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    if particle_allowed and word.lower() in PARTICLES:
        return word.lower()
    if word.isupper() and len(word) > 2:
        word = word.title()
    return "-".join(part[:1].upper() + part[1:] if part.islower() else part for part in word.split("-"))


def _initials(given: str) -> str:
    """'Douglas P.' → 'D.P.', 'Jean-Paul' → 'J.-P.'

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    letters = []
    for word in given.replace(".", ". ").split():
        parts = [p for p in word.split("-") if p and p[0].isalpha()]
        if parts:
            letters.append("-".join(f"{p[0].upper()}." for p in parts))
    return "".join(letters)


def parse_name(name: str) -> Person:
    """Split 'Gianfranco Bertone' or 'Bertone, Gianfranco' into surname and initials.
    Group authors ('The XENON Collaboration') are kept whole.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    name = re.sub(r"\s+", " ", name).strip().rstrip(",")
    if GROUP_WORDS.search(name):
        return Person(re.sub(r"^the\s+", "", name, flags=re.I), "")
    if "," in name:
        surname, given = (part.strip() for part in name.split(",", 1))
    else:
        tokens = name.split(" ")
        # Database quirk: a stray trailing initial ("Nima Arkani-hamed A") is not the surname.
        while len(tokens) > 2 and re.fullmatch(r"[A-Za-z]\.?", tokens[-1]):
            tokens.pop()
        if len(tokens) == 1:
            return Person(_fix_case(tokens[0], particle_allowed=False), "")
        start = len(tokens) - 1
        while start > 1 and tokens[start - 1].lower() in PARTICLES:
            start -= 1
        surname, given = " ".join(tokens[start:]), " ".join(tokens[:start])
    words = surname.split()
    return Person(
        " ".join(_fix_case(w, particle_allowed=i < len(words) - 1) for i, w in enumerate(words)), _initials(given)
    )


def _join(names: list[str], word: str = "and") -> str:
    if len(names) <= 1:
        return "".join(names)
    return ", ".join(names[:-1]) + f" {word} " + names[-1]


def _clean_title(title: str) -> str:
    return re.sub(r"\s+", " ", title).strip().rstrip(".")


class HarvardFormatter:
    """Builds in-text citations and references for a fixed list of sources (in ranked order).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    def __init__(self, sources: list[RankedResult], accessed_on: date, language: str = DEFAULT_LANGUAGE):
        self.sources = sources
        self.accessed_on = accessed_on
        self.lang = get_language(language)
        self.words = self.lang.harvard
        self.people = [[parse_name(a) for a in s.authors if a.strip()] for s in sources]
        self.years = self._year_labels()

    # ---- Years with a/b suffixes ------------------------------------------

    def _author_key(self, i: int) -> str:
        people = self.people[i]
        if not people:
            return _clean_title(self.sources[i].title).lower()
        surnames = [p.surname for p in people]
        return self._in_text_names(surnames).lower()

    def _year_labels(self) -> list[str]:
        no_date = self.words["no_date"]
        base = [str(s.year) if s.year else no_date for s in self.sources]
        groups: dict[tuple[str, str], list[int]] = {}
        for i in range(len(self.sources)):
            groups.setdefault((self._author_key(i), base[i]), []).append(i)
        labels = list(base)
        for members in groups.values():
            if len(members) > 1:
                members.sort(key=lambda i: _clean_title(self.sources[i].title).lower())
                for letter, i in zip("abcdefghijklmnopqrstuvwxyz", members):
                    labels[i] = f"{base[i]}{letter}" if base[i] != no_date else f"{no_date} {letter}"
        return labels

    # ---- In-text citations ----------------------------------------------------

    def _in_text_names(self, surnames: list[str]) -> str:
        if len(surnames) >= 4:
            return f"{surnames[0]} et al."
        return _join(surnames, self.words["and"])

    def in_text(self, index: int) -> str:
        """Citation text for the source at 0-based ``index``, without brackets: 'Bertone and Hooper, 2018'.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        people = self.people[index]
        who = self._in_text_names([p.surname for p in people]) if people else f"'{_clean_title(self.sources[index].title)}'"
        return f"{who}, {self.years[index]}"

    def convert_citations(self, text: str) -> str:
        """Replace numbered citations like [1] or [2, 5] or [1][3] with Harvard ones; drop numbers
        that don't match a source (the model invented them).

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """

        def replace(match: re.Match) -> str:
            numbers: list[int] = []
            for a, b in re.findall(r"(\d+)(?:\s*[–-]\s*(\d+))?", match.group(0)):
                start, end = int(a), int(b) if b else int(a)
                numbers += list(range(start, end + 1)) if 0 < end - start < 50 else [start, end]
            valid = [n for n in dict.fromkeys(numbers) if 1 <= n <= len(self.sources)]
            if not valid:
                return ""
            return "(" + "; ".join(self.in_text(n - 1) for n in valid) + ")" + (" " if match.group(0).endswith(" ") else "")

        converted = re.sub(r"(?:\[\d+(?:\s*[,;–-]\s*\d+)*\]\s*)+", replace, text)
        return re.sub(r"\s+([.,;:])", r"\1", re.sub(r"[ \t]{2,}", " ", converted)).strip()

    # ---- References -------------------------------------------------------------

    def _authors(self, index: int) -> str:
        people = self.people[index]
        if len(people) > MAX_AUTHORS_LISTED:
            return f"{people[0].reference_form} et al."
        return _join([p.reference_form for p in people], self.words["and"])

    @staticmethod
    def _locator(r: RankedResult) -> str:
        parts = ""
        if r.volume:
            parts += f", {r.volume}" + (f"({r.issue})" if r.issue else "")
        if r.pages:
            parts += f", pp. {r.pages}" if "–" in r.pages else f", {r.pages}"
        return parts

    def _link(self, r: RankedResult, prefer_doi_style: bool) -> str:
        if r.doi and prefer_doi_style:
            return f" doi: {r.doi}."
        url = f"https://doi.org/{r.doi}" if r.doi else r.url
        if not url:
            return ""
        accessed = f"({self.words['accessed']}: {self.lang.format_date(self.accessed_on)})"
        return f" {self.words['available']}: {url} {accessed}."

    def reference(self, index: int) -> str:
        r = self.sources[index]
        title = _clean_title(r.title)
        authors = self._authors(index)
        lead = f"{authors} ({self.years[index]})" if authors else f"*{title}* ({self.years[index]})"
        kind = (r.publication_type or "").lower()
        preprint = kind == "preprint" or (r.source == Source.ARXIV and not r.peer_reviewed)

        if preprint:
            what = f" '{title}'," if authors else ""
            return f"{lead}{what} arXiv {self.words['preprint']}.{self._link(r, prefer_doi_style=False)}"
        if kind == "thesis":
            body = f" *{title}*." if authors else "."
            institution = f" {r.publisher}." if r.publisher else ""
            return f"{lead}{body} {self.words['thesis']}.{institution}{self._link(r, prefer_doi_style=False)}"
        if kind == "book":
            body = f" *{title}*." if authors else "."
            publisher = f" {r.publisher}." if r.publisher else ""
            return f"{lead}{body}{publisher}{self._link(r, prefer_doi_style=True)}"
        if r.venue and r.venue != "arXiv":
            body = f" '{title}'," if authors else ","
            if kind == "book-chapter":
                return f"{lead}{body} in *{r.venue}*{self._locator(r)}.{self._link(r, prefer_doi_style=True)}"
            return f"{lead}{body} *{r.venue}*{self._locator(r)}.{self._link(r, prefer_doi_style=True)}"
        # No venue known: cite as an online document.
        body = f" *{title}*." if authors else "."
        publisher = f" {r.publisher}." if r.publisher and r.publisher != "arXiv" else ""
        return f"{lead}{body}{publisher}{self._link(r, prefer_doi_style=False)}"

    def ranked_references(self) -> list[str]:
        return [self.reference(i) for i in range(len(self.sources))]

    def alphabetical_references(self) -> list[str]:
        """Reference list order: first author's surname (or title), then year label.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """

        def key(i: int) -> tuple:
            people = self.people[i]
            name = " ".join(f"{p.surname} {p.initials}" for p in people) if people else _clean_title(self.sources[i].title)
            return (re.sub(r"[^a-z0-9 ]", "", name.lower()), self.years[i])

        return [self.reference(i) for i in sorted(range(len(self.sources)), key=key)]
