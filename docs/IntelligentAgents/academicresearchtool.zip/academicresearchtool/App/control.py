"""Stop and pause controls for a research run.

The interface owns one ``RunControl`` per run. The agents call ``checkpoint()`` at
safe points (before each workflow step, between batches of articles, before each
model call): there, a stopped run ends with ``ResearchStopped`` and a paused run
waits until it is resumed. A model that is already writing an answer is cut off
as soon as Stop is pressed (see ``App/llm.py``).

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import threading
import time


class ResearchStopped(Exception):
    """The user pressed Stop (or Reset).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """


class RunControl:
    def __init__(self) -> None:
        self._stopped = threading.Event()
        self._running = threading.Event()  # cleared while paused
        self._running.set()
        self._lock = threading.Lock()
        self.paused_seconds = 0.0  # total time spent paused, which no agent is charged for

    @property
    def stopped(self) -> bool:
        return self._stopped.is_set()

    @property
    def paused(self) -> bool:
        return not self._running.is_set()

    def stop(self) -> None:
        self._stopped.set()
        self._running.set()  # wake a paused run so it can end

    def pause(self) -> None:
        self._running.clear()

    def resume(self) -> None:
        self._running.set()

    def checkpoint(self) -> float:
        """End the run if stopped; wait here while paused. Returns the seconds spent paused.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        if self.stopped:
            raise ResearchStopped()
        waited = 0.0
        if self.paused:
            start = time.monotonic()
            self._running.wait()
            waited = time.monotonic() - start
            with self._lock:
                self.paused_seconds += waited
        if self.stopped:
            raise ResearchStopped()
        return waited
