"""Research languages.

The user picks the research language in the interface (English by default). Every
agent works in it: the planner writes its search terms in it, the databases are
filtered to it, the processing agent drops articles in other languages, and the
report (headings, Harvard wording, dates) is written in it.

To add a language, add an entry to ``LANGUAGES``. ``code`` is the ISO 639-1 code
that OpenAlex and CORE use for their language filters.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import re
import unicodedata
from dataclasses import dataclass, field
from datetime import date


@dataclass(frozen=True)
class Language:
    code: str
    name: str  # English name, used in the agents' instructions
    native: str  # shown in the interface's menu
    headings: dict[str, str]
    harvard: dict[str, str]
    months: tuple[str, ...]
    stopwords: frozenset[str] = field(default_factory=frozenset)

    def format_date(self, on: date) -> str:
        return f"{on.day} {self.months[on.month - 1]} {on.year}"


LANGUAGES: dict[str, Language] = {
    "en": Language(
        code="en",
        name="English",
        native="English",
        headings={
            "overview": "Overview",
            "findings": "Key Findings",
            "ranked": "Ranked Sources",
            "references": "Reference List",
            "main_points": "Main points from the sources",
            "none_found": "No relevant academic sources were found for this question.",
            "sources_address": "The sources below address this question.",
        },
        harvard={"and": "and", "no_date": "no date", "available": "Available at", "accessed": "Accessed",
                 "preprint": "[Preprint]", "thesis": "Thesis"},
        months=("January", "February", "March", "April", "May", "June", "July", "August", "September",
                "October", "November", "December"),
        stopwords=frozenset("the and of is are what how why does do in on for with to which between".split()),
    ),
    "fr": Language(
        code="fr",
        name="French",
        native="Français",
        headings={
            "overview": "Aperçu",
            "findings": "Principaux résultats",
            "ranked": "Sources classées",
            "references": "Bibliographie",
            "main_points": "Points principaux des sources",
            "none_found": "Aucune source académique pertinente n'a été trouvée pour cette question.",
            "sources_address": "Les sources ci-dessous traitent de cette question.",
        },
        harvard={"and": "et", "no_date": "sans date", "available": "Disponible à l'adresse", "accessed": "Consulté le",
                 "preprint": "[Prépublication]", "thesis": "Thèse"},
        months=("janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre",
                "novembre", "décembre"),
        stopwords=frozenset(
            "le la les des est sont quel quelle quels comment pourquoi dans sur pour avec une un du et entre "
            "que qui ce qu'est-ce est-ce".split()
        ),
    ),
    "es": Language(
        code="es",
        name="Spanish",
        native="Español",
        headings={
            "overview": "Resumen",
            "findings": "Hallazgos principales",
            "ranked": "Fuentes clasificadas",
            "references": "Lista de referencias",
            "main_points": "Puntos principales de las fuentes",
            "none_found": "No se encontraron fuentes académicas relevantes para esta pregunta.",
            "sources_address": "Las fuentes siguientes tratan esta pregunta.",
        },
        harvard={"and": "y", "no_date": "sin fecha", "available": "Disponible en", "accessed": "Consultado",
                 "preprint": "[Preimpresión]", "thesis": "Tesis"},
        months=("enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre",
                "noviembre", "diciembre"),
        stopwords=frozenset("el la los las es son qué cómo por qué en para con una un del y entre cuál".split()),
    ),
    "de": Language(
        code="de",
        name="German",
        native="Deutsch",
        headings={
            "overview": "Überblick",
            "findings": "Wichtigste Ergebnisse",
            "ranked": "Rangliste der Quellen",
            "references": "Literaturverzeichnis",
            "main_points": "Hauptpunkte der Quellen",
            "none_found": "Zu dieser Frage wurden keine relevanten wissenschaftlichen Quellen gefunden.",
            "sources_address": "Die folgenden Quellen behandeln diese Frage.",
        },
        harvard={"and": "und", "no_date": "ohne Datum", "available": "Verfügbar unter", "accessed": "Zugriff am",
                 "preprint": "[Preprint]", "thesis": "Dissertation"},
        months=("Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober",
                "November", "Dezember"),
        stopwords=frozenset("der die das ist sind was wie warum welche in auf für mit und zwischen ein eine von".split()),
    ),
    "it": Language(
        code="it",
        name="Italian",
        native="Italiano",
        headings={
            "overview": "Panoramica",
            "findings": "Risultati principali",
            "ranked": "Fonti classificate",
            "references": "Bibliografia",
            "main_points": "Punti principali delle fonti",
            "none_found": "Non sono state trovate fonti accademiche pertinenti per questa domanda.",
            "sources_address": "Le fonti seguenti trattano questa domanda.",
        },
        harvard={"and": "e", "no_date": "senza data", "available": "Disponibile su", "accessed": "Consultato il",
                 "preprint": "[Preprint]", "thesis": "Tesi"},
        months=("gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno", "luglio", "agosto", "settembre",
                "ottobre", "novembre", "dicembre"),
        stopwords=frozenset("il lo la gli le è sono che cosa come perché quale nel per con una un del e tra".split()),
    ),
    "pt": Language(
        code="pt",
        name="Portuguese",
        native="Português",
        headings={
            "overview": "Visão geral",
            "findings": "Principais resultados",
            "ranked": "Fontes classificadas",
            "references": "Lista de referências",
            "main_points": "Pontos principais das fontes",
            "none_found": "Não foram encontradas fontes acadêmicas relevantes para esta pergunta.",
            "sources_address": "As fontes abaixo tratam desta pergunta.",
        },
        harvard={"and": "e", "no_date": "sem data", "available": "Disponível em", "accessed": "Acesso em",
                 "preprint": "[Pré-print]", "thesis": "Tese"},
        months=("janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro",
                "outubro", "novembro", "dezembro"),
        stopwords=frozenset("o a os as é são que como por quê qual no na para com uma um do da e entre".split()),
    ),
}

DEFAULT_LANGUAGE = "en"


def get_language(code: str | None) -> Language:
    return LANGUAGES.get((code or DEFAULT_LANGUAGE).lower(), LANGUAGES[DEFAULT_LANGUAGE])


def detect_language(text: str, min_hits: int = 2) -> str | None:
    """Best guess at which supported language ``text`` is written in, from common words.

    Returns None when there aren't enough clues (e.g. a few technical keywords), so
    callers can fall back to other information rather than guess wrongly. One-letter
    words are ignored: "a" is English and Portuguese, "e" Italian and Portuguese.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    words = [w for w in re.findall(r"[a-zà-ÿ]+", text.lower()) if len(w) > 1]
    if len(words) < 3:
        return None
    scores = {code: sum(w in lang.stopwords for w in words) for code, lang in LANGUAGES.items()}
    best = max(scores, key=scores.get)
    first, second = sorted(scores.values(), reverse=True)[:2]
    return best if first >= min_hits and first > second else None


# ---- Writing systems ----------------------------------------------------------
# All the supported languages are written in the Latin alphabet. An article whose
# title, abstract, authors or journal contain words in another writing system
# (Cyrillic, Greek, Chinese, Arabic, ...) is not readable for the user and is removed.
# Single Greek letters used as scientific symbols ("β-amyloid", "α = 0.05") are fine.

GREEK_WORD = 3  # this many Greek letters in a row is a Greek word, not a symbol


def _script(ch: str) -> str:
    try:
        return unicodedata.name(ch).split()[0]
    except ValueError:
        return "UNKNOWN"


def foreign_script(text: str) -> str | None:
    """Name of the first non-Latin writing system found in ``text`` (e.g. 'CYRILLIC'), or None.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    greek_run = 0
    for ch in text or "":
        if not ch.isalpha():
            greek_run = 0
            continue
        script = _script(ch)
        if script == "LATIN":
            greek_run = 0
        elif script == "GREEK":
            greek_run += 1
            if greek_run >= GREEK_WORD:
                return "GREEK"
        else:
            return script
    return None


def language_problem(
    language: str, title: str, abstract: str | None, authors: list[str], venue: str | None, tagged: str | None
) -> str | None:
    """Why an article doesn't fit the research language, or None if it does.

    Checks, in order: the writing system of the title, abstract, author names and
    journal; the language the database recorded; and the language of the text itself.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    for part, text in (("title", title), ("abstract", abstract), ("venue", venue)):
        if (script := foreign_script(text or "")):
            return f"{script.title()} text in the {part}"
    for name in authors:
        if (script := foreign_script(name)):
            return f"author name in {script.title()} script"
    if tagged and tagged.lower() != language.lower():
        return f"written in {get_language(tagged).name if tagged.lower() in LANGUAGES else tagged}"
    detected = detect_language(f"{title} {abstract or ''}", min_hits=3)
    if detected and detected != language:
        return f"written in {get_language(detected).name}"
    return None
