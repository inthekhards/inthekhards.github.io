"""Central settings for the research tool.

Every value can be overridden with an environment variable, so you can swap
models or hosts without editing code, e.g.:

    PLANNER_MODEL=deepseek-r1:14b python interface.py

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import os
from pathlib import Path

# Project paths
PROJECT_ROOT = Path(__file__).resolve().parent.parent
RESULTS_DIR = PROJECT_ROOT / "Results"
JOURNAL_DIR = PROJECT_ROOT / "Journal"
AGENT_LOG_DIR = PROJECT_ROOT / "Agents" / "Logs"  # one subfolder per agent (see App/activity_log.py)


def shown_path(path: str | Path) -> str:
    """A path as the user would recognise it: relative to the project folder when inside it.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    path = Path(path)
    try:
        return path.resolve().relative_to(PROJECT_ROOT).as_posix()
    except ValueError:
        return str(path)


def _load_dotenv(path: Path) -> None:
    """Read KEY=value lines from a local .env file (for API keys) into the environment.

    Real environment variables take priority over the file.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip().strip("\"'"))


_load_dotenv(PROJECT_ROOT / ".env")

# Ollama (local LLM). The default host is the standard local Ollama server.
OLLAMA_HOST = os.getenv("OLLAMA_HOST", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.1:8b")
OLLAMA_TIMEOUT_SECONDS = float(os.getenv("OLLAMA_TIMEOUT_SECONDS", "180"))

# Planner Agent model: DeepSeek R1 (a reasoning model). The 8b size suits 16 GB RAM;
# use deepseek-r1:14b for stronger reasoning if memory allows.
PLANNER_MODEL = os.getenv("PLANNER_MODEL", "deepseek-r1:8b")
PLANNER_THINK = os.getenv("PLANNER_THINK", "true").lower() == "true"
# Reasoning takes longer than a plain answer, so allow more time per call.
PLANNER_TIMEOUT_SECONDS = float(os.getenv("PLANNER_TIMEOUT_SECONDS", "300"))
PLANNER_NUM_CTX = int(os.getenv("PLANNER_NUM_CTX", "16384"))  # room for 15 results + R1's thinking

# Retrieval Agent model: Qwen 3.5. It rewrites each planner query for each database,
# a quick task, so its thinking phase is off by default for speed.
RETRIEVAL_MODEL = os.getenv("RETRIEVAL_MODEL", "qwen3.5:9b")
RETRIEVAL_THINK = os.getenv("RETRIEVAL_THINK", "false").lower() == "true"
# One context size for the retrieval, processing and storage agents: if it differs between
# agents sharing a model, Ollama reloads the model at each handover (about 20-25 s each
# time on an M1). Room for 25 summaries + thinking.
AGENT_NUM_CTX = int(os.getenv("AGENT_NUM_CTX", "12288"))

# Processing Agent model: also Qwen 3.5. It reads every article, so thinking is off by
# default for speed (set PROCESSING_THINK=true for deeper but much slower reasoning).
# A low temperature keeps its relevance and credibility scores consistent.
PROCESSING_MODEL = os.getenv("PROCESSING_MODEL", RETRIEVAL_MODEL)
PROCESSING_THINK = os.getenv("PROCESSING_THINK", "false").lower() == "true"
PROCESSING_TEMPERATURE = float(os.getenv("PROCESSING_TEMPERATURE", "0.2"))
PROCESSING_BATCH_SIZE = int(os.getenv("PROCESSING_BATCH_SIZE", "5"))  # articles per Qwen call
MIN_RELEVANCE = int(os.getenv("MIN_RELEVANCE", "5"))  # 0-10; below this an article is dropped
MAX_RANKED_RESULTS = int(os.getenv("MAX_RANKED_RESULTS", "25"))  # best articles kept

# Storage Agent model: Qwen 3.5 again. It writes the report's synthesis in a single call.
# Thinking is off by default: on a base M1 its reasoning alone can use the whole 5-minute
# budget. Set STORAGE_THINK=true on a faster machine for a more considered synthesis.
STORAGE_MODEL = os.getenv("STORAGE_MODEL", RETRIEVAL_MODEL)
STORAGE_THINK = os.getenv("STORAGE_THINK", "false").lower() == "true"
STORAGE_TIMEOUT_SECONDS = float(os.getenv("STORAGE_TIMEOUT_SECONDS", "300"))

# Scholarly APIs. Keys are optional but raise rate limits; put them in .env:
#   OPENALEX_API_KEY  free from https://openalex.org/settings/api (10x the keyless daily budget)
#   CORE_API_KEY      free from https://core.ac.uk/services/api
OPENALEX_API_KEY = os.getenv("OPENALEX_API_KEY") or None
CORE_API_KEY = os.getenv("CORE_API_KEY") or None
HTTP_TIMEOUT_SECONDS = float(os.getenv("HTTP_TIMEOUT_SECONDS", "20"))
ARXIV_DELAY_SECONDS = float(os.getenv("ARXIV_DELAY_SECONDS", "3"))  # arXiv asks for 3 s between calls

# Time and search limits. The Planner Agent sorts each question into a scope:
#   general  - short, broad or curious questions: a small search
#   detailed - specific or multi-part questions: a larger search
#   extended - questions needing a much bigger search and more time: only with the user's
#              permission (pop-up); if the user says no, the "detailed" limits are used.
# 5 minutes per agent is the normal maximum. (On a base M1 the 9B models write about 6 tokens
# per second, so 2 minutes was too short for them to read the articles; lower these on a
# faster machine or with smaller models.)
# Each time limit is the TOTAL for one agent across the whole research run, including
# model loading. "Articles" is how many results the Retrieval Agent may pull per search.
GENERAL_SECONDS_PER_AGENT = float(os.getenv("GENERAL_SECONDS_PER_AGENT", "300"))
DETAILED_SECONDS_PER_AGENT = float(os.getenv("DETAILED_SECONDS_PER_AGENT", "300"))
EXTENDED_SECONDS_PER_AGENT = float(os.getenv("EXTENDED_SECONDS_PER_AGENT", "600"))
GENERAL_ARTICLES_PER_SEARCH = int(os.getenv("GENERAL_ARTICLES_PER_SEARCH", "10"))
DETAILED_ARTICLES_PER_SEARCH = int(os.getenv("DETAILED_ARTICLES_PER_SEARCH", "20"))
EXTENDED_ARTICLES_PER_SEARCH = int(os.getenv("EXTENDED_ARTICLES_PER_SEARCH", "40"))
GENERAL_QUERIES_PER_SEARCH = int(os.getenv("GENERAL_QUERIES_PER_SEARCH", "3"))
DETAILED_QUERIES_PER_SEARCH = int(os.getenv("DETAILED_QUERIES_PER_SEARCH", "5"))
EXTENDED_QUERIES_PER_SEARCH = int(os.getenv("EXTENDED_QUERIES_PER_SEARCH", "6"))

# Loop control (design doc: at most 3 planning/retrieval/processing cycles)
MAX_ITERATIONS = int(os.getenv("MAX_ITERATIONS", "3"))
MIN_RESULTS_FOR_SUFFICIENCY = int(os.getenv("MIN_RESULTS_FOR_SUFFICIENCY", "5"))
# How many of the top-ranked results the planner reads when judging sufficiency
RESULTS_TO_REVIEW = int(os.getenv("RESULTS_TO_REVIEW", "15"))
