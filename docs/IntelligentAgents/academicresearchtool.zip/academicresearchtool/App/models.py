"""Pydantic schemas shared by all agents.

These models validate every piece of data passed between agents, and
``ResearchState`` is the LangGraph state that flows through the workflow.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import operator
from datetime import datetime
from enum import Enum
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator
from pydantic.json_schema import SkipJsonSchema


class Source(str, Enum):
    ARXIV = "arxiv"
    OPENALEX = "openalex"
    CORE = "core"


class RawResult(BaseModel):
    """A single record as returned by a scholarly API, normalised.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    title: str
    authors: list[str] = Field(default_factory=list)
    abstract: str | None = None
    year: int | None = None
    doi: str | None = None
    url: str | None = None
    pdf_url: str | None = None
    citation_count: int | None = None
    # Quality signals (None = the database didn't say)
    venue: str | None = Field(default=None, description="Journal, conference or repository name")
    volume: str | None = None
    issue: str | None = None
    pages: str | None = Field(default=None, description="'187–212', or an article number")
    publisher: str | None = None
    publication_type: str | None = Field(default=None, description="e.g. article, review, preprint, thesis")
    peer_reviewed: bool | None = None
    established_venue: bool | None = Field(default=None, description="Venue is on a curated list of core journals")
    verified_authors: int | None = Field(default=None, description="How many authors have an ORCID iD")
    is_retracted: bool | None = None
    language: str | None = Field(default=None, description="ISO 639-1 code from the database, e.g. 'en'")
    source: Source
    source_id: str | None = Field(default=None, description="The record's ID in its database")
    query: str = Field(description="The planner query that produced this result")


class RankedResult(RawResult):
    """A unique, relevant article after processing, with its scores and summary.

    ``final_score`` = 60% relevance + 40% quality (see ``Agents/proc.py``).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    article_id: str = Field(description="Stable ID: doi:..., arxiv:... or title:...")
    summary: str = ""
    relevance_score: float = Field(default=0.0, ge=0.0, le=1.0)
    quality_score: float = Field(default=0.0, ge=0.0, le=1.0)
    final_score: float = Field(default=0.0, ge=0.0, le=1.0)
    relevance_reason: str = ""
    quality_notes: list[str] = Field(default_factory=list, description="Why the source is (or isn't) strong")
    found_in: list[Source] = Field(default_factory=list, description="Every database that returned this article")
    queries: list[str] = Field(default_factory=list, description="Every planner query that found it")
    assessed_by: str = Field(default="", description="Model that read the article, or 'fallback'")


# ---- Planner -------------------------------------------------------------


class ResearchSubtask(BaseModel):
    """One focused part of the user's question, with the terms used to search for it.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    description: str = Field(description="What this part of the research needs to find out")
    search_terms: list[str] = Field(
        min_length=1, description="1-3 short keyword queries for academic search engines"
    )


class AcceptanceCriteria(BaseModel):
    """The planner's own standards for accepting the results of THIS question.

    Values are clamped to sensible ranges so an over-ambitious model can't make
    the criteria impossible to meet.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    min_relevant_articles: int = Field(description="Fewest relevant articles needed (3-25)")
    min_peer_reviewed_share: float = Field(description="Fraction of articles that must be peer-reviewed (0-1)")
    min_average_quality: float = Field(description="Lowest acceptable average quality score (0-1, 0.5 is typical)")
    max_age_years: int | None = Field(
        description="If recent work matters, most articles must be at most this many years old; null if age doesn't matter"
    )
    every_subtask_covered: bool = Field(description="Whether every subtask must have supporting evidence")
    other_requirements: list[str] = Field(
        default_factory=list, description="Other requirements specific to this question, judged by reading the results"
    )

    @model_validator(mode="after")
    def _clamp(self) -> "AcceptanceCriteria":
        self.min_relevant_articles = min(max(3, self.min_relevant_articles), 25)
        self.min_peer_reviewed_share = min(max(0.0, self.min_peer_reviewed_share), 1.0)
        self.min_average_quality = min(max(0.0, self.min_average_quality), 0.85)
        if self.max_age_years is not None:
            self.max_age_years = max(2, self.max_age_years)
        return self

    def judged(self) -> list[str]:
        """Criteria that can't be measured in code; the planner judges them by reading the results.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        return (["Every subtask has supporting evidence"] if self.every_subtask_covered else []) + self.other_requirements


Scope = Literal["general", "detailed", "extended"]


class ScopeLimits(BaseModel):
    """Time and search limits for one research run, set from the question's scope.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    scope: Scope
    seconds_per_agent: float = Field(description="Total time each agent may spend across the whole run")
    articles_per_search: int = Field(description="Most results the Retrieval Agent may pull per search")
    queries_per_search: int


class ResearchPlan(BaseModel):
    """Structured LLM output: the user's question broken into subtasks, plus how to judge the results.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    objective: str = Field(description="The research goal restated as one clear sentence")
    scope: Scope = Field(
        description="'general' for short, broad or curious questions; 'detailed' for specific or "
        "multi-part questions; 'extended' only if a much larger search than 'detailed' is clearly needed"
    )
    scope_reason: str = Field(description="One sentence explaining the scope")
    requested_articles: int | None = Field(
        default=None, description="The number of articles the user explicitly asked for, or null if they didn't say"
    )
    subtasks: list[ResearchSubtask] = Field(min_length=1, description="2-5 distinct subtasks")
    acceptance_criteria: AcceptanceCriteria


class SearchPlan(BaseModel):
    """Structured LLM output: replacement search queries for a follow-up search cycle.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    queries: list[str] = Field(min_length=1, description="3-5 new keyword queries")
    rationale: str = Field(description="Why these queries should fill the gaps")


class CriterionCheck(BaseModel):
    """One acceptance criterion measured against the ranked results.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    criterion: str
    met: bool
    detail: str


class SufficiencyVerdict(BaseModel):
    """The planner's decision on the processed results (structured LLM output).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    sufficient: bool
    reason: str
    gaps: list[str] = Field(default_factory=list, description="Subtasks or aspects the results do not yet cover")
    # Filled in by code, not by the model (hidden from the JSON schema sent to the LLM).
    criteria_checks: SkipJsonSchema[list[CriterionCheck]] = Field(default_factory=list)


# ---- Retrieval -----------------------------------------------------------


class ProviderQueries(BaseModel):
    """Structured LLM output: one planner query adapted to each database.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    planner_query: str = Field(description="The planner query, copied exactly")
    arxiv: str | None = Field(
        description="Keywords for arXiv, or null if arXiv (physics, CS, maths, quantitative "
        "biology/finance, statistics, engineering) is unlikely to have relevant papers"
    )
    openalex: str = Field(description="Keywords for OpenAlex (all disciplines)")
    core: str = Field(description="Keywords for CORE (open-access papers, all disciplines)")


class QueryTranslation(BaseModel):
    """Structured LLM output from the Retrieval Agent for a whole batch of planner queries.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    translations: list[ProviderQueries]


class SearchRecord(BaseModel):
    """One API call made by the Retrieval Agent (provenance for the journal).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    planner_query: str
    source: Source
    provider_query: str | None = Field(description="What was actually sent; null if this database was skipped")
    result_count: int = 0
    filtered_out: int = Field(default=0, description="Results dropped for not being in the research language")
    error: str | None = None


class RetrievalCycle(BaseModel):
    """Everything the Retrieval Agent did in one search cycle.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    iteration: int
    started_at: datetime
    completed_at: datetime
    model: str
    searches: list[SearchRecord] = Field(default_factory=list)
    raw_results: list[RawResult] = Field(default_factory=list)


# ---- Processing ----------------------------------------------------------


class ArticleJudgement(BaseModel):
    """Structured LLM output: Qwen's reading of one article.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    index: int = Field(description="The article's number in the batch")
    relevant: bool = Field(description="True only if the article genuinely addresses the research question")
    relevance: int = Field(ge=0, le=10, description="0 = unrelated, 10 = directly answers the question")
    credibility: int = Field(ge=0, le=10, description="Strength of the source: venue, publisher, type, authors")
    summary: str = Field(description="1-2 sentence summary (max 40 words) grounded only in the title and abstract")
    relevance_reason: str = Field(description="At most 15 words on why it is or isn't relevant")


class BatchJudgement(BaseModel):
    """Structured LLM output for one batch of articles.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    articles: list[ArticleJudgement]


class StoredAssessment(BaseModel):
    """A Qwen judgement saved in the journal so later cycles don't re-read the article.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    keys: list[str] = Field(description="Every ID the article is known by (DOI, arXiv ID, title)")
    relevant: bool
    relevance: int
    credibility: int
    summary: str
    relevance_reason: str
    model: str
    iteration: int


class ProcessingReport(BaseModel):
    """The Processing Agent's report back to the Planner Agent.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    iteration: int
    raw_total: int
    unique: int
    duplicates_removed: int
    retracted_removed: int
    wrong_language_removed: int = 0
    irrelevant_removed: int
    newly_assessed: int
    llm_failures: int = 0
    kept: int
    average_quality: float = 0.0
    peer_reviewed: int = 0
    relevant_by_query: dict[str, int] = Field(default_factory=dict)


class PlannerApproval(BaseModel):
    """The Planner Agent's explicit go-ahead. Nothing is written as FINAL RESULTS or
    stored as a report without one.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    approved: bool = True
    status: Literal["approved", "best_available"] = Field(
        description="'approved' if the results met the planner's criteria; 'best_available' if the "
        "search limit was reached and the planner approved the best results found"
    )
    decided_by: str = "Planner Agent"
    decided_at: datetime = Field(default_factory=datetime.now)
    search_cycles: int
    reason: str


class FinalResults(BaseModel):
    """The approved ranking, written by the Processing Agent at the end of the journal
    under the heading "FINAL RESULTS". The Storage Agent reads its report from here.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    title: Literal["FINAL RESULTS"] = "FINAL RESULTS"
    planner_approval: PlannerApproval
    written_by: str = "Processing Agent"
    written_at: datetime = Field(default_factory=datetime.now)
    goal: str
    language: str = "en"
    article_limit: int | None = Field(default=None, description="The number of articles the user asked for")
    research_plan: ResearchPlan | None = None
    planner_review: SufficiencyVerdict | None = None
    queries_used: list[str] = Field(default_factory=list)
    limits: ScopeLimits | None = None
    extra_time: str | None = Field(default=None, description="'approved' or 'declined' if the user was asked")
    seconds_used: dict[str, float] = Field(default_factory=dict, description="Time each agent had used by now")
    ranked_results: list[RankedResult] = Field(default_factory=list)


class ReportFindings(BaseModel):
    """Findings for one research subtask (structured LLM output).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    subtask: str
    points: list[str] = Field(description="2-4 findings, each citing sources like [1] or [2, 5]")


class ReportDraft(BaseModel):
    """Structured LLM output from the Storage Agent: the written parts of the report.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    title: str = Field(description="A concise, descriptive report title (at most 12 words)")
    overview: str = Field(description="2 paragraphs answering the question, citing sources like [1]")
    findings: list[ReportFindings]


class ProcessingCycle(BaseModel):
    """What the Processing Agent produced in one cycle, kept in the journal.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    iteration: int
    started_at: datetime
    completed_at: datetime
    model: str
    report: ProcessingReport
    ranked_results: list[RankedResult] = Field(default_factory=list)


# ---- Journal -------------------------------------------------------------


class ResearchJournal(BaseModel):
    """The JSON journal document for one research run, stored in ``Journal/``.

    ``final_results`` is saved under the key "FINAL RESULTS" and is always the
    last section of the file.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    model_config = ConfigDict(populate_by_name=True)

    journal_id: str = Field(description="Date and time the journal was created, also its file name")
    created_at: datetime
    goal: str
    cycles: list[RetrievalCycle] = Field(default_factory=list)
    assessments: list[StoredAssessment] = Field(default_factory=list)
    processing_cycles: list[ProcessingCycle] = Field(default_factory=list)
    final_results: FinalResults | None = Field(default=None, alias="FINAL RESULTS")

    def all_raw_results(self) -> list[RawResult]:
        return [result for cycle in self.cycles for result in cycle.raw_results]


class RetrievalReport(BaseModel):
    """The Retrieval Agent's "I'm done" message to the Planner Agent.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    status: str = Field(description="'complete', or 'failed' if every search errored")
    iteration: int
    journal_path: str
    new_results: int
    total_results: int
    results_by_source: dict[str, int] = Field(default_factory=dict)
    errors: list[str] = Field(default_factory=list)


# ---- Workflow state ------------------------------------------------------


class ActivityLogEntry(BaseModel):
    """One line in the agents' activity log (audit trail shown in the report).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    timestamp: datetime = Field(default_factory=datetime.now)
    agent: str
    iteration: int
    message: str


def _merge_counts(left: dict, right: dict) -> dict:
    return {**left, **right}


class ResearchState(BaseModel):
    """The LangGraph state passed between agent nodes.

    Fields annotated with a reducer (``operator.add`` / ``_merge_counts``)
    accumulate across loops; all other fields are overwritten. Raw results live
    in the journal file at ``journal_path``, not in the state.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    goal: str
    language: str = Field(default="en", description="ISO 639-1 code of the research language")
    article_limit: int | None = Field(
        default=None, description="Most articles the user wants in the results (from their question)"
    )
    research_plan: ResearchPlan | None = None
    search_queries: list[str] = Field(default_factory=list)
    query_history: Annotated[list[str], operator.add] = Field(default_factory=list)
    query_hits: Annotated[dict[str, int], _merge_counts] = Field(default_factory=dict)
    iteration_count: int = 0
    journal_path: str | None = None
    retrieval_report: RetrievalReport | None = None
    processing_report: ProcessingReport | None = None
    ranked_results: list[RankedResult] = Field(default_factory=list)
    sufficient: bool = False
    evaluation: SufficiencyVerdict | None = None
    limits: ScopeLimits | None = None
    extra_time: str | None = Field(default=None, description="'approved' or 'declined' if the user was asked")
    seconds_used: Annotated[dict[str, float], _merge_counts] = Field(default_factory=dict)
    out_of_time: bool = Field(default=False, description="Set when an agent's time ran out before the next search")
    planner_approval: PlannerApproval | None = None
    storage_authorized: bool = Field(
        default=False, description="Set only by the Planner Agent once FINAL RESULTS are in the journal"
    )
    activity_log: Annotated[list[ActivityLogEntry], operator.add] = Field(default_factory=list)
    report_path: str | None = None
