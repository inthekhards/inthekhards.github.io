"""LLM layer. Agents depend on the ``LLMClient`` protocol, not on Ollama directly,
so the provider can be swapped later (design doc: provider-agnostic model layer).

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import re
import time
from typing import Protocol, TypeVar

import httpx
import ollama
from pydantic import BaseModel, ValidationError
from tenacity import Retrying, retry_if_exception, stop_after_attempt, stop_after_delay, wait_exponential

from App import config
from App.control import ResearchStopped, RunControl

T = TypeVar("T", bound=BaseModel)

_UNSET = object()


class LLMClient(Protocol):
    def generate_structured(
        self, prompt: str, schema: type[T], system: str | None = None, *, timeout: float | None = None, **kwargs
    ) -> T: ...


# Authorship notes at the end of the code's comments. Pydantic turns a class's comment into
# the "description" of the answer format sent to the model, so they are removed from it.
_ATTRIBUTION = re.compile(r"\s*(Comment|Code) written with assistance of Claude Code[^\n]*", re.I)


def answer_format(schema: type[BaseModel]) -> dict:
    """The JSON schema the model must follow, without the code's authorship notes.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    def clean(value):
        if isinstance(value, dict):
            return {
                key: (_ATTRIBUTION.sub("", item).strip() if key == "description" and isinstance(item, str) else clean(item))
                for key, item in value.items()
            }
        if isinstance(value, list):
            return [clean(item) for item in value]
        return value

    return clean(schema.model_json_schema())


_THINK_BLOCK = re.compile(r"<think>.*?</think>", re.DOTALL)


def _worth_retrying(exc: BaseException) -> bool:
    # A timeout means the agent's time is used up, so don't try again.
    if isinstance(exc, httpx.TimeoutException):
        return False
    return isinstance(exc, (ValidationError, httpx.HTTPError, ollama.ResponseError))


class OllamaLLM:
    """Talks to the local Ollama server.

    ``think`` enables a reasoning model's thinking phase (e.g. DeepSeek R1). Ollama
    returns the reasoning separately in ``last_thinking`` and constrains only the
    final answer to the JSON schema. ``system_in_prompt`` merges the system prompt
    into the user message, as DeepSeek recommends for R1.

    Each call can be given a ``timeout`` in seconds: the total time allowed for
    that call including retries (agents pass what is left of their time budget).
    Answers are streamed, so a call stops promptly when the time runs out or when
    the user presses Stop (``control``).

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    def __init__(
        self,
        model: str = config.OLLAMA_MODEL,
        host: str = config.OLLAMA_HOST,
        *,
        think: bool | None = None,
        temperature: float = 0.0,
        system_in_prompt: bool = False,
        timeout: float = config.OLLAMA_TIMEOUT_SECONDS,
        num_ctx: int | None = None,
    ):
        self.model = model
        self.host = host
        self.think = think
        self.temperature = temperature
        self.system_in_prompt = system_in_prompt
        self.timeout = timeout
        # Context window in tokens. Ollama's default can be as small as 4096, which long
        # prompts plus a reasoning model's thinking can overflow (the prompt gets cut).
        self.num_ctx = num_ctx
        self.last_thinking: str | None = None
        self.control: RunControl | None = None  # set for each run by the Planner Agent
        self.log = None  # the agent's activity-log function, set for each run by the Planner Agent
        self.client = ollama.Client(host=host, timeout=timeout)

    @property
    def _options(self) -> dict:
        options: dict = {"temperature": self.temperature}
        if self.num_ctx:
            options["num_ctx"] = self.num_ctx
        return options

    def check_health(self) -> tuple[bool, str]:
        """Return (ok, message) describing whether Ollama and the model are usable.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        try:
            installed = [m.model for m in self.client.list().models]
        except (httpx.HTTPError, ConnectionError, ollama.ResponseError) as exc:
            return False, f"Can't reach Ollama at {self.host}. Is the Ollama app running? ({exc})"

        wanted = self.model if ":" in self.model else f"{self.model}:latest"
        if wanted not in installed:
            return False, f"Model '{self.model}' isn't pulled. Run: ollama pull {self.model}"
        return True, f"Ollama ready · model {self.model}"

    def _messages(self, prompt: str, system: str | None) -> list[dict]:
        if system and self.system_in_prompt:
            return [{"role": "user", "content": f"{system}\n\n{prompt}"}]
        messages = [{"role": "system", "content": system}] if system else []
        messages.append({"role": "user", "content": prompt})
        return messages

    def generate_structured(
        self,
        prompt: str,
        schema: type[T],
        system: str | None = None,
        *,
        timeout: float | None = None,
        think=_UNSET,
    ) -> T:
        """Ask the model for JSON matching ``schema`` and validate it with Pydantic.

        Invalid JSON and transient errors are retried (up to 3 attempts) while time
        remains. ``think`` overrides the model's thinking setting for this call.
        Each call is recorded in the agent's activity log.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        started = time.monotonic()
        limit = f", time limit {timeout:.0f} s" if timeout is not None else ""
        try:
            result = self._generate(prompt, schema, system, timeout, think)
        except ResearchStopped:
            self._log(f"Model {self.model} ({schema.__name__}): stopped by the user after {time.monotonic() - started:.1f} s.", "WARN")
            raise
        except httpx.TimeoutException:
            self._log(f"Model {self.model} ({schema.__name__}): ran out of time after {time.monotonic() - started:.1f} s{limit}.", "WARN")
            raise
        except Exception as exc:
            self._log(f"Model {self.model} ({schema.__name__}): failed after {time.monotonic() - started:.1f} s: "
                      f"{type(exc).__name__}: {str(exc)[:200]}", "ERROR")
            raise
        thinking = f", {len(self.last_thinking)} characters of reasoning" if self.last_thinking else ""
        self._log(f"Model {self.model} ({schema.__name__}): answered in {time.monotonic() - started:.1f} s{thinking}.")
        return result

    def _log(self, message: str, level: str = "INFO") -> None:
        if self.log:
            self.log(message, level)

    def _generate(self, prompt: str, schema: type[T], system: str | None, timeout: float | None, think) -> T:
        deadline = time.monotonic() + timeout if timeout is not None else None
        stop = stop_after_attempt(3) | stop_after_delay(timeout) if timeout is not None else stop_after_attempt(3)
        for attempt in Retrying(
            retry=retry_if_exception(_worth_retrying),
            stop=stop,
            wait=wait_exponential(min=1, max=4),
            reraise=True,
            before_sleep=lambda state: self._log(
                f"Model {self.model} ({schema.__name__}): attempt {state.attempt_number} failed "
                f"({type(state.outcome.exception()).__name__}); trying again.",
                "WARN",
            ),
        ):
            with attempt:
                if self.control:
                    self.control.checkpoint()
                client = self.client
                if deadline is not None:
                    left = deadline - time.monotonic()
                    if left < 2:
                        raise httpx.TimeoutException("Time limit reached before the model could answer")
                    client = ollama.Client(host=self.host, timeout=min(left, self.timeout))
                stream = client.chat(
                    model=self.model,
                    messages=self._messages(prompt, system),
                    format=answer_format(schema),
                    # Models without a thinking phase (think=None) are never asked to think.
                    think=self.think if think is _UNSET or self.think is None else think,
                    options=self._options,
                    stream=True,
                )
                content, thinking = self._collect(stream, deadline)
                self.last_thinking = thinking or None
                return schema.model_validate_json(self._strip_thinking(content))

    def _collect(self, stream, deadline: float | None) -> tuple[str, str]:
        """Read a streamed answer, stopping early on Stop or when the time limit passes.
        Closing the stream ends the connection, which makes Ollama stop generating.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        content: list[str] = []
        thinking: list[str] = []
        try:
            for chunk in stream:
                if self.control and self.control.stopped:
                    raise ResearchStopped()
                if deadline is not None and time.monotonic() > deadline:
                    raise httpx.TimeoutException("Time limit reached while the model was answering")
                content.append(chunk.message.content or "")
                thinking.append(getattr(chunk.message, "thinking", None) or "")
        finally:
            close = getattr(stream, "close", None)
            if close:
                close()
        return "".join(content), "".join(thinking)

    @staticmethod
    def _strip_thinking(content: str) -> str:
        """Remove any inline <think>...</think> block a reasoning model leaves in its answer.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        return _THINK_BLOCK.sub("", content).strip()


# Errors that mean "the model call failed, returned unusable output, or ran out of time".
# Agents catch these to fall back gracefully instead of crashing the run.
LLM_ERRORS = (ValidationError, httpx.HTTPError, ollama.ResponseError, ConnectionError)
