"""Async clients for the scholarly APIs used by the Retrieval Agent.

Each provider turns a keyword query into a list of normalised ``RawResult``s.
Transient failures (timeouts, HTTP 429 and 5xx) are retried with exponential
back-off via Tenacity.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import asyncio
import re
import shlex
import time
import xml.etree.ElementTree as ET

import httpx
from tenacity import AsyncRetrying, retry_if_exception, stop_after_attempt, wait_exponential

from App import config
from App.languages import get_language
from App.models import RawResult, Source

USER_AGENT = "AcademicResearchTool/0.1 (student research project)"


def _is_retryable(exc: BaseException) -> bool:
    # A database that timed out is unlikely to answer faster on a second try, and waiting
    # again would eat into the agent's time limit; connection errors are worth one more go.
    if isinstance(exc, httpx.TimeoutException):
        return False
    if isinstance(exc, httpx.TransportError):
        return True
    return isinstance(exc, httpx.HTTPStatusError) and exc.response.status_code in (429, 500, 502, 503, 504)


def _clean(text: str | None) -> str | None:
    """Collapse whitespace and decode stray escape codes some records contain
    (CORE sends "Curricula\\u27s" for "Curricula's").

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    if not text:
        return None
    text = re.sub(r"\\u([0-9a-fA-F]{2,4})", lambda m: chr(int(m.group(1), 16)), text)
    return re.sub(r"\s+", " ", text).strip()


# Characters the databases treat as search syntax: OpenAlex rejects "?" and "*" (wildcards)
# with HTTP 400, and CORE reads several of these as query operators.
SEARCH_SYNTAX = re.compile(r"""[?*:()\[\]{}^~!\\/<>=+|&]""")


def clean_query(query: str, language: str = "en") -> str:
    """Turn a query (even a whole question) into plain search keywords.

    Removes search-syntax characters and common filler words of the research language
    ("how", "does", "the"...), which databases like CORE require every one of to match.
    Quoted phrases are kept whole: '"theory of mind"' stays as it is.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    try:
        terms = shlex.split(query)
    except ValueError:  # unbalanced quotes
        terms = query.replace('"', " ").split()
    filler = get_language(language).stopwords
    kept = []
    for term in terms:
        if " " in term:  # a quoted phrase
            phrase = " ".join(SEARCH_SYNTAX.sub(" ", term).split())
            if phrase:
                kept.append(f'"{phrase}"')
            continue
        word = SEARCH_SYNTAX.sub("", term).strip(".,;'")
        if word and word.lower() not in filler:
            kept.append(word)
    return " ".join(kept) or " ".join(SEARCH_SYNTAX.sub(" ", query).split())


def _person_key(name: str) -> str:
    """'Fujita, Naoko' and 'Naoko Fujita' → the same key, so repeated authors can be merged.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    return " ".join(sorted(re.findall(r"[a-z]+", name.lower())))


def _strip_doi(doi: str | None) -> str | None:
    return re.sub(r"^https?://(dx\.)?doi\.org/", "", doi.strip(), flags=re.I) if doi else None


class Provider:
    source: Source

    async def _get(self, client: httpx.AsyncClient, url: str, **kwargs) -> httpx.Response:
        async for attempt in AsyncRetrying(
            retry=retry_if_exception(_is_retryable),
            stop=stop_after_attempt(3),
            wait=wait_exponential(min=2, max=20),
            reraise=True,
        ):
            with attempt:
                response = await client.get(url, **kwargs)
                response.raise_for_status()
        return response

    async def search(
        self, client: httpx.AsyncClient, query: str, planner_query: str, limit: int, language: str | None = None
    ) -> list[RawResult]:
        """Search for ``query``. ``language`` (ISO 639-1, e.g. 'en') limits results to that language.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        raise NotImplementedError


class ArxivProvider(Provider):
    """arXiv Atom API. No key; arXiv asks for one request every 3 seconds.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    source = Source.ARXIV
    URL = "https://export.arxiv.org/api/query"
    NS = {"a": "http://www.w3.org/2005/Atom", "arxiv": "http://arxiv.org/schemas/atom"}

    def __init__(self, delay: float = config.ARXIV_DELAY_SECONDS):
        self.delay = delay
        self._lock: asyncio.Lock | None = None
        self._lock_loop = None  # each search cycle runs in a new event loop, which needs its own lock
        self._last_call = 0.0

    def _loop_lock(self) -> asyncio.Lock:
        """The lock for the running event loop. An asyncio lock used in one loop can't be
        used in another, and each retrieval cycle runs its searches in a fresh loop.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        loop = asyncio.get_running_loop()
        if self._lock is None or self._lock_loop is not loop:
            self._lock, self._lock_loop = asyncio.Lock(), loop
        return self._lock

    @staticmethod
    def build_query(keywords: str) -> str:
        """``sleep "memory consolidation"`` → ``all:sleep AND all:"memory consolidation"``.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        try:
            terms = shlex.split(keywords)
        except ValueError:  # unbalanced quotes
            terms = keywords.replace('"', " ").split()
        return " AND ".join(f'all:"{t}"' if " " in t else f"all:{t}" for t in terms if t)

    async def search(self, client, query, planner_query, limit, language=None):
        # arXiv has no language filter; it is almost entirely English, so the Retrieval
        # Agent only uses it for English research.
        async with self._loop_lock():  # one arXiv request at a time, spaced out
            wait = self.delay - (time.monotonic() - self._last_call)
            if wait > 0:
                await asyncio.sleep(wait)
            try:
                response = await self._get(
                    client,
                    self.URL,
                    params={
                        "search_query": self.build_query(clean_query(query, "en")),
                        "start": 0,
                        "max_results": limit,
                        "sortBy": "relevance",
                    },
                )
            finally:
                self._last_call = time.monotonic()
        return self.parse(response.text, planner_query)

    # arXiv's "journal reference" sometimes holds a status note instead of a venue.
    NOT_PUBLISHED = re.compile(r"^\s*(submitted|prepared|in preparation|under review|draft|to be submitted)\b", re.I)
    PENDING = re.compile(r"^\s*(accepted(\s+for\s+publication)?(\s+(in|by|at))?|to\s+appear(\s+in)?|in\s+press(\s+in)?)\s*[:,-]?\s*", re.I)

    @classmethod
    def publication_venue(cls, journal_ref: str | None) -> str | None:
        """The venue named in arXiv's journal reference, or None if it isn't a publication.
        'Submitted to Nature' -> None (not peer reviewed yet); 'Accepted in ApJ' -> 'ApJ'.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        journal_ref = _clean(journal_ref)
        if not journal_ref or cls.NOT_PUBLISHED.match(journal_ref):
            return None
        return cls.PENDING.sub("", journal_ref).strip() or None

    def parse(self, xml_text: str, planner_query: str) -> list[RawResult]:
        results = []
        for entry in ET.fromstring(xml_text).findall("a:entry", self.NS):
            title = _clean(entry.findtext("a:title", namespaces=self.NS))
            if not title:
                continue
            abs_url = entry.findtext("a:id", namespaces=self.NS)
            published = entry.findtext("a:published", namespaces=self.NS) or ""
            pdf = next((l.get("href") for l in entry.findall("a:link", self.NS) if l.get("title") == "pdf"), None)
            doi = _strip_doi(entry.findtext("arxiv:doi", namespaces=self.NS))
            journal_ref = self.publication_venue(entry.findtext("arxiv:journal_ref", namespaces=self.NS))
            # A DOI or journal reference means the preprint was later published in a venue.
            published_version = bool(doi or journal_ref)
            results.append(
                RawResult(
                    title=title,
                    authors=[_clean(a.findtext("a:name", namespaces=self.NS)) or "" for a in entry.findall("a:author", self.NS)],
                    abstract=_clean(entry.findtext("a:summary", namespaces=self.NS)),
                    year=int(published[:4]) if published[:4].isdigit() else None,
                    doi=doi,
                    url=abs_url,
                    pdf_url=pdf,
                    venue=journal_ref or "arXiv",
                    publisher=None if published_version else "arXiv",
                    publication_type="article" if published_version else "preprint",
                    peer_reviewed=published_version,
                    source=self.source,
                    source_id=abs_url.rsplit("/abs/", 1)[-1] if abs_url else None,
                    language="en",
                    query=planner_query,
                )
            )
        return results


class OpenAlexProvider(Provider):
    """OpenAlex works search. Keyless use is limited; a free API key gives 10x more.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    source = Source.OPENALEX
    URL = "https://api.openalex.org/works"
    FIELDS = (
        "id,display_name,doi,type,publication_year,authorships,abstract_inverted_index,"
        "primary_location,best_oa_location,cited_by_count,is_retracted,biblio,language"
    )
    PEER_REVIEWED_TYPES = {"article", "review", "letter", "editorial", "book-chapter", "book"}

    def __init__(self, api_key: str | None = config.OPENALEX_API_KEY):
        self.api_key = api_key

    async def search(self, client, query, planner_query, limit, language=None):
        headers = {"Authorization": f"Bearer {self.api_key}"} if self.api_key else {}
        params = {"search": clean_query(query, language or "en"), "per_page": limit, "select": self.FIELDS}
        if language:
            params["filter"] = f"language:{language}"
        response = await self._get(client, self.URL, params=params, headers=headers)
        return [r for w in response.json().get("results", []) if (r := self.parse_work(w, planner_query))]

    @staticmethod
    def rebuild_abstract(inverted_index: dict[str, list[int]] | None) -> str | None:
        """OpenAlex stores abstracts as {word: [positions]}; put the words back in order.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        if not inverted_index:
            return None
        positions = {pos: word for word, places in inverted_index.items() for pos in places}
        return " ".join(positions[i] for i in sorted(positions))

    def parse_work(self, work: dict, planner_query: str) -> RawResult | None:
        title = _clean(work.get("display_name"))
        if not title:
            return None
        primary = work.get("primary_location") or {}
        best_oa = work.get("best_oa_location") or {}
        venue = primary.get("source") or {}
        authors = [a.get("author") or {} for a in work.get("authorships", [])]
        work_type = work.get("type")
        biblio = work.get("biblio") or {}
        first, last = biblio.get("first_page"), biblio.get("last_page")
        pages = f"{first}–{last}" if first and last and first != last else (first or None)
        if venue.get("type") in ("journal", "conference") and work_type in self.PEER_REVIEWED_TYPES:
            peer_reviewed = True
        elif work_type == "preprint" or venue.get("type") == "repository":
            peer_reviewed = False
        else:
            peer_reviewed = None
        return RawResult(
            title=title,
            authors=[a["display_name"] for a in authors if a.get("display_name")],
            abstract=self.rebuild_abstract(work.get("abstract_inverted_index")),
            year=work.get("publication_year"),
            doi=_strip_doi(work.get("doi")),
            url=primary.get("landing_page_url") or work.get("id"),
            pdf_url=best_oa.get("pdf_url"),
            citation_count=work.get("cited_by_count"),
            venue=venue.get("display_name"),
            volume=biblio.get("volume"),
            issue=biblio.get("issue"),
            pages=pages,
            publisher=venue.get("host_organization_name"),
            publication_type=work_type,
            peer_reviewed=peer_reviewed,
            established_venue=venue.get("is_core"),
            verified_authors=sum(1 for a in authors if a.get("orcid")),
            is_retracted=work.get("is_retracted"),
            language=work.get("language"),
            source=self.source,
            source_id=work.get("id"),
            query=planner_query,
        )


class CoreProvider(Provider):
    """CORE v3 open-access search. Works without a key at low rate limits.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    source = Source.CORE
    URL = "https://api.core.ac.uk/v3/search/works/"

    def __init__(self, api_key: str | None = config.CORE_API_KEY):
        self.api_key = api_key

    async def search(self, client, query, planner_query, limit, language=None):
        headers = {"Authorization": f"Bearer {self.api_key}"} if self.api_key else {}
        keywords = clean_query(query, language or "en")
        q = f"({keywords}) AND language.code:{language}" if language else keywords
        response = await self._get(client, self.URL, params={"q": q, "limit": limit}, headers=headers)
        return [r for w in response.json().get("results", []) if (r := self.parse_work(w, planner_query))]

    def parse_work(self, work: dict, planner_query: str) -> RawResult | None:
        title = _clean(work.get("title"))
        if not title:
            return None
        # CORE merges records from many repositories, so the same author often appears
        # several times in different formats ("Fujita, Naoko" / "Naoko Fujita").
        authors: dict[str, str] = {}
        for entry in work.get("authors", []):
            name = _clean(entry.get("name"))
            if name:
                authors.setdefault(_person_key(name), name)
        authors = list(authors.values())
        display = next((l.get("url") for l in work.get("links", []) if l.get("type") == "display"), None)
        journal = next((j.get("title") for j in work.get("journals") or [] if j.get("title")), None)
        doc_type = (work.get("documentType") or "").lower() or None
        if (work.get("fieldOfStudy") or "").lower() == "thesis":
            doc_type = "thesis"
        if journal and doc_type in (None, "research article", "article", "review"):
            peer_reviewed = True
        elif doc_type in ("thesis", "preprint", "report", "presentation"):
            peer_reviewed = False
        else:
            peer_reviewed = None
        return RawResult(
            title=title,
            authors=authors,
            abstract=_clean(work.get("abstract")),
            year=work.get("yearPublished"),
            doi=_strip_doi(work.get("doi")),
            url=display or (f"https://core.ac.uk/works/{work['id']}" if work.get("id") else None),
            pdf_url=work.get("downloadUrl") or None,
            citation_count=work.get("citationCount"),
            venue=journal,
            publisher=_clean(work.get("publisher")),
            publication_type=doc_type,
            peer_reviewed=peer_reviewed,
            language=(work.get("language") or {}).get("code"),
            source=self.source,
            source_id=str(work["id"]) if work.get("id") else None,
            query=planner_query,
        )


def default_providers() -> list[Provider]:
    return [ArxivProvider(), OpenAlexProvider(), CoreProvider()]


def make_http_client() -> httpx.AsyncClient:
    return httpx.AsyncClient(
        timeout=config.HTTP_TIMEOUT_SECONDS, follow_redirects=True, headers={"User-Agent": USER_AGENT}
    )
