"""Support code for the research agents: settings, data schemas, the LLM layer,
model catalog, languages, time budgets, journal storage, scholarly API clients
and Harvard referencing.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""
