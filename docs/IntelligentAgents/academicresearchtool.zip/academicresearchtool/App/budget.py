"""Time and search limits for the agents.

Each agent has a total time budget for the whole research run, set by the
question's scope (see ``App/config.py``). Before an agent works, the Planner Agent
gives it a ``deadline``; the agent checks ``seconds_left(deadline)`` and works
with what it has when time runs short. Time spent waiting for the user to answer
a pop-up is not charged to any agent.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import time
from collections import defaultdict
from contextlib import contextmanager

from App import config
from App.models import Scope, ScopeLimits

# Which agent each workflow step belongs to (for charging time).
PLANNER, RETRIEVAL, PROCESSING, STORAGE = "Planner Agent", "Retrieval Agent", "Processing Agent", "Storage Agent"


def scope_limits(scope: Scope) -> ScopeLimits:
    seconds, articles, queries = {
        "general": (config.GENERAL_SECONDS_PER_AGENT, config.GENERAL_ARTICLES_PER_SEARCH, config.GENERAL_QUERIES_PER_SEARCH),
        "detailed": (config.DETAILED_SECONDS_PER_AGENT, config.DETAILED_ARTICLES_PER_SEARCH, config.DETAILED_QUERIES_PER_SEARCH),
        "extended": (config.EXTENDED_SECONDS_PER_AGENT, config.EXTENDED_ARTICLES_PER_SEARCH, config.EXTENDED_QUERIES_PER_SEARCH),
    }[scope]
    return ScopeLimits(scope=scope, seconds_per_agent=seconds, articles_per_search=articles, queries_per_search=queries)


# Until the planner has read the question, the normal maximum applies.
DEFAULT_LIMITS = scope_limits("detailed")


def seconds_left(deadline: float | None) -> float | None:
    """Seconds until ``deadline`` (a ``time.monotonic()`` value); None means no limit.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    return None if deadline is None else max(0.0, deadline - time.monotonic())


def has_time(deadline: float | None, needed: float) -> bool:
    left = seconds_left(deadline)
    return left is None or left >= needed


def format_seconds(seconds: float) -> str:
    seconds = round(seconds)
    return f"{seconds // 60}m {seconds % 60:02d}s" if seconds >= 60 else f"{seconds}s"


class TimeBudget:
    """Tracks how much of its time budget each agent has used in this run.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    def __init__(self, seconds_per_agent: float = DEFAULT_LIMITS.seconds_per_agent):
        self.seconds_per_agent = seconds_per_agent
        self.used: dict[str, float] = defaultdict(float)
        self.paused = 0.0  # total seconds spent waiting on the user

    def remaining(self, agent: str) -> float:
        return max(0.0, self.seconds_per_agent - self.used[agent])

    def deadline(self, agent: str) -> float:
        return time.monotonic() + self.remaining(agent)

    def charge(self, agent: str, seconds: float) -> None:
        self.used[agent] += max(0.0, seconds)

    @contextmanager
    def pause(self):
        """Don't charge anyone for the time inside this block (e.g. a pop-up).

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        start = time.monotonic()
        try:
            yield
        finally:
            self.paused += time.monotonic() - start
