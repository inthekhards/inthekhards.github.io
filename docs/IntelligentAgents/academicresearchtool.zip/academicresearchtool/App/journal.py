"""Reads and writes the JSON research journals in ``Journal/``.

One journal is created per research run and named by the date and time it was
created, e.g. ``Journal/2026-10-04_15-02-33.json``. The Retrieval Agent appends
each search cycle; the Processing Agent reads the raw results back from it and,
once the Planner Agent approves, writes the "FINAL RESULTS" section at the end,
which the Storage Agent reads.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import json
import os
from datetime import datetime
from pathlib import Path

from App import config
from App.models import ResearchJournal, RetrievalCycle

TIMESTAMP_FORMAT = "%Y-%m-%d_%H-%M-%S"


class JournalStore:
    def __init__(self, journal_dir: Path | None = None):
        self.journal_dir = journal_dir or config.JOURNAL_DIR  # read now, so a changed setting is honoured

    def create(self, goal: str) -> Path:
        """Create an empty journal for a new research run and return its path.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        self.journal_dir.mkdir(parents=True, exist_ok=True)
        now = datetime.now()
        journal_id = now.strftime(TIMESTAMP_FORMAT)
        path = self.journal_dir / f"{journal_id}.json"
        # Two runs started in the same second get -2, -3, ... suffixes.
        suffix = 2
        while path.exists():
            path = self.journal_dir / f"{journal_id}-{suffix}.json"
            suffix += 1
        self.save(path, ResearchJournal(journal_id=path.stem, created_at=now, goal=goal))
        return path

    def load(self, path: str | Path) -> ResearchJournal:
        return ResearchJournal.model_validate_json(Path(path).read_text(encoding="utf-8"))

    def save(self, path: str | Path, journal: ResearchJournal) -> None:
        """Write atomically so a crash mid-write never leaves a half-written journal.

        "FINAL RESULTS" is always the last key, and is left out until it exists.

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        data = json.loads(journal.model_dump_json(by_alias=True))
        final = data.pop("FINAL RESULTS", None)
        if final is not None:
            data["FINAL RESULTS"] = final
        path = Path(path)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, path)

    def append_cycle(self, path: str | Path, cycle: RetrievalCycle) -> ResearchJournal:
        journal = self.load(path)
        journal.cycles.append(cycle)
        self.save(path, journal)
        return journal
