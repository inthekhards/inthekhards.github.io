"""Activity logs: one plain-text log per agent for each research run.

    Agents/Logs/Planner/2026-10-04_19-30-00.log
    Agents/Logs/Retrieval/2026-10-04_19-30-00.log
    Agents/Logs/Processing/2026-10-04_19-30-00.log
    Agents/Logs/Storage/2026-10-04_19-30-00.log

Each log has the same name as the run's journal (Journal/2026-10-04_19-30-00.json),
so the two are easy to match up. A log records what the agent did and when: each
step with its duration, what it decided, every model call (model, time taken,
success, timeout or error), Stop/Pause, errors, and its total time used.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

import threading
from datetime import datetime
from pathlib import Path

from App import config

AGENT_FOLDERS = {
    "Planner Agent": "Planner",
    "Retrieval Agent": "Retrieval",
    "Processing Agent": "Processing",
    "Storage Agent": "Storage",
}


class ActivityLog:
    """Writes timestamped lines to each agent's log file for one run.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """

    def __init__(self, run_id: str, log_dir: Path | None = None):
        self.run_id = run_id
        self.log_dir = Path(log_dir or config.AGENT_LOG_DIR)
        self._lock = threading.Lock()  # model calls and the workflow may log from different threads
        self.paths = {}
        for agent, folder in AGENT_FOLDERS.items():
            (self.log_dir / folder).mkdir(parents=True, exist_ok=True)
            self.paths[agent] = self.log_dir / folder / f"{run_id}.log"

    def write(self, agent: str, message: str, level: str = "INFO") -> None:
        path = self.paths.get(agent)
        if path is None:
            return
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        lines = str(message).splitlines() or [""]
        text = f"{stamp}  {level:<5}  {lines[0]}\n" + "".join(f"{'':>28}{line}\n" for line in lines[1:])
        with self._lock:
            with open(path, "a", encoding="utf-8") as f:
                f.write(text)

    def write_all(self, message: str, level: str = "INFO") -> None:
        for agent in AGENT_FOLDERS:
            self.write(agent, message, level)

    def for_agent(self, agent: str):
        """A one-argument logging function for a single agent (given to its model client).

        Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
        """
        return lambda message, level="INFO": self.write(agent, message, level)
