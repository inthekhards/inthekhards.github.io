"""The models users can choose for each agent in the interface, and how to run them.

Defaults: DeepSeek R1 plans; Qwen 3.5 retrieves, processes and writes the report.
Any other local Ollama model name can also be typed into the interface; unknown
models get neutral settings (no thinking requested).

Only local models are used: everything runs on this computer, and nothing is sent
to cloud-hosted models.

Each model has slightly different needs: DeepSeek R1 wants its instructions in the
user message and a temperature around 0.6; models without a thinking phase must
not be asked to think.

Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
Code written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
"""

from dataclasses import dataclass

from App import config
from App.llm import OllamaLLM

ROLES = ("planner", "retrieval", "processing", "storage")
ROLE_LABELS = {"planner": "Planning", "retrieval": "Retrieval", "processing": "Processing", "storage": "Storage"}


@dataclass(frozen=True)
class ModelOption:
    tag: str
    label: str
    can_think: bool | None  # None = unknown (don't send a thinking setting)
    temperature: float = 0.7  # for answers without thinking
    thinking_temperature: float = 0.6
    system_in_prompt: bool = False
    note: str = ""


CATALOG: list[ModelOption] = [
    ModelOption("deepseek-r1:8b", "DeepSeek R1 8B", can_think=True, temperature=0.6, system_in_prompt=True,
                note="reasoning model, 5.2 GB"),
    ModelOption("qwen3.5:9b", "Qwen 3.5 9B", can_think=True, note="6.6 GB"),
    ModelOption("llama3.1:8b", "Llama 3.1 8B", can_think=False, temperature=0.5, note="4.9 GB, no thinking phase"),
    ModelOption("gemma4:e4b", "Gemma 4 E4B", can_think=True, temperature=0.7, note="6.6 GB"),
]

DEFAULT_MODELS = {
    "planner": config.PLANNER_MODEL,
    "retrieval": config.RETRIEVAL_MODEL,
    "processing": config.PROCESSING_MODEL,
    "storage": config.STORAGE_MODEL,
}


def is_cloud_model(tag: str) -> bool:
    """Ollama names its cloud-hosted models '...:cloud' or '...-cloud'.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    tag = tag.strip().lower()
    return tag.endswith(":cloud") or tag.endswith("-cloud") or "-cloud:" in tag


def profile(tag: str) -> ModelOption:
    """Settings for a model tag; neutral ones for models not in the catalog.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    tag = tag.strip()
    for option in CATALOG:
        if option.tag == tag:
            return option
    return ModelOption(tag, tag, can_think=None)


def make_llm(role: str, tag: str | None = None) -> OllamaLLM:
    """Build the LLM client for an agent role, using the model's own best settings.

    Comment written with assistance of Claude Code Opus 5.5 (Anthropic, 2026).
    """
    tag = tag or DEFAULT_MODELS[role]
    if is_cloud_model(tag):
        raise ValueError(f"'{tag}' is a cloud model. Only local models can be used.")
    option = profile(tag)
    wants_thinking = {
        "planner": config.PLANNER_THINK,
        "retrieval": config.RETRIEVAL_THINK,
        "processing": config.PROCESSING_THINK,
        "storage": config.STORAGE_THINK,
    }[role]
    think = wants_thinking if option.can_think else None
    if role == "processing":
        temperature = config.PROCESSING_TEMPERATURE  # consistent scores matter more than variety
    else:
        temperature = option.thinking_temperature if think else option.temperature
    return OllamaLLM(
        model=option.tag,
        think=think,
        temperature=temperature,
        system_in_prompt=option.system_in_prompt,
        timeout={"planner": config.PLANNER_TIMEOUT_SECONDS, "storage": config.STORAGE_TIMEOUT_SECONDS}.get(
            role, config.OLLAMA_TIMEOUT_SECONDS
        ),
        num_ctx=config.PLANNER_NUM_CTX if role == "planner" else config.AGENT_NUM_CTX,
    )
